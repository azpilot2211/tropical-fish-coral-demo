// Mobile menu drawer, mega-menu toggles, and a header shadow once the page scrolls.
(() => {
	const body = document.body;
	const nav = document.querySelector('[data-nav]');
	const opener = document.querySelector('[data-menu-open]');
	if (!nav || !opener) return;

	const setMenu = (open) => {
		body.classList.toggle('menu-open', open);
		opener.setAttribute('aria-expanded', String(open));
		if (open) nav.querySelector('input, a, button')?.focus();
		else opener.focus();
	};
	opener.addEventListener('click', () => setMenu(true));
	document.querySelectorAll('[data-menu-close]').forEach((el) => el.addEventListener('click', () => setMenu(false)));
	document.addEventListener('keydown', (e) => {
		if (e.key !== 'Escape') return;
		if (body.classList.contains('menu-open')) setMenu(false);
		document.querySelectorAll('.nav-item.is-open').forEach((li) => li.classList.remove('is-open'));
	});

	// Chevron buttons open a category's panel (the accordion on phones, the mega menu for keyboards/touch).
	nav.querySelectorAll('.mega-toggle').forEach((btn) => {
		btn.addEventListener('click', () => {
			const li = btn.closest('.nav-item');
			const open = !li.classList.contains('is-open');
			nav.querySelectorAll('.nav-item.is-open').forEach((other) => other !== li && other.classList.remove('is-open'));
			li.classList.toggle('is-open', open);
			btn.setAttribute('aria-expanded', String(open));
		});
	});

	const header = document.querySelector('[data-header]');
	const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
	window.addEventListener('scroll', onScroll, { passive: true });
	onScroll();
})();

// Home hero: while its tall section scrolls past, the pinned video's playhead follows the scroll and
// the copy steps through three beats. front-page.php adds .is-scrub (and starts the download) before
// first paint unless the visitor asked for reduced motion; without it the hero stays a still first frame.
(() => {
	const hero = document.querySelector('.hero.is-scrub');
	const video = hero?.querySelector('video');
	if (!video) return;
	const stage = hero.querySelector('.hero-stage');
	const header = document.querySelector('[data-header]');
	let stageTop = 0, target = 0, shown = 0, running = false;

	// The stage pins just under the sticky header (and the admin bar when logged in).
	const measure = () => {
		stageTop = header ? (parseFloat(getComputedStyle(header).top) || 0) + header.offsetHeight : 0;
		hero.style.setProperty('--stage-top', stageTop + 'px');
	};
	// Glide the playhead toward the scroll position; one seek at a time keeps decoding smooth.
	const tick = () => {
		shown += (target - shown) * 0.18;
		if (Math.abs(target - shown) < 0.0005) shown = target;
		const time = shown * Math.max(0, (video.duration || 0) - 0.05);
		const behind = video.duration > 0 && Math.abs(video.currentTime - time) > 0.01;
		if (behind && !video.seeking) video.currentTime = time;
		running = shown !== target || behind;
		if (running) requestAnimationFrame(tick);
	};
	const onScroll = () => {
		const r = hero.getBoundingClientRect();
		target = Math.min(1, Math.max(0, (stageTop - r.top) / (r.height - stage.offsetHeight)));
		hero.style.setProperty('--p', target.toFixed(4));
		hero.dataset.beat = target < 0.3 ? 1 : target < 0.64 ? 2 : 3;
		if (!running) { running = true; requestAnimationFrame(tick); }
	};

	measure();
	onScroll();
	window.addEventListener('scroll', onScroll, { passive: true });
	window.addEventListener('resize', () => { measure(); onScroll(); });
	video.addEventListener('loadedmetadata', onScroll);
	// The inline script already started the download; a brief muted play also lets iPhones show frames when seeking.
	video.play().then(() => { video.pause(); onScroll(); }).catch(() => video.load());
})();
