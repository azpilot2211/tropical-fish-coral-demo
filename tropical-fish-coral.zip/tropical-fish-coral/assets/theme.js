// Mobile menu drawer, mega-menu toggles, and a header shadow once the page scrolls.
(() => {
	const body = document.body;
	const nav = document.querySelector('[data-nav]');
	const opener = document.querySelector('[data-menu-open]');
	if (!nav || !opener) return;

	const setMenu = (open) => {
		body.classList.toggle('menu-open', open);
		opener.setAttribute('aria-expanded', String(open));
		if (open) nav.querySelector('input, a, button')?.focus();
		else opener.focus();
	};
	opener.addEventListener('click', () => setMenu(true));
	document.querySelectorAll('[data-menu-close]').forEach((el) => el.addEventListener('click', () => setMenu(false)));
	document.addEventListener('keydown', (e) => {
		if (e.key !== 'Escape') return;
		if (body.classList.contains('menu-open')) setMenu(false);
		document.querySelectorAll('.nav-item.is-open').forEach((li) => li.classList.remove('is-open'));
	});

	// Chevron buttons open a category's panel (the accordion on phones, the mega menu for keyboards/touch).
	nav.querySelectorAll('.mega-toggle').forEach((btn) => {
		btn.addEventListener('click', () => {
			const li = btn.closest('.nav-item');
			const open = !li.classList.contains('is-open');
			nav.querySelectorAll('.nav-item.is-open').forEach((other) => other !== li && other.classList.remove('is-open'));
			li.classList.toggle('is-open', open);
			btn.setAttribute('aria-expanded', String(open));
		});
	});

	const header = document.querySelector('[data-header]');
	const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
	window.addEventListener('scroll', onScroll, { passive: true });
	onScroll();
})();

// Home hero: a looping, autoplaying background video, no playback controls. inc/home.php's inline
// script adds .can-autoplay (and starts the download) before first paint unless the visitor asked
// for reduced motion or Save-Data; either way the poster stands in until (if ever) the video plays,
// so there's never a blank box.
(() => {
	const hero = document.querySelector('.hero[data-hero]');
	const video = hero?.querySelector('video');
	if (!hero || !video) return;
	const loading = hero.querySelector('.hero-loading');
	const autoplay = hero.classList.contains('can-autoplay');

	video.addEventListener('playing', () => loading?.classList.add('is-done'));

	// Paused while scrolled off screen to save battery and bandwidth; resumed once it's back in view.
	new IntersectionObserver(([entry]) => {
		if (entry.isIntersecting) { if (autoplay && video.paused) video.play().catch(() => {}); }
		else if (!video.paused) video.pause();
	}, { threshold: .15 }).observe(hero);

	if (autoplay) video.play().catch(() => loading?.classList.add('is-done'));
	else loading?.remove();
})();
