// Mobile menu drawer, mega-menu toggles, and a header shadow once the page scrolls.
(() => {
	const body = document.body;
	const nav = document.querySelector('[data-nav]');
	const opener = document.querySelector('[data-menu-open]');
	if (!nav || !opener) return;

	const setMenu = (open) => {
		body.classList.toggle('menu-open', open);
		opener.setAttribute('aria-expanded', String(open));
		if (open) nav.querySelector('input, a, button')?.focus();
		else opener.focus();
	};
	opener.addEventListener('click', () => setMenu(true));
	document.querySelectorAll('[data-menu-close]').forEach((el) => el.addEventListener('click', () => setMenu(false)));
	document.addEventListener('keydown', (e) => {
		if (e.key !== 'Escape') return;
		if (body.classList.contains('menu-open')) setMenu(false);
		document.querySelectorAll('.nav-item.is-open').forEach((li) => li.classList.remove('is-open'));
	});

	// Chevron buttons open a category's panel (the accordion on phones, the mega menu for keyboards/touch).
	nav.querySelectorAll('.mega-toggle').forEach((btn) => {
		btn.addEventListener('click', () => {
			const li = btn.closest('.nav-item');
			const open = !li.classList.contains('is-open');
			nav.querySelectorAll('.nav-item.is-open').forEach((other) => other !== li && other.classList.remove('is-open'));
			li.classList.toggle('is-open', open);
			btn.setAttribute('aria-expanded', String(open));
		});
	});

	const header = document.querySelector('[data-header]');
	const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
	window.addEventListener('scroll', onScroll, { passive: true });
	onScroll();
})();
