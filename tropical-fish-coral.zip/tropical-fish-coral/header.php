<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>

<?php // Elementor Pro's Theme Builder can replace the header; otherwise the theme's own shows. ?>
<?php if ( ! ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'header' ) ) ) : ?>
<div class="announce">
	<div class="wrap"><?php echo esc_html( tfc_mod( 'announcement' ) ); ?> <a href="<?php echo esc_url( home_url( '/shipping-guarantee/' ) ); ?>">Details</a></div>
</div>

<header class="site-header" data-header>
	<div class="wrap header-bar">
		<button class="header-icon menu-toggle" type="button" aria-controls="site-nav" aria-expanded="false" data-menu-open>
			<?php echo tfc_icon( 'menu' ); ?><span class="sr-only">Menu</span>
		</button>

		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() ) : ?>
				<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, [ 'class' => 'brand-logo', 'alt' => get_bloginfo( 'name' ) ] ); ?>
			<?php else : ?>
				<svg class="brand-mark" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="19" fill="var(--deep)"/><path d="M9 21c3.6-5 7.8-7.5 12.5-7.5 3.3 0 6 1.6 8.2 4.8l3.3-3.1v11.6l-3.3-3.1c-2.2 3.2-4.9 4.8-8.2 4.8C16.8 28.5 12.6 26 9 21Z" fill="var(--sky)"/><circle cx="14.5" cy="19.6" r="1.3" fill="var(--deep)"/><path d="M20 13.8c1.4 2.3 1.4 12.1 0 14.4" stroke="var(--deep)" stroke-width="1.4" fill="none" opacity=".55"/></svg>
				<span class="brand-name">Tropical Fish <em>&amp; Coral</em></span>
			<?php endif; ?>
		</a>

		<nav id="site-nav" class="site-nav" aria-label="Shop" data-nav>
			<div class="drawer-head">
				<span class="brand-name">Tropical Fish <em>&amp; Coral</em></span>
				<button class="header-icon" type="button" data-menu-close><?php echo tfc_icon( 'close' ); ?><span class="sr-only">Close menu</span></button>
			</div>
			<form class="search-field drawer-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php echo tfc_icon( 'search' ); ?>
				<input type="search" name="s" placeholder="Search fish, corals, supplies" aria-label="Search products">
				<input type="hidden" name="post_type" value="product">
			</form>
			<ul class="nav-list">
				<li class="nav-item nav-item--home"><a class="nav-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
				<?php foreach ( tfc_top_categories() as $top ) :
					$kids = tfc_child_categories( $top->term_id );
					$deep = array_filter( $kids, fn( $k ) => tfc_child_categories( $k->term_id ) ); ?>
					<li class="nav-item<?php echo $kids ? ' has-mega' : ''; ?>">
						<a class="nav-link" href="<?php echo esc_url( get_term_link( $top ) ); ?>"><?php echo esc_html( $top->name ); ?></a>
						<?php if ( $kids ) : ?>
							<button class="mega-toggle" type="button" aria-expanded="false" aria-label="<?php echo esc_attr( $top->name ); ?> categories"><?php echo tfc_icon( 'chevron' ); ?></button>
							<div class="mega">
								<div class="wrap mega-inner">
									<?php if ( $deep ) : foreach ( $kids as $kid ) : $grand = tfc_child_categories( $kid->term_id ); ?>
										<div class="mega-col<?php echo count( $grand ) > 8 ? ' mega-col--wide' : ''; ?>">
											<a class="mega-heading" href="<?php echo esc_url( get_term_link( $kid ) ); ?>"><?php echo esc_html( $kid->name ); ?></a>
											<?php if ( $grand ) : ?>
												<ul><?php foreach ( $grand as $g ) printf( '<li><a href="%s">%s</a></li>', esc_url( get_term_link( $g ) ), esc_html( $g->name ) ); ?></ul>
											<?php else : ?>
												<p class="mega-note"><?php echo esc_html( $kid->description ); ?></p>
											<?php endif; ?>
										</div>
									<?php endforeach; else : ?>
										<div class="mega-col mega-col--wide">
											<span class="mega-heading">Shop by type</span>
											<ul><?php foreach ( $kids as $kid ) printf( '<li><a href="%s">%s</a></li>', esc_url( get_term_link( $kid ) ), esc_html( $kid->name ) ); ?></ul>
										</div>
									<?php endif; ?>
									<a class="mega-promo" href="<?php echo esc_url( get_term_link( $top ) ); ?>">
										<img src="<?php echo esc_url( tfc_category_image( $top, 560, 640 ) ); ?>" alt="" loading="lazy" width="280" height="320">
										<span class="mega-promo__label">Shop all <?php echo esc_html( $top->name ); ?> <?php echo tfc_icon( 'arrow' ); ?></span>
									</a>
								</div>
							</div>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
				<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
					<li class="nav-item"><a class="nav-link" href="<?php echo esc_url( add_query_arg( 'orderby', 'date', wc_get_page_permalink( 'shop' ) ) ); ?>">New Arrivals</a></li>
				<?php endif; ?>
				<?php if ( $specials = get_page_by_path( 'specials' ) ) : ?>
					<li class="nav-item"><a class="nav-link" href="<?php echo esc_url( get_permalink( $specials ) ); ?>">Specials</a></li>
				<?php endif; ?>
				<?php if ( post_type_exists( 'tfc_tutorial' ) ) : // added by the TFC Tutorials plugin ?>
					<li class="nav-item"><a class="nav-link" href="<?php echo esc_url( get_post_type_archive_link( 'tfc_tutorial' ) ); ?>">Tutorials</a></li>
				<?php endif; ?>
				<li class="nav-item"><a class="nav-link" href="<?php echo esc_url( home_url( '/shipping-guarantee/' ) ); ?>">Shipping &amp; Guarantee</a></li>
			</ul>
		</nav>
		<div class="nav-scrim" data-menu-close></div>

		<div class="header-actions">
			<form class="search-field header-search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php echo tfc_icon( 'search' ); ?>
				<input type="search" name="s" placeholder="Search fish, corals, supplies" aria-label="Search products" value="<?php echo esc_attr( get_search_query() ); ?>">
				<input type="hidden" name="post_type" value="product">
			</form>
			<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
				<a class="header-icon" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" aria-label="Your account"><?php echo tfc_icon( 'user' ); ?></a>
			<?php endif; ?>
			<?php echo tfc_cart_link(); ?>
		</div>
	</div>
</header>
<?php endif; ?>

<main id="main">
