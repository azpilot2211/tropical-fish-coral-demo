<?php
/**
 * Tropical Fish & Coral: a WooCommerce theme for live goods, dry goods and supplies.
 */
defined( 'ABSPATH' ) || exit;

const TFC_VERSION = '2.6.0';
const TFC_LIVE    = 'live-goods'; // category slug; anything under it is livestock

require __DIR__ . '/inc/catalog.php';
require __DIR__ . '/inc/home-flags.php';
require __DIR__ . '/inc/home.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', [ 'height' => 80, 'width' => 280, 'flex-height' => true, 'flex-width' => true ] );
	add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption', 'style', 'script' ] );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'woocommerce', [
		'thumbnail_image_width' => 480,
		'single_image_width'    => 900,
		'product_grid'          => [ 'default_columns' => 4, 'default_rows' => 6 ],
	] );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'tfc-fonts', 'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..700;1,9..144,300..600&family=Instrument+Sans:wght@400..700&display=swap', [], null );
	wp_enqueue_style( 'tfc', get_stylesheet_uri(), [], TFC_VERSION );
	wp_enqueue_script( 'tfc', get_theme_file_uri( 'assets/theme.js' ), [], TFC_VERSION, [ 'in_footer' => true, 'strategy' => 'defer' ] );
} );

// The theme lays out shop pages itself; keep WooCommerce's form and gallery styles only.
add_filter( 'woocommerce_enqueue_styles', function ( $styles ) {
	unset( $styles['woocommerce-layout'], $styles['woocommerce-smallscreen'] );
	return $styles;
} );

add_filter( 'wp_resource_hints', function ( $urls, $type ) {
	if ( $type === 'preconnect' ) {
		$urls[] = [ 'href' => 'https://fonts.gstatic.com', 'crossorigin' ];
		$urls[] = 'https://images.unsplash.com';
	}
	return $urls;
}, 10, 2 );

// ---- Owner-editable text (Appearance → Customize → Store details) ----------------------------

const TFC_MODS = [
	'announcement' => [ 'Announcement bar', 'Live Arrival Guarantee on every fish, coral and invertebrate · Live goods ship overnight Monday–Wednesday', 'text' ],
	'hero_kicker'  => [ 'Hero: small line above the heading', 'Livestock · Dry goods · Reef supplies', 'text' ],
	'hero_title'   => [ 'Hero: heading', 'Healthy reef life, delivered with care.', 'text' ],
	'hero_text'    => [ 'Hero: text', 'Fish, corals and invertebrates observed in our systems before they ship, plus the foods, salt and equipment we trust on our own reefs.', 'textarea' ],
	'phone'        => [ 'Phone', '(555) 010-2468', 'text' ],
	'email'        => [ 'Email', 'hello@tropicalfishandcoral.com', 'text' ],
	'address'      => [ 'Address', "1200 Reef Way, Suite 4\nSan Diego, CA 92101", 'textarea' ],
	'hours'        => [ 'Hours', "Mon–Fri 10am–6pm\nSat 10am–4pm", 'textarea' ],
];

function tfc_mod( $key ) {
	return get_theme_mod( $key, TFC_MODS[ $key ][1] );
}

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'tfc', [ 'title' => 'Store details', 'priority' => 30 ] );
	foreach ( TFC_MODS as $key => [ $label, $default, $type ] ) {
		$wp_customize->add_setting( $key, [ 'default' => $default, 'sanitize_callback' => $type === 'textarea' ? 'sanitize_textarea_field' : 'sanitize_text_field' ] );
		$wp_customize->add_control( $key, [ 'label' => $label, 'section' => 'tfc', 'type' => $type ] );
	}
} );

// ---- Icons (inline SVG, stroke = currentColor) -----------------------------------------------

function tfc_icon( $name ) {
	$paths = [
		'search'  => '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
		'user'    => '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20.5c.8-3.6 3.9-5.5 7.5-5.5s6.7 1.9 7.5 5.5"/>',
		'bag'     => '<path d="M5.5 8.5h13l-1 12h-11l-1-12Z"/><path d="M9 8.5V7a3 3 0 0 1 6 0v1.5"/>',
		'menu'    => '<path d="M4 7h16M4 12h16M4 17h10"/>',
		'close'   => '<path d="M6 6l12 12M18 6 6 18"/>',
		'arrow'   => '<path d="M4.5 12h15M13.5 6l6 6-6 6"/>',
		'chevron' => '<path d="m7 10 5 5 5-5"/>',
		'truck'   => '<path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3v3h-7"/><circle cx="6.5" cy="17.5" r="1.8"/><circle cx="16.5" cy="17.5" r="1.8"/>',
		'shield'  => '<path d="M12 3 5 5.8v5.7c0 4.3 2.9 7.6 7 9.5 4.1-1.9 7-5.2 7-9.5V5.8L12 3Z"/><path d="m9 12 2.2 2.2L15.5 10"/>',
		'drop'    => '<path d="M12 3.5s6 6.4 6 10.8a6 6 0 0 1-12 0C6 9.9 12 3.5 12 3.5Z"/><path d="M9.5 15a2.5 2.5 0 0 0 2.5 2.3"/>',
		'chat'    => '<path d="M4.5 5.5h15v10h-9l-4.5 3.5v-3.5h-1.5z"/><path d="M8.5 10.5h7"/>',
		'lock'    => '<rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8.5 10.5V7.8a3.5 3.5 0 0 1 7 0v2.7"/>',
		'phone'   => '<path d="M6.5 4h3l1.5 4.5-2 1.3a10.5 10.5 0 0 0 5.2 5.2l1.3-2 4.5 1.5v3a2 2 0 0 1-2 2A15 15 0 0 1 4.5 6a2 2 0 0 1 2-2Z"/>',
		'mail'    => '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="m4 7 8 6 8-6"/>',
		'pin'     => '<path d="M12 21s6.5-5.6 6.5-11a6.5 6.5 0 0 0-13 0c0 5.4 6.5 11 6.5 11Z"/><circle cx="12" cy="10" r="2.3"/>',
		'clock'   => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
		'thermo'  => '<path d="M10 14.5V5a2 2 0 0 1 4 0v9.5a4 4 0 1 1-4 0Z"/><path d="M12 9v7"/>',
		'eye'     => '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>',
	];
	return '<svg class="icon" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' . ( $paths[ $name ] ?? '' ) . '</svg>';
}

// ---- Products ----------------------------------------------------------------------------------

// Is the product (default: the current one) in Live Goods or anything under it?
function tfc_is_live( $product = null ) {
	$product = $product ? wc_get_product( $product ) : wc_get_product( get_the_ID() );
	$live    = get_term_by( 'slug', TFC_LIVE, 'product_cat' );
	if ( ! $product || ! $live ) return false;
	foreach ( wc_get_product_term_ids( $product->get_parent_id() ?: $product->get_id(), 'product_cat' ) as $id ) {
		if ( $id === $live->term_id || term_is_ancestor_of( $live, $id, 'product_cat' ) ) return true;
	}
	return false;
}

// Most specific category name for the small label on product cards.
function tfc_product_category_label( $product ) {
	$terms = get_the_terms( $product->get_id(), 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) return '';
	usort( $terms, fn( $a, $b ) => count( get_ancestors( $b->term_id, 'product_cat' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat' ) ) );
	return $terms[0]->name;
}

add_filter( 'loop_shop_per_page', fn() => 24 );
add_filter( 'woocommerce_output_related_products_args', fn( $args ) => array_merge( $args, [ 'posts_per_page' => 4, 'columns' => 4 ] ) );

// Card badges (top-left over the photo) and the category label above the title.
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
add_action( 'woocommerce_before_shop_loop_item_title', function () {
	global $product;
	$badges = [];
	if ( ! $product->is_in_stock() ) $badges[] = '<span class="badge badge--muted">Sold out</span>';
	elseif ( $product->is_on_sale() ) $badges[] = '<span class="badge badge--sale">Sale</span>';
	if ( tfc_is_live( $product ) ) $badges[] = '<span class="badge badge--live">Live</span>';
	if ( $badges ) echo '<span class="card-badges">' . implode( '', $badges ) . '</span>';
}, 9 );
add_action( 'woocommerce_shop_loop_item_title', function () {
	global $product;
	$label = tfc_product_category_label( $product );
	if ( $label ) echo '<span class="card-cat">' . esc_html( $label ) . '</span>';
}, 5 );

// Card button: "Add to cart", "Choose size" for products with sizes, a disabled "Out of stock" otherwise.
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) return 'Out of stock';
	return $product->is_type( 'variable' ) ? 'Choose size' : ( $product->is_type( 'simple' ) ? 'Add to cart' : $text );
}, 10, 2 );
add_filter( 'woocommerce_loop_add_to_cart_link', function ( $html, $product ) {
	return $product->is_in_stock() ? $html : '<span class="button button--disabled" aria-disabled="true">Out of stock</span>';
}, 10, 2 );

// Products without a photo get a drawn placeholder that suits them, never a broken image.
add_filter( 'woocommerce_placeholder_img_src', function () {
	global $product;
	$kind = 'supplies';
	if ( $product instanceof WC_Product ) {
		$live = tfc_is_live( $product );
		$ids  = wc_get_product_term_ids( $product->get_parent_id() ?: $product->get_id(), 'product_cat' );
		$coral = get_term_by( 'slug', 'corals', 'product_cat' );
		$is_coral = $coral && array_filter( $ids, fn( $id ) => $id === $coral->term_id || term_is_ancestor_of( $coral, $id, 'product_cat' ) );
		$kind = $is_coral ? 'coral' : ( $live ? 'fish' : 'supplies' );
	}
	return get_theme_file_uri( "assets/placeholder-$kind.svg" );
} );

// Product page: livestock shipping note, then reassurance under the add-to-cart button.
add_action( 'woocommerce_single_product_summary', function () {
	if ( ! tfc_is_live() ) return;
	printf( '<div class="live-note">%s<div><strong>Live animal: ships overnight, Monday–Wednesday.</strong> Covered by our <a href="%s">Live Arrival Guarantee</a>.</div></div>',
		tfc_icon( 'shield' ), esc_url( home_url( '/shipping-guarantee/' ) ) );
}, 25 );
add_action( 'woocommerce_single_product_summary', function () {
	$live = tfc_is_live();
	echo '<ul class="product-assurance">'
		. '<li>' . tfc_icon( 'truck' ) . ( $live ? 'Packed to order with heat or cold packs for the season' : 'Ships any business day' ) . '</li>'
		. '<li>' . tfc_icon( $live ? 'eye' : 'shield' ) . ( $live ? 'Eating and settled in our systems before it ships' : 'Products we use on our own reefs' ) . '</li>'
		. '<li>' . tfc_icon( 'chat' ) . 'Questions? <a href="' . esc_url( home_url( '/contact/' ) ) . '">Ask a reef keeper</a></li>'
		. '</ul>';
}, 35 );

// Shop pages: the theme's woocommerce.php places the result count and sort menu in its own toolbar,
// and the product page shows "Sale" in the price instead of a floating flash.
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
add_filter( 'woocommerce_breadcrumb_defaults', fn( $d ) => array_merge( $d, [ 'delimiter' => '<span class="crumb-sep">/</span>', 'wrap_before' => '<nav class="breadcrumb" aria-label="Breadcrumb">', 'wrap_after' => '</nav>' ] ) );

// Home page rows show what can be bought today, and only products with a real photo.
add_filter( 'woocommerce_shortcode_products_query', function ( $args ) {
	if ( is_front_page() ) {
		$args['meta_query'][] = [ 'key' => '_stock_status', 'value' => 'instock' ];
		// A real photo, or a photo link (`_tfc_img_url`, used by the public demo).
		$args['meta_query'][] = [ 'relation' => 'OR', [ 'key' => '_thumbnail_id', 'compare' => 'EXISTS' ], [ 'key' => '_tfc_img_url', 'compare' => 'EXISTS' ] ];
	}
	return $args;
} );

// Sidebar category tree: top levels always, the branch you're in expanded.
function tfc_shop_nav( $current ) {
	$active = $current ? array_merge( [ $current->term_id ], get_ancestors( $current->term_id, 'product_cat' ) ) : [];
	echo '<nav class="shop-nav" aria-label="Shop categories"><span class="eyebrow">Browse</span><ul>';
	foreach ( tfc_top_categories() as $t ) tfc_shop_nav_item( $t, $active, $current );
	echo '</ul></nav>';
}
function tfc_shop_nav_item( $t, $active, $current ) {
	$open = in_array( $t->term_id, $active, true );
	$kids = $open ? tfc_child_categories( $t->term_id ) : [];
	printf( '<li%s><a href="%s"%s>%s</a>', $open ? ' class="is-open"' : '', esc_url( get_term_link( $t ) ), $current && $current->term_id === $t->term_id ? ' aria-current="page"' : '', esc_html( $t->name ) );
	if ( $kids ) {
		echo '<ul>';
		foreach ( $kids as $k ) tfc_shop_nav_item( $k, $active, $current );
		echo '</ul>';
	}
	echo '</li>';
}

// ---- Header cart ---------------------------------------------------------------------------------

function tfc_cart_link() {
	$count = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$url   = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
	return '<a class="header-icon cart-link" href="' . esc_url( $url ) . '" aria-label="Cart, ' . $count . ' items">' . tfc_icon( 'bag' )
		. '<span class="cart-count' . ( $count ? '' : ' is-empty' ) . '">' . $count . '</span></a>';
}
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['a.cart-link'] = tfc_cart_link();
	return $fragments;
} );

function tfc_cat_url( $slug ) {
	$url = get_term_link( $slug, 'product_cat' );
	return is_wp_error( $url ) ? ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ) : $url;
}

// [tfc_contact] — contact details from the Customizer, used on the Contact page.
add_shortcode( 'tfc_contact', function () {
	$rows = [
		[ 'phone', 'Call', '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', tfc_mod( 'phone' ) ) ) . '">' . esc_html( tfc_mod( 'phone' ) ) . '</a>' ],
		[ 'mail', 'Email', '<a href="mailto:' . esc_attr( tfc_mod( 'email' ) ) . '">' . esc_html( tfc_mod( 'email' ) ) . '</a>' ],
		[ 'pin', 'Visit', nl2br( esc_html( tfc_mod( 'address' ) ) ) ],
		[ 'clock', 'Hours', nl2br( esc_html( tfc_mod( 'hours' ) ) ) ],
	];
	$html = '<div class="contact-cards">';
	foreach ( $rows as [ $icon, $label, $value ] ) $html .= '<div class="contact-card">' . tfc_icon( $icon ) . '<span class="eyebrow">' . $label . '</span><p>' . $value . '</p></div>';
	return $html . '</div>';
} );

// [tfc_contact_form] — a plain form on the Contact page. Mails the owner directly with wp_mail();
// no form plugin needed for three fields.
const TFC_CONTACT_TO = [ 'ralgiere@att.net', 'azpilot@gmail.com' ];
add_shortcode( 'tfc_contact_form', function () {
	$sent = false;
	$error = '';
	if ( isset( $_POST['tfc_contact_nonce'] ) && wp_verify_nonce( $_POST['tfc_contact_nonce'], 'tfc_contact' ) ) {
		if ( ! empty( $_POST['website'] ) ) { // honeypot: bots fill hidden fields, people don't
			$sent = true;
		} else {
			$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
			$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
			$message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
			if ( $name === '' || ! is_email( $email ) || $message === '' ) {
				$error = 'Please fill in your name, a valid email and a message.';
			} else {
				$subject = 'New message from ' . $name . ' via ' . get_bloginfo( 'name' );
				$body    = "Name: $name\nEmail: $email\n\n$message";
				$sent    = wp_mail( TFC_CONTACT_TO, $subject, $body, [ 'Reply-To: ' . $name . ' <' . $email . '>' ] );
				if ( ! $sent ) $error = 'Something went wrong sending that. Please try again or email us directly.';
			}
		}
	}
	ob_start();
	if ( $sent ) : ?>
		<p class="form-success">Thanks — we'll get back to you soon.</p>
	<?php else : ?>
		<form class="contact-form" method="post">
			<?php wp_nonce_field( 'tfc_contact', 'tfc_contact_nonce' ); ?>
			<?php if ( $error ) : ?><p class="form-error"><?php echo esc_html( $error ); ?></p><?php endif; ?>
			<p class="tfc-hp"><label>Leave this field blank<input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
			<p><label for="tfc-name">Name</label><input id="tfc-name" type="text" name="name" required value="<?php echo esc_attr( wp_unslash( $_POST['name'] ?? '' ) ); ?>"></p>
			<p><label for="tfc-email">Email</label><input id="tfc-email" type="email" name="email" required value="<?php echo esc_attr( wp_unslash( $_POST['email'] ?? '' ) ); ?>"></p>
			<p><label for="tfc-message">Message</label><textarea id="tfc-message" name="message" rows="5" required><?php echo esc_textarea( wp_unslash( $_POST['message'] ?? '' ) ); ?></textarea></p>
			<button type="submit" class="btn btn--coral">Send message</button>
		</form>
	<?php endif;
	return ob_get_clean();
} );

// Page banners use the page's featured image, else the photo chosen when the page was created.
function tfc_page_banner_image( $post_id ) {
	return get_the_post_thumbnail_url( $post_id, 'full' ) ?: tfc_photo( get_post_meta( $post_id, 'tfc_photo', true ) ?: 'reef', 1800 );
}
