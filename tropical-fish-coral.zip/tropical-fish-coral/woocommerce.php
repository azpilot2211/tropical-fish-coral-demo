<?php
get_header();

if ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( is_singular( 'product' ) ? 'single' : 'archive' ) ) :
	// Elementor Pro's Theme Builder template is showing.
elseif ( is_singular( 'product' ) ) :
	while ( have_posts() ) :
		the_post(); ?>
		<div class="wrap single-wrap">
			<?php woocommerce_breadcrumb(); ?>
			<?php wc_get_template_part( 'content', 'single-product' ); ?>
		</div>
	<?php endwhile;

else :
	$term  = is_product_category() ? get_queried_object() : null;
	$title = $term ? $term->name : ( is_search() ? sprintf( 'Results for “%s”', get_search_query() ) : woocommerce_page_title( false ) );
	$desc  = $term ? $term->description : ( is_search() ? '' : 'Livestock, dry goods and reef supplies, all in one place.' );
	$total = (int) $GLOBALS['wp_query']->found_posts;
	$chips = $term ? tfc_child_categories( $term->term_id ) : ( is_search() ? [] : tfc_top_categories() );
	?>
	<section class="wrap shop-banner">
		<div class="shop-banner__text">
			<?php woocommerce_breadcrumb(); ?>
			<h1><?php echo esc_html( $title ); ?></h1>
			<?php if ( $desc ) : ?><p><?php echo esc_html( wp_strip_all_tags( $desc ) ); ?></p><?php endif; ?>
			<span class="shop-banner__count"><?php echo esc_html( sprintf( _n( '%d product', '%d products', $total ), $total ) ); ?></span>
		</div>
		<div class="shop-banner__media">
			<img src="<?php echo esc_url( $term ? tfc_category_image( $term, 1100, 700 ) : tfc_photo( 'reef', 1100, 700 ) ); ?>" alt="">
		</div>
	</section>

	<?php if ( $chips ) : ?>
		<nav class="wrap subcats" aria-label="<?php echo esc_attr( $title ); ?> categories">
			<?php foreach ( $chips as $chip ) printf( '<a href="%s">%s</a>', esc_url( get_term_link( $chip ) ), esc_html( $chip->name ) ); ?>
		</nav>
	<?php endif; ?>

	<div class="wrap shop-layout">
		<aside class="shop-sidebar"><?php tfc_shop_nav( $term ); ?></aside>
		<div class="shop-main">
			<?php if ( woocommerce_product_loop() ) :
				do_action( 'woocommerce_before_shop_loop' ); ?>
				<div class="shop-toolbar"><?php woocommerce_result_count(); woocommerce_catalog_ordering(); ?></div>
				<?php
				woocommerce_product_loop_start();
				while ( have_posts() ) {
					the_post();
					do_action( 'woocommerce_shop_loop' );
					wc_get_template_part( 'content', 'product' );
				}
				woocommerce_product_loop_end();
				do_action( 'woocommerce_after_shop_loop' );
			else : ?>
				<div class="empty-state">
					<?php echo tfc_icon( 'drop' ); ?>
					<h2>Nothing here yet</h2>
					<p>New livestock and supplies arrive every week. Try another category, or check back soon.</p>
					<a class="btn btn--dark" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">Browse the shop</a>
				</div>
			<?php endif; ?>
		</div>
	</div>
<?php endif;

get_footer();
