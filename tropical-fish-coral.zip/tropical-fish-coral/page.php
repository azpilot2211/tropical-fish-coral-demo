<?php
get_header();
while ( have_posts() ) :
	the_post();
	// Cart, checkout and account pages get a compact header so the form stays front and centre.
	$compact = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
	$eyebrow = [ 'about' => 'Our story', 'contact' => 'Get in touch', 'faq' => 'Help', 'shipping-guarantee' => 'Help' ][ get_post_field( 'post_name' ) ] ?? get_bloginfo( 'name' );
	?>
	<section class="page-banner<?php echo $compact ? ' page-banner--compact' : ''; ?>">
		<?php if ( ! $compact ) : ?>
			<img class="page-banner__img" src="<?php echo esc_url( tfc_page_banner_image( get_the_ID() ) ); ?>" alt="">
		<?php endif; ?>
		<div class="wrap page-banner__inner">
			<?php if ( ! $compact ) : ?><span class="eyebrow eyebrow--light"><?php echo esc_html( $eyebrow ); ?></span><?php endif; ?>
			<h1><?php the_title(); ?></h1>
		</div>
	</section>
	<div class="wrap page-body<?php echo $compact ? ' page-body--wide' : ''; ?>">
		<article class="prose"><?php the_content(); ?></article>
	</div>
<?php endwhile;
get_footer();
