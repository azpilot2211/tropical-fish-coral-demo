<?php
/**
 * Store structure: the category tree (with keywords the Supplier Import plugin uses to file
 * products), category photos, and the starter pages. Created once, then left for the owner to edit.
 */
defined( 'ABSPATH' ) || exit;

// slug => [ name, importer keywords, photo key, description, children ]
const TFC_TREE = [
	'live-goods' => [ 'Live Goods', '', 'reef', 'Hand-picked fish, corals and invertebrates, observed in our systems before they ship.', [
		'fish' => [ 'Fish', 'fish', 'fish', 'Reef-safe community fish, show-stopping centerpieces and everything in between.', [
			'angelfish'          => [ 'Angelfish', 'angel, centropyge, pomacanthus, holacanthus, genicanthus' ],
			'tangs'              => [ 'Tangs & Surgeonfish', 'tang, surgeon, naso, zebrasoma, acanthurus, hippo, tomini, sailfin, ctenochaetus' ],
			'clownfish'          => [ 'Clownfish', 'clown, amphiprion, premnas, ocellaris, percula, maroon' ],
			'wrasses'            => [ 'Wrasses', 'wrasse, coris, halichoeres, cirrhilabrus, paracheilinus, pseudocheilinus, fairy, flasher, six line, lunare, hogfish, leopard, cleaner wrasse' ],
			'gobies-blennies'    => [ 'Gobies & Blennies', 'goby, gobies, gobiodon, blenny, blennies, mandarin, dragonet, sleeper, jawfish, firefish, dartfish' ],
			'damsels-chromis'    => [ 'Damsels & Chromis', 'damsel, chromis, dascyllus, domino' ],
			'anthias-basslets'   => [ 'Anthias & Basslets', 'anthias, basslet, gramma, dottyback, pseudochromis, assessor' ],
			'butterflyfish'      => [ 'Butterflyfish', 'butterfly, butterflyfish, copperband, chaetodon, heniochus' ],
			'cardinalfish'       => [ 'Cardinalfish', 'cardinal' ],
			'hawkfish'           => [ 'Hawkfish', 'hawk' ],
			'rabbitfish-foxface' => [ 'Rabbitfish & Foxface', 'rabbit, foxface, siganus' ],
			'triggers-puffers'   => [ 'Triggers & Puffers', 'trigger, puffer, boxfish, cowfish, toby' ],
			'eels-predators'     => [ 'Eels & Predators', 'eel, moray, lion, lionfish, scorpion, grouper, frogfish' ],
		] ],
		'corals' => [ 'Corals', 'coral', 'corals', 'Aquacultured and wild colonies, frags and one-of-a-kind pieces, photographed as they are.', [
			'sps-corals'  => [ 'SPS Corals', 'sps, acropora, acro, montipora, monti, stylophora, pocillopora, seriatopora, birdsnest, millepora' ],
			'lps-corals'  => [ 'LPS Corals', 'lps, euphyllia, torch, hammer, frogspawn, acan, acanthastrea, blasto, favia, chalice, brain, duncan, scoly, trachyphyllia, goniopora, cyphastrea, micromussa, bubble coral, plate coral' ],
			'soft-corals' => [ 'Soft Corals', 'soft, softie, leather, sinularia, sarcophyton, toadstool, kenya tree, xenia, star polyp, gsp, clove, gorgonian, capnella' ],
			'zoanthids'   => [ 'Zoanthids & Palys', 'zoa, zoanthid, paly, palythoa' ],
			'mushrooms'   => [ 'Mushrooms', 'mushroom, rhodactis, ricordea, discosoma, yuma' ],
			'anemones'    => [ 'Anemones', 'anemone, bubble tip, bta, sebae, carpet' ],
			'frag-packs'  => [ 'Frag Packs', 'frag pack' ],
		] ],
		'invertebrates' => [ 'Invertebrates', 'invert, invertebrate', 'inverts', 'The cleanup crew and the characters: shrimp, crabs, snails, stars and clams.', [
			'shrimp'           => [ 'Shrimp', 'shrimp' ],
			'crabs'            => [ 'Crabs', 'crab' ],
			'snails'           => [ 'Snails', 'snail, conch, nassarius, turbo, trochus, cerith, nerite' ],
			'starfish-urchins' => [ 'Starfish & Urchins', 'star, starfish, linckia, urchin' ],
			'clams'            => [ 'Clams & Scallops', 'clam, tridacna, maxima, derasa, crocea, squamosa, scallop' ],
			'cleanup-crews'    => [ 'Cleanup Crews', 'cleanup, clean-up, crew' ],
		] ],
		'live-rock-sand' => [ 'Live Rock & Sand', 'live rock, rock, sand, substrate, rubble', 'rock', 'Cured rock and live sand to seed a new system or add biology to an established one.' ],
	] ],
	'dry-goods' => [ 'Dry Goods', '', 'dry', 'Foods, salt, supplements and water care: everything your livestock uses up.', [
		'foods'          => [ 'Fish & Coral Food', 'food, pellet, flake, frozen, mysis, brine, nori, seaweed, wafer, feed, reef roids, coral food, spectrum' ],
		'salt-additives' => [ 'Salt & Additives', 'salt, additive, calcium, alkalinity, magnesium, trace, supplement, buffer, kalk, iodine, strontium, amino' ],
		'test-kits'      => [ 'Test Kits', 'test, kit, refractometer, hydrometer, salinity' ],
		'water-care'     => [ 'Water Care & Medications', 'conditioner, dechlorinator, bacteria, medication, treatment, remover, clarifier, ick, ich, parasite, cure, aquarium clner, waste' ],
		'filter-media'   => [ 'Filter Media', 'media, carbon, gfo, bio ball, filter floss, phosphate, purigen, media bag, ceramic' ],
	] ],
	'supplies' => [ 'Supplies', '', 'supplies', 'Aquariums, lighting, flow and filtration: the equipment that keeps a reef running.', [
		'aquariums'         => [ 'Aquariums & Stands', 'aquarium, tank, stand, cabinet, sump, all-in-one, aio' ],
		'filters'           => [ 'Filters', 'filter, canister, hang on, hob, filter sock, roller' ],
		'protein-skimmers'  => [ 'Protein Skimmers', 'skimmer' ],
		'lighting'          => [ 'Lighting', 'light, lighting, led, lamp, fixture, bulb, t5' ],
		'pumps'             => [ 'Pumps & Powerheads', 'pump, powerhead, wavemaker, gyre, flow' ],
		'heaters-chillers'  => [ 'Heaters & Chillers', 'heater, hter, chiller, thermometer' ],
		'reactors-dosing'   => [ 'Reactors & Dosing', 'reactor, doser, dosing, controller, top off, ato' ],
		'tools-maintenance' => [ 'Tools & Maintenance', 'tool, net, scraper, siphon, magnet, glove, tweezer, tong, algae cleaner' ],
		'merchandise'       => [ 'Merchandise', 'merch, merchandise, shirt, sticker, hat, gift card' ],
	] ],
];

// Photography (Unsplash licence: free for commercial use). Swap any category's photo by giving the
// category a thumbnail under Products → Categories.
const TFC_PHOTOS = [
	'reef'     => 'photo-1694661641480-d4e76d6bead3', // mixed LPS reef tank
	'fish'     => 'photo-1544552866-d3ed42536cfd',    // clownfish in anemone
	'fish-alt' => 'photo-1524704796725-9fc3044a58b2', // tang on blue
	'corals'   => 'photo-1682045324088-ddaf4da1df35', // coral frags on black
	'zoas'     => 'photo-1631475755115-ca227d221b91', // zoanthid close-up
	'inverts'  => 'photo-1703221291880-303643093c22', // blue linckia star on coral
	'rock'     => 'photo-1490544270497-a6044db8db90', // rockwork, anemones and sand
	'supplies' => 'photo-1583949184685-33fda190a216', // nano reef on a desk
	'dry'      => 'photo-1546026423-cc4642628d2b',    // reef tank, fed
	'mandarin' => 'photo-1550016681-60a1d9d23bf7',    // mandarin dragonet
	'visitor'  => 'photo-1585404544089-b386c0723dd4', // visitor at a big aquarium
];

function tfc_photo( $key, $w = 1200, $h = 0 ) {
	$id = TFC_PHOTOS[ $key ] ?? TFC_PHOTOS['reef'];
	return "https://images.unsplash.com/$id?auto=format&fit=crop&q=72&w=$w" . ( $h ? "&h=$h" : '' );
}

// Create the categories and pages once per theme version. Existing ones are left alone, so owner
// edits (names, descriptions, photos) survive updates.
add_action( 'init', function () {
	if ( ! taxonomy_exists( 'product_cat' ) || get_option( 'tfc_setup' ) === TFC_VERSION ) return;
	tfc_create_terms( TFC_TREE, 0 );
	tfc_create_pages();
	tfc_migrate_wording();
	tfc_migrate_home_rows();
	tfc_migrate_contact_form();
	update_option( 'tfc_setup', TFC_VERSION );
}, 20 );

// The Contact page gains a mail form below the info cards (v2.6.0). Appended only if the page doesn't
// already have it, so a re-run, or an owner who added their own form, isn't duplicated.
function tfc_migrate_contact_form() {
	$p = get_page_by_path( 'contact' );
	if ( ! $p || strpos( $p->post_content, '[tfc_contact_form]' ) !== false ) return;
	wp_update_post( [ 'ID' => $p->ID, 'post_content' => wp_slash( $p->post_content . '<h2>Send us a message</h2>[tfc_contact_form]' ) ] );
}

// "tank" became "aquarium" in the starter copy (v2.2). Fixes pages and the Supplies blurb already saved, by exact
// phrase only, so anything the owner rewrote is left alone.
function tfc_migrate_wording() {
	$swap = [ 'our own tanks' => 'our own aquariums', 'favour tank-raised and aquacultured' => 'favour captive-bred and aquacultured', 'aquacultured and tank-raised stock' => 'aquacultured and captive-bred stock',
		'small amounts of tank water' => 'small amounts of aquarium water', 'into the tank.' => 'into the aquarium.', 'stocking a new tank' => 'stocking a new aquarium' ];
	foreach ( [ 'about', 'faq', 'contact' ] as $slug ) {
		$p = get_page_by_path( $slug );
		if ( ! $p ) continue;
		$new = strtr( $p->post_content, $swap );
		if ( $new !== $p->post_content ) wp_update_post( [ 'ID' => $p->ID, 'post_content' => wp_slash( $new ) ] );
	}
	$t = get_term_by( 'slug', 'supplies', 'product_cat' );
	if ( $t && strpos( $t->description, 'Tanks, lighting' ) === 0 ) wp_update_term( $t->term_id, 'product_cat', [ 'description' => 'Aquariums, lighting' . substr( $t->description, 15 ) ] );
}

// The home page's "New corals & frags" row became "Live goods" (v2.4.1), then both it and "Dry goods &
// supplies" became curated tickbox rows (live="1"/dry="1") instead of a category filter (v2.5.0), and
// "Dry goods & supplies" dropped from 8 items to 4 along the way (v2.4.1), so every row fits one line on
// desktop. Fixes the Home page already saved, by exact shortcode text only (every shape it's been across
// those versions, so an upgrade from any of them lands on the same final text), so a row the owner
// reworded or re-limited is left alone. Both the page content and, if the page was opened in Elementor,
// its block data (Elementor renders from that instead) are checked - with different swap text for each:
// WordPress writes post_content through wp_encode_ambiguous_ampersands() on save, turning "&" into
// "&amp;", but postmeta (Elementor's JSON) is stored exactly as written.
function tfc_migrate_home_rows() {
	$ancient_corals = 'eyebrow="Coral spotlight" title="New corals %1$s frags" category="corals" limit="4" link="corals"';
	$medium_live    = 'eyebrow="Fresh from the reef" title="Live goods" category="live-goods" limit="4" link="live-goods"';
	$new_live       = 'eyebrow="Fresh from the reef" title="Live goods" live="1" link="live-goods"';
	$ancient_dry    = 'eyebrow="Stock up" title="Dry goods %1$s supplies" category="dry-goods,supplies" limit="8" link="supplies"';
	$medium_dry     = 'eyebrow="Stock up" title="Dry goods %1$s supplies" category="dry-goods,supplies" limit="4" link="supplies"';
	$new_dry        = 'eyebrow="Stock up" title="Dry goods %1$s supplies" dry="1" link="supplies"';
	$content_swap = [
		sprintf( "[tfc_products $ancient_corals]", '&amp;' ) => "[tfc_products $new_live]",
		"[tfc_products $medium_live]"                        => "[tfc_products $new_live]",
		sprintf( "[tfc_products $ancient_dry]", '&amp;' )     => sprintf( "[tfc_products $new_dry]", '&amp;' ),
		sprintf( "[tfc_products $medium_dry]", '&amp;' )      => sprintf( "[tfc_products $new_dry]", '&amp;' ),
	];
	$elementor_swap = [
		sprintf( "[tfc_products $ancient_corals]", '&' ) => "[tfc_products $new_live]",
		"[tfc_products $medium_live]"                    => "[tfc_products $new_live]",
		sprintf( "[tfc_products $ancient_dry]", '&' )     => sprintf( "[tfc_products $new_dry]", '&' ),
		sprintf( "[tfc_products $medium_dry]", '&' )      => sprintf( "[tfc_products $new_dry]", '&' ),
	];
	$p = get_page_by_path( 'home' );
	if ( ! $p ) return;
	$new = strtr( $p->post_content, $content_swap );
	if ( $new !== $p->post_content ) wp_update_post( [ 'ID' => $p->ID, 'post_content' => wp_slash( $new ) ] );

	$data = json_decode( (string) get_post_meta( $p->ID, '_elementor_data', true ), true );
	if ( ! is_array( $data ) ) return;
	$changed = false;
	tfc_migrate_elementor_shortcodes( $data, $elementor_swap, $changed );
	if ( $changed ) update_post_meta( $p->ID, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
}

// Walks Elementor's block data (any depth, so a row the owner moved or nested differently is still found)
// and swaps a Shortcode widget's text when it's an exact match, so widgets the owner added are untouched.
function tfc_migrate_elementor_shortcodes( array &$node, array $swap, &$changed ) {
	if ( ( $node['widgetType'] ?? '' ) === 'shortcode' && isset( $node['settings']['shortcode'], $swap[ $node['settings']['shortcode'] ] ) ) {
		$node['settings']['shortcode'] = $swap[ $node['settings']['shortcode'] ];
		$changed = true;
	}
	foreach ( $node as &$child ) if ( is_array( $child ) ) tfc_migrate_elementor_shortcodes( $child, $swap, $changed );
}

function tfc_create_terms( array $tree, $parent ) {
	$order = 0;
	foreach ( $tree as $slug => $node ) {
		[ $name, $keywords, $photo, $desc, $children ] = $node + [ '', '', '', '', [] ];
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		$id   = $term ? $term->term_id : wp_insert_term( $name, 'product_cat', [ 'slug' => $slug, 'parent' => $parent, 'description' => $desc ] );
		if ( is_wp_error( $id ) ) continue;
		$id = is_array( $id ) ? $id['term_id'] : $id;
		// Categories the importer created earlier (e.g. Fish): put them in the tree and give them copy.
		if ( $term && ( $term->parent !== $parent || ( $desc && $term->description === '' ) ) ) {
			wp_update_term( $id, 'product_cat', [ 'parent' => $parent, 'description' => $term->description ?: $desc ] );
		}
		update_term_meta( $id, 'order', $order++ );
		if ( $keywords ) update_term_meta( $id, 'tfc_keywords', $keywords );
		if ( $photo ) update_term_meta( $id, 'tfc_photo', $photo );
		if ( $children ) tfc_create_terms( $children, $id );
	}
}

// Top-level shop categories in menu order (Live Goods, Dry Goods, Supplies, plus any the owner adds).
function tfc_top_categories() {
	$uncat = (int) get_option( 'default_product_cat' );
	return array_values( array_filter(
		get_terms( [ 'taxonomy' => 'product_cat', 'parent' => 0, 'hide_empty' => false ] ) ?: [],
		fn( $t ) => $t->term_id !== $uncat
	) );
}

function tfc_child_categories( $term_id ) {
	return get_terms( [ 'taxonomy' => 'product_cat', 'parent' => $term_id, 'hide_empty' => false ] ) ?: [];
}

// Photo for a category: its own thumbnail, else its (or its nearest parent's) theme photo, else the
// newest product photo in it, else the reef photo.
function tfc_category_image( $term, $w = 900, $h = 0 ) {
	$thumb = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
	if ( $thumb && ( $url = wp_get_attachment_image_url( $thumb, 'large' ) ) ) return $url;
	foreach ( array_merge( [ $term->term_id ], get_ancestors( $term->term_id, 'product_cat' ) ) as $id ) {
		$key = get_term_meta( $id, 'tfc_photo', true );
		if ( $key ) return tfc_photo( $key, $w, $h );
	}
	$recent = wc_get_products( [ 'category' => [ $term->slug ], 'limit' => 1, 'return' => 'ids', 'orderby' => 'date' ] );
	if ( $recent && ( $img = get_post_thumbnail_id( $recent[0] ) ) ) return wp_get_attachment_image_url( $img, 'large' );
	return tfc_photo( 'reef', $w, $h );
}

// ---- Starter pages ----------------------------------------------------------

function tfc_create_pages() {
	$pages = [
		'home'               => [ 'Home', 'reef', tfc_home_default_content() ],
		'specials'           => [ 'Specials', 'corals', '[tfc_products special="1" limit="48" empty="No specials right now. Check back soon."]' ],
		'about'              => [ 'About Us', 'visitor', tfc_page_about() ],
		'shipping-guarantee' => [ 'Shipping & Live Arrival Guarantee', 'fish-alt', tfc_page_shipping() ],
		'faq'                => [ 'Frequently Asked Questions', 'zoas', tfc_page_faq() ],
		'contact'            => [ 'Contact Us', 'reef', tfc_page_contact() ],
	];
	foreach ( $pages as $slug => [ $title, $photo, $content ] ) {
		if ( get_page_by_path( $slug ) ) continue;
		$id = wp_insert_post( [ 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title, 'post_content' => $content ] );
		if ( $id && ! is_wp_error( $id ) ) update_post_meta( $id, 'tfc_photo', $photo );
		if ( $id && $slug === 'home' ) {
			tfc_elementor_meta( $id, $content ); // opens in Elementor as separate blocks
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $id ); // Home is the front page (change it under Settings → Reading)
		}
	}
}

function tfc_page_about() {
	return <<<HTML
<p class="lead">We started Tropical Fish &amp; Coral because we were tired of opening boxes of stressed, underfed livestock. Every fish, coral and invertebrate we sell is one we would put in our own aquariums.</p>
<h2>How we work</h2>
<div class="tfc-steps">
<div><strong>Sourced with care</strong><p>We buy from collectors and aquaculture farms with good handling records, and we favour captive-bred and aquacultured animals whenever they are available.</p></div>
<div><strong>Observed before sale</strong><p>New arrivals rest in our holding systems, eating and settled, before they are listed. If an animal isn't thriving, it doesn't ship.</p></div>
<div><strong>Packed to order</strong><p>Livestock is bagged the day it ships, with oxygen, heat or cold packs for the season, in insulated boxes built for overnight travel.</p></div>
</div>
<h2>Everything else your reef needs</h2>
<p>Alongside livestock we stock the foods, salt, supplements, test kits and equipment we use ourselves, so you can build and run a whole system from one place, with real people to ask when you have a question.</p>
HTML;
}

function tfc_page_shipping() {
	return <<<HTML
<p class="lead">Live animals are shipped overnight so they spend as little time in the box as possible. Here is exactly how it works.</p>
<h2>When live goods ship</h2>
<ul>
<li>Fish, corals and invertebrates ship <strong>Monday to Wednesday</strong> by overnight service, so nothing sits in a depot over a weekend.</li>
<li>Orders placed Thursday through Sunday ship the following Monday.</li>
<li>In extreme heat or cold we may hold an order for a better day. We will always tell you first.</li>
</ul>
<h2>Dry goods and supplies</h2>
<p>Foods, salt, test kits and equipment ship on any business day by ground service. Orders with both live and dry items ship together on the next live shipping day unless you ask us to split them.</p>
<h2>Shipping costs</h2>
<p>Shipping is calculated at checkout from your state and the weight of your order, with separate rates for live goods and dry goods.</p>
<h2>Live Arrival Guarantee</h2>
<p>If an animal arrives dead, we will refund or replace it. To make a claim:</p>
<ol>
<li>Be home to receive the delivery on the scheduled day.</li>
<li>Within <strong>2 hours of delivery</strong>, email us a clear photo of the animal in its unopened bag.</li>
<li>Include your order number and your water parameters (salinity and temperature).</li>
</ol>
<p class="note">The guarantee covers arrival only. It does not cover losses after acclimation, or orders refused or delayed because of an incorrect address.</p>
HTML;
}

function tfc_page_faq() {
	$items = [
		'How do you choose which animals to sell?' => 'We buy from suppliers with good collection and handling practices, favour aquacultured and captive-bred stock, and only list animals that are eating and settled in our systems.',
		'What days do you ship livestock?' => 'Monday to Wednesday, overnight. Orders placed later in the week ship the following Monday so animals are never stuck in transit over a weekend.',
		'What if something arrives dead?' => 'Our Live Arrival Guarantee covers it. Send a photo of the animal in the unopened bag within 2 hours of delivery and we will refund or replace it. See the Shipping &amp; Live Arrival Guarantee page for details.',
		'How should I acclimate new arrivals?' => 'Float the sealed bag for 15 minutes to match temperature, then slowly add small amounts of aquarium water to the bag over 30 to 45 minutes before netting the animal into the aquarium. Don\'t add the shipping water to your aquarium.',
		'Are your corals photographed as sold?' => 'Colonies and one-of-a-kind pieces are shown as the actual piece. Frags and common corals may use a representative photo; the size is listed on each product.',
		'Do you ship everywhere?' => 'Dry goods and supplies ship to most states. Live goods can\'t go to every state; if we can\'t ship livestock to your address, checkout will tell you before you pay.',
		'Can I combine live and dry items in one order?' => 'Yes. Mixed orders ship together on the next live shipping day. Ask us if you would rather have the dry items sent sooner.',
	];
	$html = '<p class="lead">Can\'t find your answer? <a href="/contact/">Get in touch</a>, and a reef keeper will reply.</p><div class="tfc-faq">';
	foreach ( $items as $q => $a ) $html .= "<details><summary>$q</summary><p>$a</p></details>";
	return $html . '</div>';
}

function tfc_page_contact() {
	return '<p class="lead">Questions about an order, stocking a new aquarium or keeping something alive? We\'re reef keepers too, and happy to help.</p>[tfc_contact]<h2>Send us a message</h2>[tfc_contact_form]';
}
