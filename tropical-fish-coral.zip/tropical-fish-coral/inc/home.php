<?php
// The home page as building blocks. Every section is a shortcode, and the Home page (a normal page in
// Pages) is just those shortcodes, so in Elementor each one is a block you can move, delete or reword
// (its text lives in the shortcode's quotes), with any Elementor widgets added between them.
// A block whose product list is empty (no featured products yet, nothing on sale) shows nothing.
defined( 'ABSPATH' ) || exit;

// The starter Home page, in order. Also what the front page shows when its page is empty.
function tfc_home_default_content() {
	return implode( "\n\n", [
		'[tfc_hero]',
		'[tfc_categories]',
		'[tfc_products eyebrow="Handpicked" title="Featured products" featured="1" link="shop" link_text="Browse everything"]',
		'[tfc_products eyebrow="Just landed" title="New arrivals" new="1" link="new"]',
		'[tfc_products eyebrow="Save on reef essentials" title="Specials" special="1" link="specials"]',
		'[tfc_story]',
		'[tfc_products eyebrow="Fresh from the reef" title="Live goods" live="1" link="live-goods"]',
		'[tfc_products eyebrow="Stock up" title="Dry goods & supplies" dry="1" link="supplies"]',
		'[tfc_shipping]',
	] );
}

// True while a page is being edited in Elementor (the pinned scroll hero is shown as a plain screen there).
function tfc_in_elementor_editor() {
	if ( ! class_exists( '\Elementor\Plugin' ) ) return false;
	$p = \Elementor\Plugin::$instance;
	return ( $p->editor && $p->editor->is_edit_mode() ) || ( $p->preview && $p->preview->is_preview_mode() );
}

// A link written in a shortcode: 'shop', 'new' (the shop, newest first), a page or category slug, a full address, or a /path.
function tfc_home_link( $to ) {
	$to = trim( (string) $to );
	if ( $to === '' ) return '';
	if ( $to === 'shop' ) return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
	if ( preg_match( '#^(https?:)?//#', $to ) ) return $to;
	if ( $to === 'new' ) return add_query_arg( 'orderby', 'date', tfc_home_link( 'shop' ) );
	if ( $to[0] === '/' ) return home_url( $to );
	if ( get_page_by_path( $to ) ) return get_permalink( get_page_by_path( $to ) );
	return tfc_cat_url( $to );
}

// shortcode_atts() with the text decoded once: WordPress can turn & in a shortcode into &#038;.
function tfc_home_atts( $defaults, $atts, $tag ) {
	return array_map( fn( $v ) => is_string( $v ) ? html_entity_decode( $v, ENT_QUOTES, "UTF-8" ) : $v, shortcode_atts( $defaults, $atts, $tag ) );
}

// "Title|Text" -> [ Title, Text ].
function tfc_home_pair( $s ) {
	return array_pad( array_map( 'trim', explode( '|', (string) $s, 2 ) ), 2, '' );
}

// "*word*" in a heading becomes the italic accent.
function tfc_home_heading( $s ) {
	return preg_replace( '/\*(.+?)\*/', '<em>$1</em>', esc_html( $s ) );
}

// Wraps each word of a heading (already escaped, and possibly containing one <em>…</em> spanning
// several words) in its own span for a word-by-word entrance animation, each keeping the italic
// style if its word was inside it.
function tfc_home_hero_words( $words ) {
	$in_em = false;
	$out   = [];
	foreach ( $words as $i => $word ) {
		if ( strpos( $word, '<em>' ) !== false ) $in_em = true;
		$text  = str_replace( [ '<em>', '</em>' ], '', $word );
		$out[] = '<span class="hero-word" style="--i:' . ( $i + 1 ) . '">' . ( $in_em ? "<em>$text</em>" : $text ) . '</span>';
		if ( strpos( $word, '</em>' ) !== false ) $in_em = false;
	}
	return implode( ' ', $out );
}

// [tfc_hero]: a looping, autoplaying video hero, no playback controls. The headline rises in word
// by word on load, and a facts strip runs along the bottom edge.
add_shortcode( 'tfc_hero', function ( $atts ) {
	$a = tfc_home_atts( [
		'kicker'  => tfc_mod( 'hero_kicker' ),
		'title'   => tfc_mod( 'hero_title' ),
		'text'    => tfc_mod( 'hero_text' ),
		'video'   => get_theme_file_uri( 'assets/hero-video.mp4' ),
		'poster'  => get_theme_file_uri( 'assets/hero-video.jpg' ),
		'fact1'   => 'Overnight|Live goods ship Monday to Wednesday, so nothing waits in a depot.',
		'fact2'   => 'Observed|Every animal is settled and eating in our systems before it’s sold.',
		'fact3'   => 'Guaranteed|Live arrival on every order.',
		'button1' => 'Shop livestock|live-goods',
		'button2' => 'Shop supplies|supplies',
		'button3' => 'Specials|specials',
		'button4' => 'New arrivals|new',
	], $atts, 'tfc_hero' );
	// "*word*" in the heading becomes the italic accent; with none, the last word does.
	$title = tfc_home_heading( $a['title'] );
	if ( strpos( $title, '<em>' ) === false ) $title = preg_replace( '/(\S+)$/', '<em>$1</em>', $title );
	$words = preg_split( '/\s+/', trim( $title ) );
	ob_start();
	?>
	<section class="hero" data-hero>
		<div class="hero-stage" style="--word-count: <?php echo count( $words ); ?>">
			<video class="hero-video" src="<?php echo esc_url( $a['video'] ); ?>" poster="<?php echo esc_url( $a['poster'] ); ?>" muted loop playsinline preload="none" aria-hidden="true"></video>
			<?php if ( ! tfc_in_elementor_editor() ) : // Before first paint: start the download for visitors who'll get autoplay; for everyone
			// else, drop the loading bar so it never flashes for a video that's never going to play (theme.js
			// reads the .can-autoplay class it sets here to decide whether to call video.play()). ?>
				<script>if (!matchMedia('(prefers-reduced-motion: reduce)').matches && !navigator.connection?.saveData) { const v = document.currentScript.previousElementSibling; v.closest('.hero').classList.add('can-autoplay'); v.preload = 'auto'; } else { document.currentScript.closest('.hero-stage').querySelector('.hero-loading')?.remove(); }</script>
			<?php endif; ?>
			<div class="hero-loading" aria-hidden="true"></div>
			<div class="wrap hero-copy">
				<span class="eyebrow eyebrow--light hero-word" style="--i:0"><?php echo esc_html( $a['kicker'] ); ?></span>
				<h1><?php echo tfc_home_hero_words( $words ); ?></h1>
				<p class="lead"><?php echo esc_html( $a['text'] ); ?></p>
				<div class="hero-actions">
					<?php // Each button has its own bar colour (.hero-btn--1..4) and icon; on phones the short label shows ("Shop livestock" -> "Livestock", "New arrivals" -> "New").
					foreach ( [ 'button1' => [ 1, 'fish' ], 'button2' => [ 2, 'wrench' ], 'button3' => [ 3, 'tag' ], 'button4' => [ 4, 'spark' ] ] as $k => [ $n, $icon ] ) : [ $label, $to ] = tfc_home_pair( $a[ $k ] ); if ( $label === '' ) continue; ?>
						<a class="btn hero-btn hero-btn--<?php echo $n; ?>" href="<?php echo esc_url( tfc_home_link( $to ) ); ?>"><?php echo tfc_icon( $icon ); ?><span class="hero-btn__full"><?php echo esc_html( $label ); ?></span><span class="hero-btn__short" aria-hidden="true"><?php echo esc_html( ucfirst( preg_replace( '/^Shop\s+|\s+arrivals$/i', '', $label ) ) ); ?></span></a>
					<?php endforeach; ?>
				</div>
			</div>
			<ul class="hero-facts">
				<?php foreach ( [ 'fact1', 'fact2', 'fact3' ] as $k ) : [ $h, $t ] = tfc_home_pair( $a[ $k ] ); ?>
					<li><strong><?php echo esc_html( $h ); ?></strong><span><?php echo esc_html( $t ); ?></span></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );

// [tfc_categories]: the category tiles and the dry-goods strip.
add_shortcode( 'tfc_categories', function ( $atts ) {
	$a = tfc_home_atts( [
		'eyebrow'     => 'Shop the reef',
		'title'       => 'Find your aquarium needs',
		'link_text'   => 'Browse everything',
		'tiles'       => 'corals,fish,invertebrates,live-rock-sand,supplies', // up to five category slugs, big tile first
		'dry_eyebrow' => 'Dry goods',
		'dry_title'   => 'Foods, salt, test kits & water care',
		'dry_button'  => 'Shop dry goods',
	], $atts, 'tfc_categories' );
	$count = function ( $term ) {
		$n = (int) get_term_meta( $term->term_id, 'product_count_product_cat', true );
		return $n ? sprintf( _n( '%d product', '%d products', $n ), $n ) : 'Coming soon';
	};
	$classes = [ 'bento__a', 'bento__b', 'bento__c', 'bento__d', 'bento__e' ];
	$dry     = get_term_by( 'slug', 'dry-goods', 'product_cat' );
	ob_start();
	?>
	<section class="section section--tight">
		<div class="wrap">
			<div class="section-head">
				<div><span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><h2><?php echo esc_html( $a['title'] ); ?></h2></div>
				<a class="link-arrow" href="<?php echo esc_url( tfc_home_link( 'shop' ) ); ?>"><?php echo esc_html( $a['link_text'] ); ?> <?php echo tfc_icon( 'arrow' ); ?></a>
			</div>
			<div class="bento">
				<?php foreach ( array_slice( array_filter( array_map( 'trim', explode( ',', $a['tiles'] ) ) ), 0, 5 ) as $i => $slug ) :
					$t = get_term_by( 'slug', $slug, 'product_cat' );
					if ( ! $t ) continue;
					$big = $i === 0; ?>
					<a class="cat-tile <?php echo $classes[ $i ]; ?>" href="<?php echo esc_url( get_term_link( $t ) ); ?>">
						<img src="<?php echo esc_url( tfc_category_image( $t, $big ? 1100 : 700, $big ? 1100 : 560 ) ); ?>" alt="" loading="lazy">
						<span class="cat-tile__body">
							<span class="cat-tile__count"><?php echo esc_html( $count( $t ) ); ?></span>
							<span class="cat-tile__name"><?php echo esc_html( $t->name ); ?></span>
						</span>
						<span class="cat-tile__go"><?php echo tfc_icon( 'arrow' ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
			<?php if ( $dry ) : ?>
				<div class="dry-strip">
					<div class="dry-strip__copy">
						<span class="eyebrow"><?php echo esc_html( $a['dry_eyebrow'] ); ?></span>
						<h3><?php echo esc_html( html_entity_decode( $a['dry_title'] ) ); ?></h3>
						<p><?php echo esc_html( $dry->description ); ?></p>
						<a class="btn btn--dark" href="<?php echo esc_url( get_term_link( $dry ) ); ?>"><?php echo esc_html( $a['dry_button'] ); ?></a>
					</div>
					<ul class="dry-strip__links">
						<?php foreach ( tfc_child_categories( $dry->term_id ) as $kid ) : ?>
							<li><a href="<?php echo esc_url( get_term_link( $kid ) ); ?>"><span><?php echo esc_html( $kid->name ); ?></span><?php echo tfc_icon( 'arrow' ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );

// [tfc_products]: a heading and a row of products. Either the products ticked on their edit screen
// (featured="1", new="1", special="1", live="1" or dry="1"; at most limit, default 4), or a category
// (category="slug,slug") or the on-sale ones (on_sale="1"). link="slug|shop|new|/path"; empty="…" is shown when there are none.
add_shortcode( 'tfc_products', function ( $atts ) {
	$a = tfc_home_atts( [ 'eyebrow' => '', 'title' => '', 'category' => '', 'featured' => '', 'new' => '', 'special' => '', 'live' => '', 'dry' => '', 'on_sale' => '', 'limit' => TFC_HOME_LIMIT, 'link' => '', 'link_text' => 'View all', 'empty' => '' ], $atts, 'tfc_products' );
	foreach ( array_keys( TFC_HOME_FLAGS ) as $flag ) if ( $a[ $flag ] ) $ticked = $flag; // the products ticked on their edit screen
	if ( isset( $ticked ) ) {
		$products = tfc_home_flag_grid( $ticked, $a['limit'] );
	} else {
		$args = sprintf( 'limit="%d" columns="4" orderby="date" order="DESC"', max( 1, (int) $a['limit'] ) );
		if ( $a['category'] !== '' ) $args .= sprintf( ' category="%s" cat_operator="IN"', esc_attr( $a['category'] ) );
		if ( $a['on_sale'] ) $args .= ' on_sale="true"';
		$products = do_shortcode( "[products $args]" );
	}
	if ( strpos( $products, '<li' ) === false ) return $a['empty'] === '' ? '' : '<section class="section"><div class="wrap"><p class="lead">' . esc_html( $a['empty'] ) . '</p></div></section>';
	$link = tfc_home_link( $a['link'] );
	ob_start();
	?>
	<section class="section">
		<div class="wrap">
			<?php if ( $a['title'] !== '' ) : ?><div class="section-head">
				<div><?php if ( $a['eyebrow'] !== '' ) : ?><span class="eyebrow"><?php echo esc_html( html_entity_decode( $a['eyebrow'] ) ); ?></span><?php endif; ?><h2><?php echo esc_html( html_entity_decode( $a['title'] ) ); ?></h2></div>
				<?php if ( $link ) : ?><a class="link-arrow" href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $a['link_text'] ); ?> <?php echo tfc_icon( 'arrow' ); ?></a><?php endif; ?>
			</div><?php endif; ?>
			<?php echo $products; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );

// [tfc_story]: photo on the left, three numbered steps on the right.
add_shortcode( 'tfc_story', function ( $atts ) {
	$a = tfc_home_atts( [
		'image'     => tfc_photo( 'mandarin', 1000, 1100 ),
		'image_alt' => 'A mandarin dragonet on live rock',
		'eyebrow'   => 'How we care for livestock',
		'title'     => 'Nothing ships until it’s *ready* to.',
		'text'      => 'A healthy arrival starts long before the box. Every animal spends time in our systems first, so what reaches you is settled, eating and strong.',
		'step1'     => 'Rested on arrival|New livestock recovers from its journey in dedicated holding systems with stable, reef-grade water.',
		'step2'     => 'Observed & fed|We watch behaviour and appetite daily. If an animal isn’t thriving, it isn’t listed.',
		'step3'     => 'Packed to order|Bagged the day it ships, with oxygen and seasonal heat or cold packs, overnight to your door.',
		'link_text' => 'More about us',
		'link'      => 'about',
	], $atts, 'tfc_story' );
	ob_start();
	?>
	<section class="section story">
		<div class="wrap story-grid">
			<figure class="story-media">
				<img src="<?php echo esc_url( $a['image'] ); ?>" alt="<?php echo esc_attr( $a['image_alt'] ); ?>" loading="lazy" width="500" height="550">
			</figure>
			<div class="story-copy">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo tfc_home_heading( $a['title'] ); ?></h2>
				<p class="lead"><?php echo esc_html( $a['text'] ); ?></p>
				<ol class="steps">
					<?php foreach ( [ 'step1', 'step2', 'step3' ] as $i => $k ) : [ $h, $t ] = tfc_home_pair( $a[ $k ] ); ?>
						<li><span><?php printf( '%02d', $i + 1 ); ?></span><div><strong><?php echo esc_html( html_entity_decode( $h ) ); ?></strong><p><?php echo esc_html( $t ); ?></p></div></li>
					<?php endforeach; ?>
				</ol>
				<?php if ( $a['link_text'] !== '' ) : ?><a class="link-arrow" href="<?php echo esc_url( tfc_home_link( $a['link'] ) ); ?>"><?php echo esc_html( $a['link_text'] ); ?> <?php echo tfc_icon( 'arrow' ); ?></a><?php endif; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );

// [tfc_shipping]: the dark shipping and guarantee band.
add_shortcode( 'tfc_shipping', function ( $atts ) {
	$a = tfc_home_atts( [
		'eyebrow' => 'Shipping & guarantee',
		'title'   => 'Overnight to your door, Monday to Wednesday.',
		'text'    => 'Live goods travel overnight early in the week, so nothing sits in a depot over a weekend. If anything arrives dead, send a photo of the sealed bag within two hours and we’ll refund or replace it.',
		'button'  => 'How shipping works|shipping-guarantee',
		'fact1'   => 'Mon–Wed|Live shipping days',
		'fact2'   => '2 hrs|To report a DOA with a photo',
		'fact3'   => 'By state|Rates calculated at checkout',
	], $atts, 'tfc_shipping' );
	[ $label, $to ] = tfc_home_pair( $a['button'] );
	ob_start();
	?>
	<section class="ship-band">
		<div class="wrap ship-band__grid">
			<div class="ship-band__copy">
				<span class="eyebrow eyebrow--light"><?php echo esc_html( html_entity_decode( $a['eyebrow'] ) ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo esc_html( $a['text'] ); ?></p>
				<?php if ( $label !== '' ) : ?><a class="btn btn--coral" href="<?php echo esc_url( tfc_home_link( $to ) ); ?>"><?php echo esc_html( $label ); ?></a><?php endif; ?>
			</div>
			<dl class="ship-band__facts">
				<?php foreach ( [ 'fact1', 'fact2', 'fact3' ] as $k ) : [ $big, $small ] = tfc_home_pair( $a[ $k ] ); ?>
					<div><dt><?php echo esc_html( $big ); ?></dt><dd><?php echo esc_html( $small ); ?></dd></div>
				<?php endforeach; ?>
			</dl>
		</div>
	</section>
	<?php
	return ob_get_clean();
} );

// ---- Elementor -------------------------------------------------------------------------------

// Elementor Pro's Theme Builder can replace the header, footer, product pages, shop and category pages
// (the templates call elementor_theme_do_location()); without Pro the theme's own versions show.
add_action( 'elementor/theme/register_locations', fn( $manager ) => $manager->register_all_core_location() );

// True when Elementor is running and this page was built with it.
function tfc_built_with_elementor( $post_id ) {
	return class_exists( '\Elementor\Plugin' ) && get_post_meta( $post_id, '_elementor_edit_mode', true ) === 'builder';
}

// The Elementor data for a page made of shortcodes: one full-width container per line, each holding a
// Shortcode widget. Saved with the page (harmless when Elementor isn't installed) so that "Edit with
// Elementor" opens the sections as separate blocks instead of one big text box.
function tfc_elementor_meta( $post_id, $shortcodes ) {
	$data = [];
	foreach ( array_filter( array_map( 'trim', preg_split( '/\R+/', $shortcodes ) ) ) as $sc ) {
		$data[] = [
			'id'       => substr( md5( $post_id . $sc . count( $data ) ), 0, 7 ),
			'elType'   => 'container',
			'settings' => [ 'content_width' => 'full', 'padding' => [ 'unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true ] ],
			'elements' => [ [ 'id' => substr( md5( $sc . $post_id ), 0, 7 ), 'elType' => 'widget', 'widgetType' => 'shortcode', 'settings' => [ 'shortcode' => $sc ], 'elements' => [] ] ],
			'isInner'  => false,
		];
	}
	update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
	update_post_meta( $post_id, '_elementor_template_type', 'wp-page' );
	update_post_meta( $post_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.25.0' );
	update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
}
