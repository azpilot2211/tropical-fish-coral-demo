<?php
// "Home page" tickboxes on each product (Product data → General): Featured, New arrival, Special. Each
// fills the matching row on the home page ([tfc_products featured="1"], new="1", special="1").
// A row shows at most TFC_HOME_LIMIT products (two rows of four) so the layout can't break; when more
// are ticked, the most recently ticked ones show and the earliest drop off. A tick is stored as the
// time it was made, which is what puts the newest first.
defined( 'ABSPATH' ) || exit;

const TFC_HOME_LIMIT = 8;
const TFC_HOME_FLAGS = [
	'featured' => [ 'Featured', '_tfc_home_featured', 'Featured products' ],
	'new'      => [ 'New arrival', '_tfc_home_new', 'New arrivals' ],
	'special'  => [ 'Special', '_tfc_home_special', 'Specials' ],
];

// Published products with a flag ticked, most recently ticked first. IDs.
function tfc_home_flagged( $flag, $limit = TFC_HOME_LIMIT ) {
	return get_posts( [
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => max( 1, min( 48, (int) $limit ) ),
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'meta_key'       => TFC_HOME_FLAGS[ $flag ][1],
		'orderby'        => 'meta_value_num',
		'order'          => 'DESC',
	] );
}

// How many published products have the flag ticked (shown or not).
function tfc_home_flag_count( $flag ) {
	global $wpdb;
	return (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(*) FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND p.post_type = 'product' AND p.post_status = 'publish'",
		TFC_HOME_FLAGS[ $flag ][1]
	) );
}

// The product grid for a flag (the theme's normal product cards). '' when nothing is ticked.
function tfc_home_flag_grid( $flag, $limit ) {
	$ids = tfc_home_flagged( $flag, $limit );
	if ( ! $ids ) return '';
	$q = new WP_Query( [ 'post_type' => 'product', 'post__in' => $ids, 'orderby' => 'post__in', 'posts_per_page' => count( $ids ), 'no_found_rows' => true ] );
	wc_setup_loop( [ 'columns' => 4 ] );
	ob_start();
	woocommerce_product_loop_start();
	while ( $q->have_posts() ) {
		$q->the_post();
		wc_get_template_part( 'content', 'product' );
	}
	woocommerce_product_loop_end();
	wp_reset_postdata();
	wc_reset_loop();
	return ob_get_clean();
}

// The tickboxes, under the price fields in the General tab.
add_action( 'woocommerce_product_options_general_product_data', function () {
	global $post;
	echo '<div class="options_group"><p class="form-field"><strong>Home page</strong></p>';
	foreach ( TFC_HOME_FLAGS as $flag => [ $label, $key, $row ] ) {
		woocommerce_wp_checkbox( [
			'id'          => $key,
			'label'       => $label,
			'value'       => get_post_meta( $post->ID, $key, true ) ? 'yes' : 'no',
			'description' => sprintf( 'Show in the “%s” row on the home page (up to %d at a time, most recently ticked first; %d ticked now).', $row, TFC_HOME_LIMIT, tfc_home_flag_count( $flag ) ),
		] );
	}
	echo '</div>';
} );

add_action( 'woocommerce_process_product_meta', function ( $post_id ) {
	// Runs only when the full product edit form is saved (WooCommerce checks its nonce), so quick edits and imports leave the ticks alone.
	foreach ( TFC_HOME_FLAGS as $flag => [ , $key ] ) {
		if ( isset( $_POST[ $key ] ) ) {
			if ( ! get_post_meta( $post_id, $key, true ) ) update_post_meta( $post_id, $key, time() ); // keep the first tick's time on later saves
		} else {
			delete_post_meta( $post_id, $key );
		}
	}
	// Featured also sets WooCommerce's own star, so blocks and widgets that use it agree.
	$product = wc_get_product( $post_id );
	if ( $product && $product->is_featured() !== isset( $_POST['_tfc_home_featured'] ) ) {
		$product->set_featured( isset( $_POST['_tfc_home_featured'] ) );
		$product->save();
	}
}, 20 ); // after WooCommerce saves its own fields (its save is on this hook at 10), or it would overwrite the star

// Products list: a "Home page" column showing which rows each product is in.
add_filter( 'manage_edit-product_columns', function ( $cols ) {
	$out = [];
	foreach ( $cols as $k => $v ) {
		$out[ $k ] = $v;
		if ( $k === 'name' ) $out['tfc_home'] = 'Home page';
	}
	return $out;
} );
add_action( 'manage_product_posts_custom_column', function ( $col, $post_id ) {
	if ( $col !== 'tfc_home' ) return;
	$on = [];
	foreach ( TFC_HOME_FLAGS as $flag => [ $label, $key ] ) if ( get_post_meta( $post_id, $key, true ) ) $on[] = $label;
	echo $on ? esc_html( implode( ', ', $on ) ) : '<span aria-hidden="true">–</span>';
}, 10, 2 );
