<?php
get_header();

$cat   = fn( $slug ) => get_term_by( 'slug', $slug, 'product_cat' );
$count = function ( $term ) {
	$n = $term ? (int) get_term_meta( $term->term_id, 'product_count_product_cat', true ) : 0;
	return $n ? sprintf( _n( '%d product', '%d products', $n ), $n ) : 'Coming soon';
};
// "*word*" in the Customizer heading becomes the italic accent.
$title = preg_replace( '/\*(.+?)\*/', '<em>$1</em>', esc_html( tfc_mod( 'hero_title' ) ) );
if ( strpos( $title, '<em>' ) === false ) $title = preg_replace( '/(\S+)$/', '<em>$1</em>', $title );

// A home-page product row: heading, "view all" link and a grid of in-stock products.
$row = function ( $eyebrow, $heading, $slugs, $link_slug, $limit = 8 ) {
	$products = do_shortcode( sprintf( '[products limit="%d" columns="4" orderby="date" order="DESC" category="%s" cat_operator="IN"]', $limit, esc_attr( $slugs ) ) );
	if ( strpos( $products, 'product' ) === false || strpos( $products, '<li' ) === false ) return;
	?>
	<section class="section">
		<div class="wrap">
			<div class="section-head">
				<div><span class="eyebrow"><?php echo esc_html( $eyebrow ); ?></span><h2><?php echo esc_html( $heading ); ?></h2></div>
				<a class="link-arrow" href="<?php echo esc_url( tfc_cat_url( $link_slug ) ); ?>">View all <?php echo tfc_icon( 'arrow' ); ?></a>
			</div>
			<?php echo $products; ?>
		</div>
	</section>
	<?php
};
?>

<section class="hero">
	<div class="hero-bubbles" aria-hidden="true">
		<i style="--x:2%;--s:18px;--d:13s;--t:-2s"></i>
		<i style="--x:5%;--s:10px;--d:9s;--t:-6s"></i>
		<i style="--x:8%;--s:24px;--d:16s;--t:-11s"></i>
		<i style="--x:48%;--s:14px;--d:11s;--t:-4s"></i>
		<i style="--x:51%;--s:20px;--d:15s;--t:-9s"></i>
		<i style="--x:94%;--s:12px;--d:10s;--t:-1s"></i>
		<i style="--x:97%;--s:22px;--d:14s;--t:-7s"></i>
	</div>
	<div class="wrap hero-grid">
		<div class="hero-copy">
			<span class="eyebrow"><?php echo esc_html( tfc_mod( 'hero_kicker' ) ); ?></span>
			<h1><?php echo $title; ?></h1>
			<p class="lead"><?php echo esc_html( tfc_mod( 'hero_text' ) ); ?></p>
			<div class="hero-actions">
				<a class="btn btn--coral" href="<?php echo esc_url( tfc_cat_url( 'live-goods' ) ); ?>">Shop livestock</a>
				<a class="btn btn--ghost" href="<?php echo esc_url( tfc_cat_url( 'supplies' ) ); ?>">Shop supplies</a>
			</div>
			<ul class="hero-facts">
				<li><strong>Overnight</strong><span>Live goods ship Mon–Wed</span></li>
				<li><strong>Observed</strong><span>Settled &amp; eating before sale</span></li>
				<li><strong>Guaranteed</strong><span>Live arrival, every order</span></li>
			</ul>
		</div>
		<figure class="hero-media">
			<img src="<?php echo esc_url( tfc_mod( 'hero_image' ) ); ?>" alt="A reef aquarium full of soft corals" width="760" height="920" fetchpriority="high">
			<figcaption class="hero-card hero-card--bottom"><?php echo tfc_icon( 'shield' ); ?><span><strong>Live Arrival Guarantee</strong>Photo of the sealed bag within 2 hours and we make it right.</span></figcaption>
			<div class="hero-card hero-card--top"><?php echo tfc_icon( 'thermo' ); ?><span><strong>Packed for the season</strong>Heat &amp; cold packs, insulated boxes</span></div>
		</figure>
	</div>
</section>

<section class="section section--tight">
	<div class="wrap">
		<div class="section-head">
			<div><span class="eyebrow">Shop the reef</span><h2>Find what your tank needs</h2></div>
			<a class="link-arrow" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">Browse everything <?php echo tfc_icon( 'arrow' ); ?></a>
		</div>
		<div class="bento">
			<?php foreach ( [ 'fish' => 'bento__a', 'corals' => 'bento__b', 'invertebrates' => 'bento__c', 'live-rock-sand' => 'bento__d', 'supplies' => 'bento__e' ] as $slug => $class ) :
				$t = $cat( $slug );
				if ( ! $t ) continue; ?>
				<a class="cat-tile <?php echo $class; ?>" href="<?php echo esc_url( get_term_link( $t ) ); ?>">
					<img src="<?php echo esc_url( tfc_category_image( $t, $class === 'bento__a' ? 1100 : 700, $class === 'bento__a' ? 1100 : 560 ) ); ?>" alt="" loading="lazy">
					<span class="cat-tile__body">
						<span class="cat-tile__count"><?php echo esc_html( $count( $t ) ); ?></span>
						<span class="cat-tile__name"><?php echo esc_html( $t->name ); ?></span>
					</span>
					<span class="cat-tile__go"><?php echo tfc_icon( 'arrow' ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
		<?php if ( $dry = $cat( 'dry-goods' ) ) : ?>
			<div class="dry-strip">
				<div class="dry-strip__copy">
					<span class="eyebrow">Dry goods</span>
					<h3>Foods, salt, test kits &amp; water care</h3>
					<p><?php echo esc_html( $dry->description ); ?></p>
					<a class="btn btn--dark" href="<?php echo esc_url( get_term_link( $dry ) ); ?>">Shop dry goods</a>
				</div>
				<ul class="dry-strip__links">
					<?php foreach ( tfc_child_categories( $dry->term_id ) as $kid ) : ?>
						<li><a href="<?php echo esc_url( get_term_link( $kid ) ); ?>"><span><?php echo esc_html( $kid->name ); ?></span><?php echo tfc_icon( 'arrow' ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
	</div>
</section>

<?php $row( 'Just landed', 'Fresh in the holding systems', 'live-goods', 'live-goods' ); ?>

<section class="section story">
	<div class="wrap story-grid">
		<figure class="story-media">
			<img src="<?php echo esc_url( tfc_photo( 'mandarin', 1000, 1100 ) ); ?>" alt="A mandarin dragonet on live rock" loading="lazy" width="500" height="550">
		</figure>
		<div class="story-copy">
			<span class="eyebrow">How we care for livestock</span>
			<h2>Nothing ships until it's <em>ready</em> to.</h2>
			<p class="lead">A healthy arrival starts long before the box. Every animal spends time in our systems first, so what reaches you is settled, eating and strong.</p>
			<ol class="steps">
				<li><span>01</span><div><strong>Rested on arrival</strong><p>New livestock recovers from its journey in dedicated holding systems with stable, reef-grade water.</p></div></li>
				<li><span>02</span><div><strong>Observed &amp; fed</strong><p>We watch behaviour and appetite daily. If an animal isn't thriving, it isn't listed.</p></div></li>
				<li><span>03</span><div><strong>Packed to order</strong><p>Bagged the day it ships, with oxygen and seasonal heat or cold packs, overnight to your door.</p></div></li>
			</ol>
			<a class="link-arrow" href="<?php echo esc_url( home_url( '/about/' ) ); ?>">More about us <?php echo tfc_icon( 'arrow' ); ?></a>
		</div>
	</div>
</section>

<?php $row( 'Coral spotlight', 'New corals & frags', 'corals', 'corals', 4 ); ?>
<?php $row( 'Stock up', 'Dry goods & supplies', 'dry-goods,supplies', 'supplies', 8 ); ?>

<section class="ship-band">
	<div class="wrap ship-band__grid">
		<div class="ship-band__copy">
			<span class="eyebrow eyebrow--light">Shipping &amp; guarantee</span>
			<h2>Overnight to your door, Monday to Wednesday.</h2>
			<p>Live goods travel overnight early in the week, so nothing sits in a depot over a weekend. If anything arrives dead, send a photo of the sealed bag within two hours and we'll refund or replace it.</p>
			<a class="btn btn--coral" href="<?php echo esc_url( home_url( '/shipping-guarantee/' ) ); ?>">How shipping works</a>
		</div>
		<dl class="ship-band__facts">
			<div><dt>Mon–Wed</dt><dd>Live shipping days</dd></div>
			<div><dt>2 hrs</dt><dd>To report a DOA with a photo</dd></div>
			<div><dt>By state</dt><dd>Rates calculated at checkout</dd></div>
		</dl>
	</div>
</section>

<?php get_footer();
