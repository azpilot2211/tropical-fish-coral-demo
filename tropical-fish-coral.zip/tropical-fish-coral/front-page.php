<?php
// The home page. Its content is the Home page in Pages (edit it there or in Elementor); the sections
// are shortcodes from inc/home.php. If that page is empty, or the front page isn't a page, the default
// sections show, so the site is never blank.
get_header();

$content = '';
if ( is_page() && have_posts() ) {
	the_post();
	ob_start();
	the_content();
	$content = trim( ob_get_clean() );
}
echo $content !== '' ? $content : do_shortcode( tfc_home_default_content() );

get_footer();
