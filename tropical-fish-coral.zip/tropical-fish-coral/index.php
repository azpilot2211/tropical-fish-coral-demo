<?php get_header(); ?>
<section class="page-banner page-banner--compact">
	<div class="wrap page-banner__inner">
		<h1><?php echo is_404() ? 'Page not found' : ( is_search() ? 'Search results' : esc_html( wp_strip_all_tags( get_the_archive_title() ?: get_bloginfo( 'name' ) ) ) ); ?></h1>
	</div>
</section>
<div class="wrap page-body">
	<?php if ( ! is_404() && have_posts() ) : ?>
		<div class="post-list">
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'post-card' ); ?>>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<?php the_excerpt(); ?>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<div class="empty-state">
			<?php echo tfc_icon( 'drop' ); ?>
			<h2><?php echo is_404() ? 'This page swam off.' : 'No results'; ?></h2>
			<p>Try a search, or head back to the shop.</p>
			<form class="search-field" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php echo tfc_icon( 'search' ); ?>
				<input type="search" name="s" placeholder="Search fish, corals, supplies" aria-label="Search products">
				<input type="hidden" name="post_type" value="product">
			</form>
		</div>
	<?php endif; ?>
</div>
<?php get_footer();
