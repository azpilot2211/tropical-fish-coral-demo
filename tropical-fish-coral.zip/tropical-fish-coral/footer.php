</main>

<?php if ( ! ( function_exists( 'elementor_theme_do_location' ) && elementor_theme_do_location( 'footer' ) ) ) : ?>
<section class="assurance" aria-label="Why shop with us">
	<div class="wrap assurance-grid">
		<div><?php echo tfc_icon( 'shield' ); ?><strong>Live Arrival Guarantee</strong><span>Every fish, coral and invertebrate</span></div>
		<div><?php echo tfc_icon( 'truck' ); ?><strong>Overnight, Mon–Wed</strong><span>Never stuck in a depot over a weekend</span></div>
		<div><?php echo tfc_icon( 'eye' ); ?><strong>Observed before sale</strong><span>Eating and settled before it ships</span></div>
		<div><?php echo tfc_icon( 'chat' ); ?><strong>Real reef keepers</strong><span><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Ask us anything</a></span></div>
	</div>
</section>

<footer class="site-footer">
	<div class="wrap footer-grid">
		<div class="footer-brand">
			<span class="brand-name">Tropical Fish <em>&amp; Coral</em></span>
			<p>Healthy livestock, honest advice and the dry goods and equipment to keep a reef thriving.</p>
			<ul class="footer-contact">
				<li><?php echo tfc_icon( 'phone' ); ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', tfc_mod( 'phone' ) ) ); ?>"><?php echo esc_html( tfc_mod( 'phone' ) ); ?></a></li>
				<li><?php echo tfc_icon( 'mail' ); ?><a href="mailto:<?php echo esc_attr( tfc_mod( 'email' ) ); ?>"><?php echo esc_html( tfc_mod( 'email' ) ); ?></a></li>
			</ul>
		</div>
		<div>
			<h2 class="footer-title">Livestock</h2>
			<ul>
				<?php foreach ( [ 'fish', 'corals', 'invertebrates', 'live-rock-sand' ] as $slug ) :
					$t = get_term_by( 'slug', $slug, 'product_cat' );
					if ( $t ) printf( '<li><a href="%s">%s</a></li>', esc_url( get_term_link( $t ) ), esc_html( $t->name ) );
				endforeach; ?>
			</ul>
		</div>
		<div>
			<h2 class="footer-title">Dry Goods &amp; Supplies</h2>
			<ul>
				<?php foreach ( [ 'foods', 'salt-additives', 'test-kits', 'aquariums', 'lighting', 'pumps' ] as $slug ) :
					$t = get_term_by( 'slug', $slug, 'product_cat' );
					if ( $t ) printf( '<li><a href="%s">%s</a></li>', esc_url( get_term_link( $t ) ), esc_html( $t->name ) );
				endforeach; ?>
			</ul>
		</div>
		<div>
			<h2 class="footer-title">Help</h2>
			<ul>
				<li><a href="<?php echo esc_url( home_url( '/shipping-guarantee/' ) ); ?>">Shipping &amp; Guarantee</a></li>
				<?php if ( post_type_exists( 'tfc_tutorial' ) ) : // added by the TFC Tutorials plugin ?>
					<li><a href="<?php echo esc_url( get_post_type_archive_link( 'tfc_tutorial' ) ); ?>">Tutorials</a></li>
				<?php endif; ?>
				<li><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">FAQ</a></li>
				<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">About us</a></li>
				<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a></li>
				<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?><li><a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>">Your account</a></li><?php endif; ?>
			</ul>
		</div>
		<div>
			<h2 class="footer-title">Visit</h2>
			<p><?php echo nl2br( esc_html( tfc_mod( 'address' ) ) ); ?></p>
			<p class="footer-hours"><?php echo nl2br( esc_html( tfc_mod( 'hours' ) ) ); ?></p>
		</div>
	</div>
	<div class="wrap footer-bottom">
		<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Tropical Fish &amp; Coral</span>
		<span>Live goods ship overnight Monday–Wednesday</span>
	</div>
</footer>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
