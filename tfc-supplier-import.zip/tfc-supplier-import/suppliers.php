<?php
// Supplier codes. Each supplier a product was imported from gets a short code you can recognise (ASD,
// AMA, SSA…). When a customer checks out, every order line records the supplier and its code, so you
// can see at a glance who each item is ordered from. Codes are edited on WooCommerce → Suppliers.
defined( 'ABSPATH' ) || exit;

// [ source => code ] as saved on the Suppliers page.
function tfc_sup_saved() {
	return (array) get_option( 'tfc_si_suppliers', [] );
}

// The code for a supplier ("aquasd.com", "superiorpets.csv"): the saved one, else one suggested from its name.
function tfc_sup_code( $source ) {
	$source = (string) $source;
	return tfc_sup_saved()[ $source ] ?? tfc_si_default_code( $source );
}

// Every supplier that has products, with how many: [ source => product count ].
function tfc_sup_sources() {
	global $wpdb;
	$out = [];
	foreach ( $wpdb->get_results( "SELECT m.meta_value src, COUNT(*) n FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_tfc_si_source' AND m.meta_value <> '' AND p.post_type = 'product' AND p.post_status <> 'trash' GROUP BY m.meta_value ORDER BY m.meta_value", ARRAY_A ) as $r ) $out[ $r['src'] ] = (int) $r['n'];
	return $out;
}

// ---- Recording it on the order --------------------------------------------------

// Each order line gets the supplier and its code (hidden from the customer; shown on the order in admin).
add_action( 'woocommerce_checkout_create_order_line_item', function ( $item, $cart_key, $values ) {
	$product = $values['data'] ?? null;
	if ( ! $product instanceof WC_Product ) return;
	$source = (string) get_post_meta( $product->get_parent_id() ?: $product->get_id(), '_tfc_si_source', true );
	if ( $source === '' ) return;
	$item->add_meta_data( '_tfc_supplier', $source, true );
	$item->add_meta_data( '_tfc_supplier_code', tfc_sup_code( $source ), true );
}, 10, 3 );

// A note and a summary on the order: "ASD ×2, AMA ×1". Runs for the classic and the block checkout.
function tfc_sup_summarise_order( $order ) {
	$order = is_numeric( $order ) ? wc_get_order( $order ) : $order;
	if ( ! $order ) return;
	$count = [];
	foreach ( $order->get_items() as $item ) {
		$code = $item->get_meta( '_tfc_supplier_code' );
		if ( $code !== '' ) $count[ $code ] = ( $count[ $code ] ?? 0 ) + (int) $item->get_quantity();
	}
	if ( ! $count ) return;
	$text = implode( ', ', array_map( fn( $c, $n ) => "$c ×$n", array_keys( $count ), $count ) );
	$order->update_meta_data( '_tfc_suppliers', implode( ', ', array_keys( $count ) ) );
	$order->save();
	$order->add_order_note( 'Order from: ' . $text );
}
add_action( 'woocommerce_checkout_order_processed', 'tfc_sup_summarise_order' );
add_action( 'woocommerce_store_api_checkout_order_processed', 'tfc_sup_summarise_order' );

// On the order screen, under each item.
add_action( 'woocommerce_after_order_itemmeta', function ( $item_id, $item ) {
	if ( ! $item instanceof WC_Order_Item_Product || $item->get_meta( '_tfc_supplier_code' ) === '' ) return;
	printf( '<div class="wc-order-item-sku"><strong>Supplier:</strong> %s (%s)</div>', esc_html( $item->get_meta( '_tfc_supplier_code' ) ), esc_html( $item->get_meta( '_tfc_supplier' ) ) );
}, 10, 2 );

// Orders list: a "Suppliers" column (the codes of everything in the order).
$tfc_sup_col = fn( $cols ) => array_slice( $cols, 0, 2, true ) + [ 'tfc_suppliers' => 'Suppliers' ] + array_slice( $cols, 2, null, true );
add_filter( 'manage_woocommerce_page_wc-orders_columns', $tfc_sup_col );   // HPOS orders screen
add_filter( 'manage_edit-shop_order_columns', $tfc_sup_col );              // classic orders screen
$tfc_sup_cell = function ( $col, $order = null ) {
	if ( $col !== 'tfc_suppliers' ) return;
	$order = is_object( $order ) ? $order : wc_get_order( get_the_ID() );
	echo $order && $order->get_meta( '_tfc_suppliers' ) ? esc_html( $order->get_meta( '_tfc_suppliers' ) ) : '<span aria-hidden="true">–</span>';
};
add_action( 'manage_woocommerce_page_wc-orders_custom_column', $tfc_sup_cell, 10, 2 );
add_action( 'manage_shop_order_posts_custom_column', $tfc_sup_cell, 10, 2 );

// ---- Settings page: WooCommerce → Suppliers -------------------------------------

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Suppliers', 'Suppliers', 'manage_woocommerce', 'tfc-suppliers', 'tfc_sup_page' );
} );

function tfc_sup_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) return;
	$sources = tfc_sup_sources();
	if ( isset( $_POST['tfc_sup'] ) ) {
		check_admin_referer( 'tfc_sup' );
		$saved = [];
		foreach ( (array) wp_unslash( $_POST['tfc_sup'] ) as $source => $code ) {
			$code = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $code ) );
			if ( isset( $sources[ $source ] ) && $code !== '' ) $saved[ $source ] = substr( $code, 0, 6 );
		}
		update_option( 'tfc_si_suppliers', $saved, false );
		echo '<div class="notice notice-success"><p>Saved.</p></div>';
	}
	?>
	<div class="wrap">
	<h1>Suppliers</h1>
	<p style="max-width:720px">Each supplier has a short code, like <strong>ASD</strong> for Aqua SD or <strong>SSA</strong> for Seaside Aquatics. When a customer checks out, every item on the order is stamped with its supplier’s code, shown under the item on the order screen and as a <em>Suppliers</em> column in the orders list, so you know who to order each item from. Suppliers appear here after you import their products. Up to 6 letters or numbers; the suggested codes come from the supplier’s name.</p>
	<?php if ( ! $sources ) : ?>
		<p>No suppliers yet. Import products from a supplier’s website or spreadsheet first (WooCommerce → Supplier Import).</p>
	<?php else : ?>
		<form method="post">
			<?php wp_nonce_field( 'tfc_sup' ); ?>
			<table class="widefat striped" style="max-width:640px">
				<thead><tr><th>Supplier (where the products came from)</th><th>Products</th><th>Code</th></tr></thead>
				<tbody>
				<?php foreach ( $sources as $source => $n ) : ?>
					<tr>
						<td><?php echo esc_html( $source ); ?></td>
						<td><?php echo (int) $n; ?></td>
						<td><input name="tfc_sup[<?php echo esc_attr( $source ); ?>]" value="<?php echo esc_attr( tfc_sup_code( $source ) ); ?>" maxlength="6" style="width:90px;text-transform:uppercase"></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description" style="max-width:640px">A supplier’s website and its spreadsheet show up as separate lines (for example <code>aquasd.com</code> and <code>aquaqSD.csv</code>). Give them the same code if they’re the same supplier. Changing a code only affects new orders.</p>
			<?php submit_button( 'Save codes' ); ?>
		</form>
	<?php endif; ?>
	</div>
	<?php
}
