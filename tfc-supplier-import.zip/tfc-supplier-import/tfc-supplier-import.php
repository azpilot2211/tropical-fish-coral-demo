<?php
/*
Plugin Name: TFC Supplier Import
Description: Pull fish, coral and dry goods from a wholesaler's website into WooCommerce (or a CSV) with your markup, and charge shipping per state for live and dry goods.
Version: 1.2.0
Requires at least: 6.0
Requires PHP: 7.4
Requires Plugins: woocommerce
*/
defined( 'ABSPATH' ) || exit;
require __DIR__ . '/parse.php';
require __DIR__ . '/shipping.php';
require __DIR__ . '/photos.php';
require __DIR__ . '/login.php';

add_action( 'admin_menu', function () {
	$hook = add_submenu_page( 'woocommerce', 'Supplier Import', 'Supplier Import', 'manage_woocommerce', 'tfc-supplier-import', 'tfc_si_page' );
	add_action( "load-$hook", 'tfc_si_handle' ); // runs before any output, so the CSV download can send headers
} );

function tfc_si_handle() {
	global $tfc_si_msg, $tfc_si_login;
	if ( empty( $_POST['tfc_si'] ) || ! current_user_can( 'manage_woocommerce' ) ) return;
	check_admin_referer( 'tfc_si' );
	$key       = 'tfc_si_rows_' . get_current_user_id();
	$sheet_key = 'tfc_si_sheet_' . get_current_user_id();
	$action    = $_POST['tfc_si'];

	// Spreadsheet step 1: read the file, guess the columns, show the matching step.
	if ( $action === 'upload' ) {
		$file  = $_FILES['sheet'] ?? null;
		$ext   = strtolower( pathinfo( $file['name'] ?? '', PATHINFO_EXTENSION ) );
		$table = null;
		if ( $file && $file['error'] === UPLOAD_ERR_OK && is_uploaded_file( $file['tmp_name'] ) ) {
			if ( $ext === 'xlsx' ) $table = tfc_si_read_xlsx( $file['tmp_name'] );
			if ( in_array( $ext, [ 'csv', 'tsv', 'txt' ], true ) ) $table = tfc_si_read_csv( file_get_contents( $file['tmp_name'] ) );
		}
		if ( ! $table ) {
			$tfc_si_msg = [ 'error', 'Couldn’t read that file. Upload an .xlsx or .csv file (in Excel: File → Save As → CSV). Older .xls files need saving as one of those first.' ];
			return;
		}
		[ $header, $map ] = tfc_si_guess_columns( $table );
		set_transient( $sheet_key, [ 'file' => sanitize_file_name( $file['name'] ), 'table' => $table, 'header' => $header, 'map' => $map ], DAY_IN_SECONDS );
		$tfc_si_msg = [ 'info', 'Check the columns below, then click “Use these columns”.' ];
		return;
	}
	// Spreadsheet step 2: turn the rows into the checklist below.
	if ( $action === 'map' ) {
		$sheet  = get_transient( $sheet_key );
		$header = max( 0, (int) ( $_POST['header'] ?? 1 ) - 1 );
		$map    = [];
		foreach ( (array) wp_unslash( $_POST['map'] ?? [] ) as $field => $col ) {
			if ( isset( TFC_SI_SHEET_FIELDS[ $field ] ) && $col !== '' ) $map[ $field ] = (int) $col;
		}
		if ( ! $sheet ) {
			$tfc_si_msg = [ 'warning', 'That upload expired. Upload the file again.' ];
		} elseif ( ! isset( $map['name'], $map['cost'] ) ) {
			$tfc_si_msg = [ 'error', 'Pick which columns hold the name and the price.' ];
			$sheet['header'] = $header;
			$sheet['map']    = $map;
			set_transient( $sheet_key, $sheet, DAY_IN_SECONDS );
		} elseif ( ! ( $rows = tfc_si_priced( tfc_si_from_table( $sheet['table'], $header, $map ) ) ) ) {
			$tfc_si_msg = [ 'warning', 'No rows with a price were found below that header row. Check the header row number and the Price column.' ];
		} else {
			foreach ( $rows as $i => $r ) $rows[ $i ]['source'] = $sheet['file']; // which supplier list it came from
			set_transient( $key, $rows, DAY_IN_SECONDS );
			delete_transient( $sheet_key );
			$tfc_si_msg = [ 'success', sprintf( 'Found %d items in %s.', count( $rows ), $sheet['file'] ) ];
		}
		return;
	}
	if ( $action === 'cancel_sheet' ) {
		delete_transient( $sheet_key );
		return;
	}

	if ( $action === 'fetch' ) {
		$url = esc_url_raw( trim( wp_unslash( $_POST['url'] ?? '' ) ) );
		update_option( 'tfc_si_url', $url, false );
		delete_transient( $key );
		delete_transient( $sheet_key );
		$login_error = tfc_si_login_posted( $url );
		$rows        = $login_error ? new WP_Error( 'login', '', '' ) : tfc_si_fetch( $url );
		if ( is_wp_error( $rows ) && $rows->get_error_code() === 'login' ) {
			$tfc_si_login = [ $rows->get_error_data(), $login_error ];
			$tfc_si_msg   = [ 'warning', 'That page needs a login to the supplier’s website.' ];
		} elseif ( is_wp_error( $rows ) ) {
			$tfc_si_msg = [ 'error', $rows->get_error_message() ];
		} elseif ( ! $rows ) {
			$tfc_si_msg = [ 'warning', 'No product data found at that URL. The site may need a login (use “Log in to the site”), or uses a layout this plugin can’t read yet.' ];
		} elseif ( ! ( $priced = tfc_si_priced( $rows ) ) ) {
			$tfc_si_msg = [ 'warning', sprintf( 'Found %d items, but none show a price. If the supplier only shows prices to logged-in customers, click “Log in to the site”.', count( $rows ) ) ];
		} else {
			foreach ( $priced as $i => $r ) $priced[ $i ]['source'] = (string) wp_parse_url( $url, PHP_URL_HOST );
			set_transient( $key, $priced, DAY_IN_SECONDS );
			$skipped    = count( $rows ) - count( $priced );
			$tfc_si_msg = [ 'success', sprintf( 'Found %d items.', count( $priced ) ) . ( $skipped ? sprintf( ' Left out %d without a price.', $skipped ) : '' )
				. ( $skipped && ! isset( $_POST['tfc_login'] ) ? ' If the supplier shows more prices to logged-in customers, click “Log in to the site”.' : '' ) ];
		}
		return;
	}

	$mk = tfc_si_markups( wp_unslash( $_POST['mk'] ?? [] ) );
	update_option( 'tfc_si_markups', $mk, false );
	$picked = json_decode( wp_unslash( $_POST['picked'] ?? '' ), true );
	$groups = tfc_si_prepare( get_transient( $key ) ?: [], is_array( $picked ) ? $picked : [], $mk );
	if ( ! $groups ) {
		$tfc_si_msg = [ 'warning', 'Nothing selected, or the list expired. Fetch the URL or upload the file again.' ];
		return;
	}
	// Weights are in lb and dimensions in inches here; store them in the shop's own units.
	$unit = get_option( 'woocommerce_weight_unit', 'lbs' );
	$dim  = get_option( 'woocommerce_dimension_unit', 'in' );
	foreach ( $groups as $g => $items ) {
		foreach ( $items as $k => $r ) {
			if ( $r['weight'] !== null ) $groups[ $g ][ $k ]['weight'] = round( wc_get_weight( $r['weight'], $unit, 'lbs' ), 3 );
			foreach ( [ 'length', 'width', 'height' ] as $f ) {
				if ( ( $r[ $f ] ?? null ) !== null ) $groups[ $g ][ $k ][ $f ] = round( wc_get_dimension( $r[ $f ], $dim, 'in' ), 2 );
			}
		}
	}
	if ( $action === 'csv' ) {
		foreach ( $groups as $g => $items ) $groups[ $g ][0]['cat_path'] = tfc_si_term_path( tfc_si_category_for( $items[0] ) );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=supplier-products-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		foreach ( tfc_si_csv_rows( $groups, $unit, $dim ) as $line ) fputcsv( $out, $line );
		exit;
	}
	tfc_si_import( $groups, ! empty( $_POST['refile'] ) );
	global $tfc_si_img_fails;
	$dead = array_keys( array_filter( (array) $tfc_si_img_fails, fn( $n ) => $n >= 5 ) );
	$tfc_si_msg = [ 'success', sprintf( 'Saved %d products to WooCommerce. <a href="%s">View products</a>', count( $groups ), esc_url( admin_url( 'edit.php?post_type=product' ) ) )
		. ( $dead ? ' Images from ' . esc_html( implode( ', ', $dead ) ) . ' were skipped because their links aren’t working; ask the supplier for current image links.' : '' ) ];
}

// Saved markups and default weights (lb), or $src (the posted form) cleaned into the same shape.
function tfc_si_markups( $src = null ) {
	$src = $src ?? get_option( 'tfc_si_markups', [] );
	$out = [];
	foreach ( TFC_SI_CATS as $cat => $_ ) {
		$out[ $cat ] = [
			'price'      => (float) ( $src[ $cat ]['price'] ?? 0 ),
			'price_type' => ( $src[ $cat ]['price_type'] ?? '' ) === 'flat' ? 'flat' : 'percent',
			'weight'     => max( 0, (float) ( $src[ $cat ]['weight'] ?? 0 ) ),
		];
	}
	return $out;
}

// ---- Fetching ------------------------------------------------------------

function tfc_si_fetch( $url ) {
	$u = wp_parse_url( $url );
	if ( empty( $u['host'] ) ) return new WP_Error( 'url', 'Enter a full URL, like https://supplier.com' );
	$base = ( $u['scheme'] ?? 'https' ) . '://' . $u['host'] . ( isset( $u['port'] ) ? ':' . $u['port'] : '' );

	// Shopify stores publish their catalog as JSON; a /collections/... URL narrows it to that collection.
	$json = preg_match( '#^/collections/[^/]+#', $u['path'] ?? '', $m ) ? $base . $m[0] : $base;
	$rows = tfc_si_pages( fn( $n ) => tfc_si_from_shopify( tfc_si_json( "$json/products.json?limit=250&page=$n" ) ?? [], $base ) );
	if ( ! $rows ) {
		$rows = tfc_si_pages( fn( $n ) => tfc_si_from_woo( tfc_si_json( "$base/wp-json/wc/store/v1/products?per_page=100&page=$n" ) ?? [] ) );
	}
	if ( $rows ) return $rows;

	// Any other site: read the schema.org product data search engines use.
	$res = tfc_si_remote_get( $url );
	if ( is_wp_error( $res ) ) return $res;
	$code = wp_remote_retrieve_response_code( $res );
	$rows = $code === 200 ? tfc_si_from_jsonld( wp_remote_retrieve_body( $res ), $url ) : [];
	if ( ! $rows && ( $login = tfc_si_login_url( $res, $url, true ) ) ) return new WP_Error( 'login', 'That page needs a login.', $login );
	if ( $code === 403 || $code === 503 ) {
		return new WP_Error( 'blocked', 'The site blocked the request (bot protection such as Cloudflare). Ask the supplier for a product feed or spreadsheet, or to allow your store’s server.' );
	}
	if ( $code !== 200 ) return new WP_Error( 'http', "The site returned an error (HTTP $code). Check the URL." );
	return $rows;
}

// ponytail: stops at 20 pages (5,000 Shopify / 2,000 Woo products); raise it if a supplier is bigger.
function tfc_si_pages( callable $page ) {
	$rows = [];
	for ( $n = 1; $n <= 20; $n++ ) {
		$batch = $page( $n );
		if ( ! $batch ) break;
		$rows = array_merge( $rows, $batch );
	}
	return $rows;
}

function tfc_si_json( $url ) {
	$res = tfc_si_remote_get( $url );
	if ( wp_remote_retrieve_response_code( $res ) !== 200 ) return null;
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	return is_array( $data ) ? $data : null;
}

// ---- Saving to WooCommerce -----------------------------------------------

function tfc_si_import( array $groups, $refile = false ) {
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	wc_set_time_limit( 0 );
	foreach ( $groups as $group => $items ) tfc_si_save( (string) $group, $items, $refile );
}

// One product per group. Several sizes = variable product with a Size option.
// Re-importing updates price, stock and weight; name, description and images are only set the
// first time. Category too, unless $refile asks to re-file existing products into categories.
function tfc_si_save( $group, array $items, $refile = false ) {
	$first    = $items[0];
	$variable = $first['size'] !== '';
	$id       = tfc_si_find( '_tfc_si_group', $group );
	$product  = $id ? wc_get_product( $id ) : ( $variable ? new WC_Product_Variable() : new WC_Product_Simple() );

	if ( ! $id ) {
		$product->set_name( $first['name'] );
		$product->set_description( wp_kses_post( $first['description'] ) );
		$product->set_category_ids( array_filter( [ tfc_si_category_for( $first ) ] ) );
		$product->update_meta_data( '_tfc_si_group', $group );
	} elseif ( $refile ) {
		$product->set_category_ids( array_filter( [ tfc_si_category_for( $first ) ] ) );
	}
	if ( ! empty( $first['source'] ) ) $product->update_meta_data( '_tfc_si_source', $first['source'] );
	if ( $variable ) {
		$attrs = $product->get_attributes();
		$size  = new WC_Product_Attribute();
		$size->set_name( 'Size' );
		$size->set_options( array_values( array_unique( array_merge(
			isset( $attrs['size'] ) ? $attrs['size']->get_options() : [],
			array_column( $items, 'size' )
		) ) ) );
		$size->set_visible( true );
		$size->set_variation( true );
		$attrs['size'] = $size;
		$product->set_attributes( $attrs );
	} else {
		tfc_si_set_prices( $product, $first );
	}
	$pid = $product->save();

	if ( $variable ) {
		foreach ( $items as $r ) {
			$vid = tfc_si_find( '_tfc_si_id', $r['id'] );
			$v   = $vid ? wc_get_product( $vid ) : new WC_Product_Variation();
			$v->set_parent_id( $pid );
			$v->set_attributes( [ 'size' => $r['size'] ] );
			tfc_si_set_prices( $v, $r );
			$v->save();
		}
		WC_Product_Variable::sync( $pid );
	}
	if ( ! $id ) tfc_si_attach_images( $pid, $first['name'], $first['images'] );
}

function tfc_si_set_prices( WC_Product $p, array $r ) {
	$p->set_regular_price( (string) $r['price'] );
	$p->set_stock_status( $r['available'] ? 'instock' : 'outofstock' );
	// Blank values keep whatever you've set in WooCommerce.
	if ( $r['weight'] !== null ) $p->set_weight( (string) $r['weight'] );
	if ( ( $r['length'] ?? null ) !== null ) $p->set_length( (string) $r['length'] );
	if ( ( $r['width'] ?? null ) !== null ) $p->set_width( (string) $r['width'] );
	if ( ( $r['height'] ?? null ) !== null ) $p->set_height( (string) $r['height'] );
	$p->update_meta_data( '_tfc_si_id', $r['id'] );
	$p->update_meta_data( '_tfc_si_cost', $r['cost'] );
}

// First image becomes the product photo, the rest its gallery.
// ponytail: capped at 10 per product so a big import doesn't stall on downloads.
function tfc_si_attach_images( $pid, $name, array $urls ) {
	$ids = [];
	foreach ( array_slice( $urls, 0, 10 ) as $url ) {
		$id = tfc_si_sideload( $url, $pid, $name );
		if ( ! is_wp_error( $id ) ) $ids[] = $id;
	}
	if ( ! $ids ) return;
	$product = wc_get_product( $pid );
	$product->set_image_id( array_shift( $ids ) );
	$product->set_gallery_image_ids( $ids );
	$product->save();
}

// Download an image into the Media Library. Judged by the file's content rather than its
// name, so links like getImage.php?code=123 work and links to web pages are skipped.
// The same link is only downloaded once; later products reuse it.
function tfc_si_sideload( $url, $pid, $name ) {
	global $tfc_si_img_fails; // host => failed downloads in a row, this import
	$existing = get_posts( [ 'post_type' => 'attachment', 'post_status' => 'any', 'meta_key' => '_tfc_si_src', 'meta_value' => $url, 'fields' => 'ids', 'numberposts' => 1 ] );
	if ( $existing ) return $existing[0];
	// A supplier whose image links are dead would otherwise cost a slow failed download per product.
	$host = (string) wp_parse_url( $url, PHP_URL_HOST );
	if ( ( $tfc_si_img_fails[ $host ] ?? 0 ) >= 5 ) return new WP_Error( 'skipped', "Skipped: images from $host keep failing" );
	$tmp = download_url( $url, 30 );
	$tfc_si_img_fails[ $host ] = is_wp_error( $tmp ) ? ( $tfc_si_img_fails[ $host ] ?? 0 ) + 1 : 0;
	if ( is_wp_error( $tmp ) ) return $tmp;
	$ext = [ 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp' ][ wp_get_image_mime( $tmp ) ] ?? null;
	if ( ! $ext ) {
		@unlink( $tmp );
		return new WP_Error( 'not_image', "Not an image: $url" );
	}
	$id = media_handle_sideload( [ 'name' => sanitize_title( $name ) . ".$ext", 'tmp_name' => $tmp ], $pid, $name );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp );
		return $id;
	}
	update_post_meta( $id, '_tfc_si_src', $url );
	return $id;
}

function tfc_si_find( $key, $value ) {
	$ids = get_posts( [
		'post_type'   => [ 'product', 'product_variation' ],
		'post_status' => 'any',
		'meta_key'    => $key,
		'meta_value'  => $value,
		'fields'      => 'ids',
		'numberposts' => 1,
	] );
	return $ids ? $ids[0] : 0;
}

// Best store category for a row: the most specific category (e.g. Live Goods > Fish > Tangs) whose
// keywords match the supplier's category or the product name. Fish look under Fish, Invertebrates and
// Live Rock; corals under Corals, Invertebrates and Live Rock; everything else under Dry Goods and
// Supplies. Falls back to Live Goods > Fish / Live Goods > Corals / Dry Goods.
function tfc_si_category_for( array $row ) {
	static $cands = [];
	$type = $row['category'];
	if ( ! isset( $cands[ $type ] ) ) {
		$cands[ $type ] = [];
		$roots = [ 'fish' => [ 'fish', 'invertebrates', 'live-rock-sand' ], 'coral' => [ 'corals', 'invertebrates', 'live-rock-sand' ], 'dry' => [ 'dry-goods', 'supplies' ] ][ $type ];
		foreach ( $roots as $slug ) {
			$root = get_term_by( 'slug', $slug, 'product_cat' );
			if ( ! $root ) continue;
			$base = count( get_ancestors( $root->term_id, 'product_cat' ) );
			foreach ( array_merge( [ $root ], get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false, 'child_of' => $root->term_id ] ) ) as $t ) {
				// Keywords: the theme's list for the category, else the words of its name ("Tangs" -> "tang").
				$kw = (string) get_term_meta( $t->term_id, 'tfc_keywords', true );
				$kw = $kw !== '' ? array_map( 'trim', explode( ',', $kw ) ) : array_map( fn( $w ) => rtrim( $w, 's' ), preg_split( '/[^a-z]+/', strtolower( $t->name ), -1, PREG_SPLIT_NO_EMPTY ) );
				$cands[ $type ][] = [ 'id' => $t->term_id, 'depth' => 1 + count( get_ancestors( $t->term_id, 'product_cat' ) ) - $base, 'keywords' => array_filter( $kw, fn( $w ) => strlen( $w ) > 2 ) ];
			}
		}
	}
	return tfc_si_pick_term( $cands[ $type ], $row['cat_text'] ?? '', $row['name'] ) ?: tfc_si_term( TFC_SI_CATS[ $type ][1] );
}

// Term id -> "Live Goods > Fish > Tangs & Surgeonfish" (for the CSV).
function tfc_si_term_path( $id ) {
	$ids = array_merge( array_reverse( get_ancestors( $id, 'product_cat' ) ), [ $id ] );
	return implode( ' > ', array_map( fn( $i ) => get_term( $i )->name, $ids ) );
}

// "Live Goods > Fish" -> term id, creating the categories if needed.
function tfc_si_term( $path ) {
	$parent = 0;
	foreach ( explode( ' > ', $path ) as $name ) {
		$t = term_exists( $name, 'product_cat', $parent ) ?: wp_insert_term( $name, 'product_cat', [ 'parent' => $parent ] );
		if ( is_wp_error( $t ) ) return $parent;
		$parent = (int) $t['term_id'];
	}
	return $parent;
}

// ---- Admin page ----------------------------------------------------------

// Spreadsheet column matching: which row has the column names, which column is which field,
// and a preview of the top of the file.
function tfc_si_sheet_step( array $sheet ) {
	$table  = $sheet['table'];
	$header = $sheet['header'];
	$heads  = $table[ $header ] ?? [];
	$width  = max( array_map( 'count', array_slice( $table, 0, 50 ) ) );
	$letter = fn( $i ) => ( $i >= 26 ? chr( 64 + intdiv( $i, 26 ) ) : '' ) . chr( 65 + $i % 26 );
	?>
	<h2>Match the columns in <?php echo esc_html( $sheet['file'] ); ?></h2>
	<form method="post">
		<?php wp_nonce_field( 'tfc_si' ); ?>
		<p><label>Column names are in row <input type="number" name="header" min="1" style="width:70px" value="<?php echo (int) $header + 1; ?>"></label></p>
		<table class="form-table" style="max-width:640px">
		<?php foreach ( TFC_SI_SHEET_FIELDS as $field => [ $label ] ) : ?>
			<tr>
				<th><?php echo esc_html( $label ) . ( in_array( $field, [ 'name', 'cost' ], true ) ? ' *' : '' ); ?></th>
				<td><select name="map[<?php echo $field; ?>]">
					<option value="">— not in this file —</option>
					<?php for ( $c = 0; $c < $width; $c++ ) {
						printf( '<option value="%d"%s>%s: %s</option>', $c, selected( $sheet['map'][ $field ] ?? null, $c, false ), $letter( $c ), esc_html( wp_html_excerpt( (string) ( $heads[ $c ] ?? '' ), 40, '…' ) ) );
					} ?>
				</select></td>
			</tr>
		<?php endforeach; ?>
		</table>
		<p>
			<button class="button button-primary" name="tfc_si" value="map">Use these columns</button>
			<button class="button" name="tfc_si" value="cancel_sheet">Cancel</button>
		</p>
		<p class="description">Rows without a price are skipped. A row with only a name in it, like “ANGELFISH” or “Soft Corals”, is treated as a section heading and helps sort the rows under it into fish, coral or dry goods.</p>
	</form>
	<h3>Top of the file</h3>
	<div style="overflow:auto;max-height:380px">
		<table class="widefat striped">
			<thead><tr><th>Row</th><?php for ( $c = 0; $c < $width; $c++ ) echo '<th>' . $letter( $c ) . '</th>'; ?></tr></thead>
			<tbody>
			<?php foreach ( array_slice( $table, 0, 15, true ) as $i => $row ) : ?>
				<tr<?php echo $i === $header ? ' style="font-weight:600;background:#f0f6fc"' : ''; ?>>
					<td><?php echo (int) $i + 1; ?></td>
					<?php for ( $c = 0; $c < $width; $c++ ) echo '<td>' . esc_html( wp_html_excerpt( (string) ( $row[ $c ] ?? '' ), 60, '…' ) ) . '</td>'; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php
}

function tfc_si_page() {
	global $tfc_si_msg, $tfc_si_login;
	$rows  = get_transient( 'tfc_si_rows_' . get_current_user_id() ) ?: [];
	$sheet = get_transient( 'tfc_si_sheet_' . get_current_user_id() );
	$mk    = tfc_si_markups();
	?>
	<div class="wrap">
	<h1>Supplier Import</h1>
	<?php if ( $tfc_si_msg ) printf( '<div class="notice notice-%s"><p>%s</p></div>', esc_attr( $tfc_si_msg[0] ), wp_kses_post( $tfc_si_msg[1] ) ); ?>

	<div style="display:flex;flex-wrap:wrap;gap:0 48px">
		<form method="post" id="tfc-si-fetch">
			<?php wp_nonce_field( 'tfc_si' ); ?>
			<h2>From a website</h2>
			<p>
				<input type="url" name="url" class="regular-text" required
					placeholder="https://wholesaler.com/collections/corals"
					value="<?php echo esc_attr( get_option( 'tfc_si_url', '' ) ); ?>">
				<button class="button button-primary" name="tfc_si" value="fetch">Fetch items</button>
				<button type="button" class="button" data-tfc-login>Log in to the site</button>
			</p>
			<p class="description" style="max-width:460px">Shopify and WooCommerce stores, and any site with standard product data. Paste a category page to fetch just that category. Items without a price are left out; if the supplier only shows prices to logged-in customers, log in first.</p>
		</form>
		<?php tfc_si_login_dialog( 'tfc-si-fetch', [ 'tfc_si', 'fetch' ], $tfc_si_login[0] ?? '', $tfc_si_login[1] ?? '', (bool) $tfc_si_login ); ?>
		<form method="post" enctype="multipart/form-data">
			<?php wp_nonce_field( 'tfc_si' ); ?>
			<h2>From a spreadsheet</h2>
			<p>
				<input type="file" name="sheet" accept=".xlsx,.csv,.tsv,.txt" required>
				<button class="button button-primary" name="tfc_si" value="upload">Upload</button>
			</p>
			<p class="description" style="max-width:460px">A supplier’s price or availability list as .xlsx or .csv. You’ll match up the columns next.</p>
		</form>
	</div>

	<?php if ( $sheet ) : tfc_si_sheet_step( $sheet ); ?>
	<?php elseif ( $rows ) : ?>
	<form method="post" id="tfc-si">
		<?php wp_nonce_field( 'tfc_si' ); ?>
		<input type="hidden" name="picked" id="tfc-si-picked">

		<h2>Markup &amp; shipping weight</h2>
		<table class="widefat" style="max-width:560px">
			<thead><tr><th></th><th>Price markup</th><th>Default shipping weight</th></tr></thead>
			<tbody>
			<?php foreach ( TFC_SI_CATS as $cat => [ $label ] ) : ?>
				<tr><th><?php echo esc_html( $label ); ?></th>
					<td>
						<input type="number" step="0.01" style="width:90px" name="mk[<?php echo $cat; ?>][price]" value="<?php echo esc_attr( $mk[ $cat ]['price'] ); ?>">
						<select name="mk[<?php echo $cat; ?>][price_type]">
							<option value="percent">%</option>
							<option value="flat" <?php selected( $mk[ $cat ]['price_type'], 'flat' ); ?>>$ added</option>
						</select>
					</td>
					<td><input type="number" step="0.01" min="0" style="width:90px" name="mk[<?php echo $cat; ?>][weight]" value="<?php echo esc_attr( $mk[ $cat ]['weight'] ?: '' ); ?>"> lb</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description">Each item uses the weight from the supplier’s spreadsheet when it has one, otherwise its category’s default; type in a row to override. Weight is what the per-lb state shipping rates charge on.</p>

		<h2>Items (<?php echo count( $rows ); ?>)</h2>
		<p>
			<input type="search" id="tfc-si-filter" placeholder="Filter by name or size">
			Select:
			<button type="button" class="button" data-select="all">All shown</button>
			<?php foreach ( TFC_SI_CATS as $cat => [ $label ] ) : ?>
				<button type="button" class="button" data-select="<?php echo $cat; ?>">+ <?php echo esc_html( $label ); ?></button>
			<?php endforeach; ?>
			<button type="button" class="button" data-select="none">None</button>
		</p>
		<table class="widefat striped" id="tfc-si-rows">
			<thead><tr>
				<td class="check-column"><input type="checkbox" id="tfc-si-all"></td>
				<th></th><th>Product</th><th>Size</th><th>Category</th><th>Stock</th>
				<th>Cost</th><th>Your price</th><th>Weight (lb)</th>
			</tr></thead>
			<tbody>
			<?php foreach ( $rows as $i => $r ) : ?>
				<tr data-i="<?php echo (int) $i; ?>" data-search="<?php echo esc_attr( strtolower( $r['name'] . ' ' . $r['size'] ) ); ?>">
					<th class="check-column"><input type="checkbox" class="pick"></th>
					<td><?php if ( $r['images'] ) : ?><img src="<?php echo esc_url( $r['images'][0] ); ?>" width="44" height="44" style="object-fit:cover" loading="lazy" alt=""><?php endif; ?></td>
					<td><a href="<?php echo esc_url( $r['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $r['name'] ); ?></a></td>
					<td><?php echo esc_html( $r['size'] ); ?></td>
					<td><select class="cat">
						<?php foreach ( TFC_SI_CATS as $cat => [ $label ] ) printf( '<option value="%s"%s>%s</option>', $cat, selected( $r['category'], $cat, false ), esc_html( $label ) ); ?>
					</select></td>
					<td><?php echo $r['available'] ? 'In stock' : '<em>Out</em>'; ?></td>
					<td class="cost" data-v="<?php echo esc_attr( $r['cost'] ); ?>"><?php echo esc_html( number_format( $r['cost'], 2 ) ); ?></td>
					<td class="price"></td>
					<td><input type="number" step="0.01" min="0" class="weight" style="width:80px" value="<?php echo esc_attr( $r['weight'] ?? '' ); ?>"></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p>
			<button class="button button-primary" name="tfc_si" value="import">Import selected into WooCommerce</button>
			<button class="button" name="tfc_si" value="csv">Download selected as CSV</button>
			<label style="margin-left:12px"><input type="checkbox" name="refile" value="1"> Re-file products imported before into categories</label>
		</p>
		<p class="description">Import creates products (with images) or updates the price, stock and weight of ones imported before. The CSV loads through Products → Import.</p>
	</form>
	<script>
	(() => {
		const form = document.getElementById('tfc-si');
		const rows = [...form.querySelectorAll('#tfc-si-rows tbody tr')];
		const q = (el, s) => el.querySelector(s);
		const field = (cat, f) => q(form, `[name="mk[${cat}][${f}]"]`).value;
		const calc = () => rows.forEach(tr => {
			const cat = q(tr, '.cat').value, cost = parseFloat(q(tr, '.cost').dataset.v);
			const amt = parseFloat(field(cat, 'price')) || 0;
			const price = field(cat, 'price_type') === 'flat' ? cost + amt : cost * (1 + amt / 100);
			q(tr, '.price').textContent = (Math.round(Math.round(price * 1e6) / 1e4) / 100).toFixed(2); // same half-up rounding as the import
			q(tr, '.weight').placeholder = field(cat, 'weight'); // blank row = category default
		});
		form.addEventListener('input', calc);
		form.addEventListener('change', calc);
		calc();

		const filter = document.getElementById('tfc-si-filter');
		filter.addEventListener('input', () => {
			const s = filter.value.toLowerCase();
			rows.forEach(tr => tr.hidden = !tr.dataset.search.includes(s));
		});
		filter.addEventListener('keydown', e => e.key === 'Enter' && e.preventDefault()); // don't submit the import

		const shown = () => rows.filter(tr => !tr.hidden);
		form.querySelectorAll('[data-select]').forEach(b => b.addEventListener('click', () => {
			const s = b.dataset.select;
			shown().forEach(tr => {
				const box = q(tr, '.pick');
				box.checked = s !== 'none' && (s === 'all' || box.checked || q(tr, '.cat').value === s);
			});
		}));
		document.getElementById('tfc-si-all').addEventListener('change', e => shown().forEach(tr => q(tr, '.pick').checked = e.target.checked));

		// Send picks as one JSON field: thousands of separate inputs would hit PHP's max_input_vars.
		form.addEventListener('submit', e => {
			const picked = rows.filter(tr => q(tr, '.pick').checked).map(tr => ({
				i: +tr.dataset.i, cat: q(tr, '.cat').value, weight: q(tr, '.weight').value,
			}));
			if (!picked.length) { e.preventDefault(); alert('Tick at least one item.'); return; }
			document.getElementById('tfc-si-picked').value = JSON.stringify(picked);
		});
	})();
	</script>
	<?php endif; ?>
	</div>
	<?php
}
