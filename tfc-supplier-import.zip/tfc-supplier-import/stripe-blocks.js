// Lists "Credit or debit card" (Stripe) in WooCommerce's block checkout. Paying redirects to Stripe's
// page; WooCommerce calls the gateway's process_payment() on the server, so nothing else happens here.
(() => {
	const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
	const { getSetting } = window.wc.wcSettings;
	const { createElement: el } = window.wp.element;
	// WooCommerce 9+ publishes gateway data under paymentMethodData; older versions as tfc_stripe_data.
	const data = (getSetting('paymentMethodData', {}) || {}).tfc_stripe || getSetting('tfc_stripe_data', {});
	const title = data.title || 'Credit or debit card';
	const Description = () => el('p', null, data.description || '');
	registerPaymentMethod({
		name: 'tfc_stripe',
		label: el('span', null, title),
		ariaLabel: title,
		content: el(Description),
		edit: el(Description),
		canMakePayment: () => true,
		supports: { features: data.supports || ['products'] },
	});
})();
