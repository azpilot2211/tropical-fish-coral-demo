<?php
// Pure parsing helpers: no WordPress calls, so test.php can run them with plain `php`.
// Every parser returns rows shaped like:
// [ id, group, name, size, cost, available, category, images[], url, description ]
// `group` ties sizes of one product together so they import as variations.

// Shopify storefront /products.json — one row per variant (size).
function tfc_si_from_shopify( array $data, $base ) {
	$rows = [];
	foreach ( $data['products'] ?? [] as $p ) {
		$tags = is_array( $p['tags'] ?? '' ) ? implode( ' ', $p['tags'] ) : ( $p['tags'] ?? '' );
		$cat  = tfc_si_classify( ( $p['product_type'] ?? '' ) . ' ' . $tags . ' ' . $p['title'] );
		foreach ( $p['variants'] ?? [] as $v ) {
			$rows[] = tfc_si_row( [
				'id'          => 'shopify:' . $v['id'],
				'group'       => 'shopify:' . $p['id'],
				'name'        => $p['title'],
				'size'        => $v['title'] === 'Default Title' ? '' : $v['title'],
				'cost'        => $v['price'],
				'available'   => ! empty( $v['available'] ),
				'category'    => $cat,
				'cat_text'    => ( $p['product_type'] ?? '' ) . ' ' . $tags,
				'images'      => array_column( $p['images'] ?? [], 'src' ),
				'url'         => $base . '/products/' . $p['handle'],
				'description' => $p['body_html'] ?? '',
			] );
		}
	}
	return $rows;
}

// WooCommerce Store API /wp-json/wc/store/v1/products — one row per product.
function tfc_si_from_woo( array $data ) {
	$rows = [];
	foreach ( $data as $p ) {
		if ( ! isset( $p['prices']['price'] ) ) continue;
		$cats = implode( ' ', array_column( $p['categories'] ?? [], 'name' ) );
		$rows[] = tfc_si_row( [
			'id'          => 'woo:' . $p['id'],
			'group'       => 'woo:' . $p['id'],
			'name'        => $p['name'],
			'cost'        => $p['prices']['price'] / 10 ** (int) ( $p['prices']['currency_minor_unit'] ?? 2 ),
			'available'   => ! empty( $p['is_in_stock'] ),
			'category'    => tfc_si_classify( $cats . ' ' . $p['name'] ),
			'cat_text'    => $cats,
			'images'      => array_column( $p['images'] ?? [], 'src' ),
			'url'         => $p['permalink'] ?? '',
			'description' => $p['description'] ?? '',
		] );
	}
	return $rows;
}

// schema.org Product data embedded in a page's <script type="application/ld+json">.
function tfc_si_from_jsonld( $html, $page_url ) {
	preg_match_all( '#<script[^>]*application/ld\+json[^>]*>(.*?)</script>#is', $html, $m );
	$found = [];
	foreach ( $m[1] as $json ) {
		tfc_si_ld_walk( json_decode( trim( $json ), true ), $found );
	}
	$rows = [];
	foreach ( $found as [ $p, $group ] ) {
		$offer = $p['offers'] ?? [];
		$offer = isset( $offer[0] ) ? $offer[0] : $offer;
		$cost  = $offer['price'] ?? $offer['lowPrice'] ?? null;
		if ( $cost === null ) continue;
		// image can be a URL, an ImageObject, or a list of either.
		$images = $p['image'] ?? [];
		$images = is_string( $images ) || isset( $images['url'] ) ? [ $images ] : (array) $images;
		$images = array_values( array_filter( array_map( fn( $i ) => is_array( $i ) ? ( $i['url'] ?? '' ) : (string) $i, $images ) ) );
		$name  = $p['name'] ?? '';
		$id    = $p['sku'] ?? $p['@id'] ?? $p['url'] ?? $name;
		$rows[] = tfc_si_row( [
			'id'          => 'ld:' . $id,
			'group'       => 'ld:' . ( $group !== '' ? $group : $id ),
			'name'        => $name,
			'size'        => is_string( $p['size'] ?? null ) ? $p['size'] : '',
			'cost'        => $cost,
			'available'   => stripos( (string) ( $offer['availability'] ?? 'InStock' ), 'InStock' ) !== false,
			'category'    => tfc_si_classify( ( is_string( $p['category'] ?? null ) ? $p['category'] : '' ) . ' ' . $name ),
			'cat_text'    => is_string( $p['category'] ?? null ) ? $p['category'] : '',
			'images'      => $images,
			'url'         => $p['url'] ?? $offer['url'] ?? $page_url,
			'description' => $p['description'] ?? '',
		] );
	}
	return $rows;
}

// Collect every Product node, remembering the ProductGroup (sizes) it sits under.
function tfc_si_ld_walk( $node, array &$found, $group = '' ) {
	if ( ! is_array( $node ) ) return;
	$type = (array) ( $node['@type'] ?? [] );
	if ( in_array( 'ProductGroup', $type, true ) ) {
		$group = (string) ( $node['productGroupID'] ?? $node['name'] ?? '' );
	} elseif ( in_array( 'Product', $type, true ) ) {
		$found[] = [ $node, $group ];
		return;
	}
	foreach ( $node as $child ) tfc_si_ld_walk( $child, $found, $group );
}

// ---- Spreadsheets (supplier price / availability lists) --------------------

// Field => [ label, header patterns in priority order ]. Headers are matched lowercased with
// punctuation turned into spaces (except #).
const TFC_SI_SHEET_FIELDS = [
	'name'        => [ 'Name', [ '/^common name/', '/^(product|item) ?name/', '/^name$/', '/^(product|item|species|title)$/', '/description/' ] ],
	'cost'        => [ 'Price / cost', [ '/wholesale|your price|cost/', '/^(unit |regular |reg )?price/', '/price/' ] ],
	'sale'        => [ 'Sale price (used when filled in)', [ '/sale|special|promo/' ] ],
	'size'        => [ 'Size', [ '/size/' ] ],
	'sku'         => [ 'Item # / SKU', [ '/sku|item ?(#|no|num)|part ?(#|no|num)|code|^id$|^#$/', '/upc|barcode|gtin/' ] ],
	'category'    => [ 'Category', [ '/categor|^cat\b|^czt|dept|department|section|group|type/' ] ],
	'qty'         => [ 'Stock / qty', [ '/qty|quantity|stock|avail|on hand/' ] ],
	'weight'      => [ 'Weight (lb)', [ '/weight|^wt|^lbs?$/' ] ],
	'length'      => [ 'Length (in)', [ '/^len/' ] ],
	'width'       => [ 'Width (in)', [ '/^wid|^with$/' ] ],
	'height'      => [ 'Height (in)', [ '/^hei|^hig/' ] ],
	'image'       => [ 'Image URL', [ '/image|photo|picture|img/' ] ],
	'description' => [ 'Description', [ '/descr|decrip|discrip|details|notes/' ] ],
];

// "Bicolor Angel Lg" -> [ 'Bicolor Angel', 'Lg' ]. Suppliers often put the size at the end of
// the name; splitting it off lets the sizes become one product. No size found -> [ name, '' ].
function tfc_si_split_size( $name ) {
	$code = '(?:x{0,2}s|sm|small|md|med|medium|ml|lg|large|x{0,2}l|tiny|jumbo|show)';
	$num  = '\d+(?:\.\d+)?';
	$inch = "$num(?:\"|in\\b)?(?:\\s*-\\s*$num)?(?:\"|in\\b)\\+?"; // 3"  3-4"  3"-4"  3.5"+
	if ( preg_match( "~^(.+?)[\\s,\\-]+({$code}(?:/{$code})?|{$inch}|$num(?:\\s*-\\s*$num)?\\s*lbs?)$~i", trim( $name ), $m ) ) {
		return [ trim( $m[1] ), $m[2] ];
	}
	return [ trim( $name ), '' ];
}

// CSV text -> rows of cells. Handles Excel's BOM and Windows-1252 export, and ; or tab delimiters.
function tfc_si_read_csv( $text ) {
	$text = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
	if ( ! preg_match( '//u', $text ) ) { // not valid UTF-8, so it's Excel's Windows-1252
		if ( function_exists( 'mb_convert_encoding' ) ) $text = mb_convert_encoding( $text, 'UTF-8', 'Windows-1252' );
		elseif ( function_exists( 'iconv' ) ) $text = iconv( 'Windows-1252', 'UTF-8//IGNORE', $text );
	}
	$sample = substr( $text, 0, 4000 );
	$counts = [ ',' => substr_count( $sample, ',' ), ';' => substr_count( $sample, ';' ), "\t" => substr_count( $sample, "\t" ) ];
	arsort( $counts );
	$fh = fopen( 'php://temp', 'r+' );
	fwrite( $fh, $text );
	rewind( $fh );
	$table = [];
	while ( ( $row = fgetcsv( $fh, 0, key( $counts ), '"', '' ) ) !== false ) {
		if ( $row !== [ null ] ) $table[] = $row;
	}
	fclose( $fh );
	return $table;
}

// First worksheet of an .xlsx file -> rows of cell text. Null if it can't be read.
// ponytail: reads sheet1.xml, which is the first tab in files from Excel and Google Sheets.
function tfc_si_read_xlsx( $path ) {
	if ( ! class_exists( 'ZipArchive' ) ) return null;
	$zip = new ZipArchive();
	if ( $zip->open( $path ) !== true ) return null;
	$strings_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
	$sheet_xml   = $zip->getFromName( 'xl/worksheets/sheet1.xml' );
	$zip->close();
	if ( $sheet_xml === false ) return null;

	$strings = [];
	if ( $strings_xml !== false ) {
		foreach ( simplexml_load_string( $strings_xml, 'SimpleXMLElement', LIBXML_NONET )->si as $si ) {
			$s = (string) $si->t;
			foreach ( $si->r as $run ) $s .= (string) $run->t; // text with mixed formatting
			$strings[] = $s;
		}
	}
	$table = [];
	foreach ( simplexml_load_string( $sheet_xml, 'SimpleXMLElement', LIBXML_NONET )->sheetData->row as $row ) {
		$cells = [];
		$col   = -1;
		foreach ( $row->c as $c ) {
			$col  = isset( $c['r'] ) ? tfc_si_col_index( (string) $c['r'] ) : $col + 1;
			$type = (string) $c['t'];
			$cells[ $col ] = $type === 's' ? ( $strings[ (int) $c->v ] ?? '' ) : ( $type === 'inlineStr' ? (string) $c->is->t : (string) $c->v );
		}
		if ( $cells ) $table[] = array_replace( array_fill( 0, max( array_keys( $cells ) ) + 1, '' ), $cells );
	}
	return $table;
}

// "AB12" -> 27
function tfc_si_col_index( $ref ) {
	$n = 0;
	foreach ( str_split( preg_replace( '/[^A-Z]/', '', strtoupper( $ref ) ) ) as $ch ) $n = $n * 26 + ord( $ch ) - 64;
	return $n - 1;
}

// "$1,299.50 ea" -> 1299.5; nothing numeric -> null.
function tfc_si_number( $s ) {
	return preg_match( '/\d[\d,]*(?:\.\d+)?|\.\d+/', (string) $s, $m ) ? (float) str_replace( ',', '', $m[0] ) : null;
}

// "Weight: 12 oz" -> 0.75 (lb). No unit = lb.
function tfc_si_lbs( $s ) {
	$n = tfc_si_number( $s );
	if ( $n !== null && preg_match( '/\d\s*(oz|kg|g)\b/i', (string) $s, $m ) ) $n *= [ 'oz' => 1 / 16, 'kg' => 2.20462, 'g' => 0.00220462 ][ strtolower( $m[1] ) ];
	return $n === null ? null : round( $n, 3 );
}

// "140 mm" -> 5.51 (in). No unit = inches.
function tfc_si_inches( $s ) {
	$n = tfc_si_number( $s );
	if ( $n !== null && preg_match( '/\d\s*(mm|cm|ft)\b/i', (string) $s, $m ) ) $n *= [ 'mm' => 1 / 25.4, 'cm' => 1 / 2.54, 'ft' => 12 ][ strtolower( $m[1] ) ];
	return $n === null ? null : round( $n, 2 );
}

// "Size: 15.3 cm x 8.1 cm x 5.31 cm" -> [ length, width, height ] in inches, or null if it isn't L x W x H.
function tfc_si_dims( $s ) {
	$num = '(\d+(?:\.\d+)?\s*(?:in|mm|cm|ft|")?)';
	return preg_match( "~$num\s*x\s*$num\s*x\s*$num~i", (string) $s, $m ) ? array_map( 'tfc_si_inches', [ $m[1], $m[2], $m[3] ] ) : null;
}

// "SKU: 3F96385BE" -> "3F96385BE" (some supplier exports label every value).
function tfc_si_unlabel( $s ) {
	return trim( preg_replace( '/^[a-z][a-z ]{1,15}:\s*/i', '', (string) $s ) );
}

// Find the header row (the first of the top 20 with a name and a price column) and guess
// which column holds each field. Returns [ header row index, [ field => column index ] ].
function tfc_si_guess_columns( array $table ) {
	foreach ( array_slice( $table, 0, 20, true ) as $i => $row ) {
		$heads = array_map( fn( $c ) => trim( preg_replace( '/[^a-z0-9#]+/', ' ', strtolower( (string) $c ) ) ), $row );
		$map   = [];
		foreach ( TFC_SI_SHEET_FIELDS as $field => [ , $patterns ] ) {
			foreach ( $patterns as $pattern ) {
				foreach ( $heads as $col => $h ) {
					if ( $h !== '' && ! in_array( $col, $map, true ) && preg_match( $pattern, $h ) ) {
						$map[ $field ] = $col;
						continue 3;
					}
				}
			}
		}
		if ( isset( $map['name'], $map['cost'] ) ) return [ $i, $map ];
	}
	return [ 0, [] ];
}

// Rows under the header -> importer rows.
// - Rows without a price are skipped. A row with a single filled cell ("ANGELFISH", "Soft Corals")
//   is a section heading that helps sort the rows below it into fish / coral / dry.
// - Same name with different sizes = one product with a Size option. Sizes can be their own
//   column or the end of the name ("Bicolor Angel Lg"); a size is only split off a name when
//   another row shares the rest of the name, so one-off names like "Trace A - 500 mL" stay whole.
// - Rows with their own item # / SKU stay separate products (e.g. one-of-a-kind coral colonies);
//   exact repeats are listed once.
function tfc_si_from_table( array $table, $header, array $map ) {
	$get = fn( array $row, $f ) => isset( $map[ $f ] ) ? trim( (string) ( $row[ $map[ $f ] ] ?? '' ) ) : '';
	// Every category-looking column (cat-1, cat-2, Type…) helps decide fish / coral / dry.
	$cat_cols = array_keys( array_filter( $table[ $header ] ?? [], fn( $h ) => preg_match( '/^(cat|czt|type|categor|dept|department|section|group)/i', trim( (string) $h ) ) ) );
	if ( isset( $map['category'] ) ) $cat_cols[] = $map['category'];

	// Pass 1: priced rows, their section heading, and how often each name-minus-size occurs.
	$priced  = [];
	$bases   = [];
	$section = '';
	foreach ( array_slice( $table, $header + 1 ) as $row ) {
		$name   = preg_replace( '/\s+/u', ' ', $get( $row, 'name' ) );
		$cost   = tfc_si_number( $get( $row, 'sale' ) ) ?? tfc_si_number( $get( $row, 'cost' ) );
		$filled = array_values( array_filter( array_map( fn( $c ) => trim( (string) $c ), $row ), 'strlen' ) );
		if ( $cost === null && count( $filled ) === 1 ) $section = $filled[0]; // heading, in whatever column
		if ( $name === '' || $cost === null ) continue;
		$split    = tfc_si_split_size( $name );
		$priced[] = [ $row, $name, $cost, $section, $split ];
		if ( $split[1] !== '' ) $bases[ strtolower( $split[0] ) ] = ( $bases[ strtolower( $split[0] ) ] ?? 0 ) + 1;
	}

	// Pass 2: build the rows.
	$rows = [];
	$seen = [];
	foreach ( $priced as [ $row, $name, $cost, $section, $split ] ) {
		$size = tfc_si_unlabel( $get( $row, 'size' ) );
		$dims = tfc_si_dims( $size );
		if ( $dims ) $size = ''; // "8 in x 3 in x 4 in" is a box size, not a product size
		if ( $size === '' && $split[1] !== '' && $bases[ strtolower( $split[0] ) ] > 1 ) [ $name, $size ] = $split;
		$sku = tfc_si_unlabel( $get( $row, 'sku' ) );
		$key = strtolower( $name );
		$id  = 'sheet:' . ( $sku !== '' ? $sku : $key . '|' . strtolower( $size ) );
		if ( isset( $seen[ $id ] ) ) continue;
		$seen[ $id ] = true;

		$cat_text = $section;
		foreach ( array_unique( $cat_cols ) as $c ) $cat_text .= ' ' . ( $row[ $c ] ?? '' );
		$qty   = strtolower( tfc_si_unlabel( $get( $row, 'qty' ) ) );
		$image = $get( $row, 'image' );
		$dim   = fn( $f, $i ) => tfc_si_inches( $get( $row, $f ) ) ?? ( $dims[ $i ] ?? null );
		$rows[] = tfc_si_row( [
			'id'          => $id,
			'group'       => 'sheet:' . ( $size === '' && $sku !== '' ? $sku : $key ),
			'name'        => $name,
			'size'        => $size,
			'cost'        => $cost,
			'available'   => $qty === '' || ( is_numeric( $qty ) ? $qty > 0 : ! preg_match( '/\b(no|out|sold|none|n\/a)\b/', $qty ) ),
			// The sheet's own categories / section win over words in the name ("Coral Beauty" is a fish).
			'category'    => tfc_si_classify( $cat_text, null ) ?? tfc_si_classify( $name ),
			'cat_text'    => trim( $cat_text ),
			'weight'      => tfc_si_lbs( $get( $row, 'weight' ) ),
			'length'      => $dim( 'length', 0 ),
			'width'       => $dim( 'width', 1 ),
			'height'      => $dim( 'height', 2 ),
			'images'      => filter_var( $image, FILTER_VALIDATE_URL ) ? [ $image ] : [],
			'description' => preg_replace( '/^\s*description\s*:?\s*/i', '', $get( $row, 'description' ) ),
		] );
	}
	return $rows;
}

function tfc_si_row( array $r ) {
	// cat_text = the supplier's own category words, used to pick a store sub-category.
	$r += [ 'size' => '', 'available' => true, 'images' => [], 'url' => '', 'description' => '', 'weight' => null, 'length' => null, 'width' => null, 'height' => null, 'cat_text' => '' ];
	$r['name'] = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $r['name'], ENT_QUOTES, 'UTF-8' ) ) );
	$r['cost'] = (float) $r['cost'];
	return $r;
}

// Pick the most specific store category for a product. $cands = [ [ id, depth, keywords[] ], ... ]
// (the store's categories under Fish, Corals, Supplies…). A keyword matches at the start of a word
// in the supplier's own category text or the product name. Deeper categories win ("Tangs" beats
// "Fish"), then a hit in the supplier's category, then the longer keyword. Null if nothing matches.
function tfc_si_pick_term( array $cands, $cat_text, $name ) {
	$best  = null;
	$score = -1;
	foreach ( $cands as $c ) {
		foreach ( $c['keywords'] as $kw ) {
			$re     = '/\b' . preg_quote( $kw, '/' ) . '/i';
			$in_cat = preg_match( $re, (string) $cat_text );
			if ( ! $in_cat && ! preg_match( $re, (string) $name ) ) continue;
			$s = $c['depth'] * 1000 + ( $in_cat ? 100 : 0 ) + strlen( $kw );
			if ( $s > $score ) [ $score, $best ] = [ $s, $c['id'] ];
		}
	}
	return $best;
}

// ---- Finding photos on a supplier's website ---------------------------------------------------

// Words that must all appear in a search result's title for it to count as the same product.
// Drops the scientific name ("Black Storm - Amphiprion ocellaris" -> black, storm), sizes and filler.
function tfc_si_key_words( $name ) {
	$name = preg_replace( '/\s+[-–—]\s+.*$/u', '', html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) ); // " - Scientific name" (any dash)
	$name = preg_replace( '/\([^)]*\)/', ' ', $name );                                                     // "(3.5 Inches)"
	$words = preg_split( '/[^a-z0-9]+/', strtolower( $name ), -1, PREG_SPLIT_NO_EMPTY );
	$skip  = [ 'the', 'and', 'with', 'for', 'xs', 'sm', 'md', 'lg', 'xl', 'xxl', 'small', 'medium', 'large', 'tiny', 'show', 'size', 'inch', 'inches', 'lbs' ];
	return array_values( array_unique( array_filter( $words, fn( $w ) => strlen( $w ) > 1 && ! in_array( $w, $skip, true ) && ! is_numeric( $w ) ) ) );
}

// The search query to send: the name without scientific name, sizes or punctuation.
function tfc_si_search_query( $name ) {
	return implode( ' ', tfc_si_key_words( $name ) );
}

// From a supplier's search results page, the image of the result whose title contains every key
// word of $name (the closest-titled one if several do). Null when nothing is a confident match.
function tfc_si_match_image( $html, $name, $page_url ) {
	$need = tfc_si_key_words( $name );
	if ( count( $need ) < 2 ) return null; // one word ("Naso") is too vague to be sure it's the same animal
	$u    = parse_url( $page_url );
	$root = ( $u['scheme'] ?? 'https' ) . '://' . ( $u['host'] ?? '' );
	$best = null;
	$extra_best = PHP_INT_MAX;
	preg_match_all( '/<img\b[^>]*>/i', (string) $html, $tags );
	foreach ( $tags[0] as $tag ) {
		preg_match_all( '/([a-z-]+)\s*=\s*("([^"]*)"|\'([^\']*)\')/i', $tag, $am, PREG_SET_ORDER );
		$attr = [];
		foreach ( $am as $a ) $attr[ strtolower( $a[1] ) ] = html_entity_decode( $a[3] !== '' ? $a[3] : ( $a[4] ?? '' ), ENT_QUOTES, 'UTF-8' );
		$title = $attr['alt'] ?? $attr['title'] ?? '';
		$have  = preg_split( '/[^a-z0-9]+/', strtolower( $title ), -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $have || ! tfc_si_all_words_in( $need, $have ) ) continue; // every key word must be in the title
		$src = tfc_si_largest_src( $attr );
		if ( $src === '' || strpos( $src, 'data:' ) === 0 ) continue;
		$extra = count( $have ) - count( $need );
		if ( $extra < $extra_best ) {
			$extra_best = $extra;
			$best       = strpos( $src, '//' ) === 0 ? 'https:' . $src : ( strpos( $src, '/' ) === 0 ? $root . $src : $src );
		}
	}
	return $best;
}

// Every needed word appears among $have, counting short forms: "clownfish" ~ "clown",
// "angel" ~ "angelfish", "tang" ~ "tangs" (one must start with the other, 4+ letters).
function tfc_si_all_words_in( array $need, array $have ) {
	foreach ( $need as $w ) {
		$ok = false;
		foreach ( $have as $h ) {
			if ( $h === $w || ( min( strlen( $h ), strlen( $w ) ) >= 4 && ( strpos( $w, $h ) === 0 || strpos( $h, $w ) === 0 ) ) ) {
				$ok = true;
				break;
			}
		}
		if ( ! $ok ) return false;
	}
	return true;
}

// Biggest candidate from srcset / data-srcset, else data-src / src; then ask image CDNs for a large copy.
function tfc_si_largest_src( array $attr ) {
	$src = $attr['data-src'] ?? $attr['src'] ?? '';
	$max = 0;
	foreach ( [ 'data-srcset', 'srcset' ] as $k ) {
		foreach ( explode( ',', $attr[ $k ] ?? '' ) as $cand ) {
			if ( preg_match( '/^\s*(\S+)\s+(\d+)w/', $cand, $m ) && (int) $m[2] > $max ) [ $max, $src ] = [ (int) $m[2], $m[1] ];
		}
	}
	$src = preg_replace( '#/stencil/[0-9x]+w?/#', '/stencil/1280x1280/', $src ); // BigCommerce
	return preg_replace( '/([?&])width=\d+/', '$1width=1200', $src );             // Shopify
}

// Guess fish / coral / dry from product type, tags and title. Checked in that order of
// specificity: supplies first so "Coral Food" or "Fish Net" land in dry goods.
// $fallback is returned when nothing matches ('dry', or null to ask "did anything match?").
// ponytail: keyword guess; every row has a category dropdown to correct it.
function tfc_si_classify( $text, $fallback = 'dry' ) {
	$t = strtolower( $text );
	if ( preg_match( '/\b(dry|supplies|equipment|foods?|pellets?|flakes?|salt|pumps?|lights?|lighting|led|filters?|test|kits?|glue|heaters?|skimmers?|media|supplements?|additives?|nets?|reactors?|controllers?|sump|tubing|fittings?|dosing|frozen)\b/', $t ) ) return 'dry';
	if ( preg_match( '/\b(coral\w*|frags?|zoa\w*|acro\w*|sps|lps|mushrooms?|ricordea|euphyllia|torch|hammer|monti\w*|goniopora|chalice|anemones?|clams?|polyps?|leather|toadstool|xenia)\b/', $t ) ) return 'coral';
	if ( preg_match( '/\b(\w*fish|tangs?|clown\w*|gob(y|ies)|wrasses?|angel\w*|damsel\w*|blenn\w*|chromis|basslets?|anthias|puffers?|eels?|cardinal\w*|dottybacks?|shrimp|crabs?|snails?|urchins?|inverts?|invertebrates?|livestock)\b/', $t ) ) return 'fish';
	return $fallback;
}

// Shipping for one order to one state (shipping.php supplies the inputs).
// $rate  = [ live_base, live_lb, dry_base, dry_lb, live => can ship live? ] or null if no rates.
// $lines = [ [ live => bool, lbs => weight of one, qty => n ], ... ]
// Each type in the order pays its base + per-lb charge, so a mixed order pays both.
// Returns null when the order can't ship there.
function tfc_sr_cost( $rate, array $lines ) {
	if ( ! $rate ) return null;
	$lbs = [];
	foreach ( $lines as $l ) {
		$type          = $l['live'] ? 'live' : 'dry';
		$lbs[ $type ] = ( $lbs[ $type ] ?? 0 ) + $l['lbs'] * $l['qty'];
	}
	if ( isset( $lbs['live'] ) && empty( $rate['live'] ) ) return null;
	$cost = 0;
	foreach ( $lbs as $type => $w ) $cost += (float) $rate[ "{$type}_base" ] + (float) $rate[ "{$type}_lb" ] * $w;
	return round( $cost, 2 );
}

// $type is 'percent' or 'flat'. Half cents round up (70.99 + 50% = 106.49), which plain
// round() gets wrong because 106.485 is stored as 106.48499…
function tfc_si_markup( $cost, $type, $amount ) {
	$price = $type === 'flat' ? $cost + $amount : $cost * ( 1 + $amount / 100 );
	return round( round( $price * 100, 4 ) ) / 100;
}

// key => [ label, WooCommerce category path ]. Paths match the theme's live-goods / dry-goods slugs.
const TFC_SI_CATS = [
	'fish'  => [ 'Fish', 'Live Goods > Fish' ],
	'coral' => [ 'Corals', 'Live Goods > Corals' ],
	'dry'   => [ 'Dry Goods', 'Dry Goods' ],
];

// Picked rows ({i, cat, weight} from the form) -> [ group => rows with price & weight ].
// Weight: typed in the row, else from the supplier's sheet, else the category default.
// Sizes of one product take the first size's category, so one product gets one markup.
function tfc_si_prepare( array $rows, array $picked, array $mk ) {
	$groups = [];
	foreach ( $picked as $p ) {
		$r = $rows[ (int) ( $p['i'] ?? -1 ) ] ?? null;
		if ( ! $r ) continue;
		if ( isset( TFC_SI_CATS[ $p['cat'] ?? '' ] ) ) $r['category'] = $p['cat'];
		$r['weight'] = is_numeric( $p['weight'] ?? '' ) ? (float) $p['weight'] : ( $r['weight'] ?? null );
		$groups[ $r['group'] ][] = $r;
	}
	foreach ( $groups as $g => $items ) {
		$m = $mk[ $items[0]['category'] ];
		foreach ( $items as $k => $r ) {
			$groups[ $g ][ $k ]['category'] = $items[0]['category'];
			$groups[ $g ][ $k ]['price']    = tfc_si_markup( $r['cost'], $m['price_type'], $m['price'] );
			$groups[ $g ][ $k ]['weight']   = $r['weight'] ?? ( $m['weight'] ? (float) $m['weight'] : null );
		}
	}
	return $groups;
}

// WooCommerce's own product CSV format (Products > Import). SKUs link sizes to their parent
// and let a re-import update existing products instead of duplicating them.
// $unit / $dim are the store's weight and dimension units, which Woo's importer expects in the headers.
function tfc_si_csv_head( $unit = 'lbs', $dim = 'in' ) {
	return [
		'Type', 'SKU', 'Parent', 'Name', 'Published', 'Description', 'Categories', 'Images', 'In stock?', 'Regular price',
		"Weight ($unit)", "Length ($dim)", "Width ($dim)", "Height ($dim)",
		'Attribute 1 name', 'Attribute 1 value(s)', 'Attribute 1 visible', 'Attribute 1 global',
		'Meta: _tfc_si_group', 'Meta: _tfc_si_id', 'Meta: _tfc_si_cost',
	];
}

function tfc_si_csv_rows( array $groups, $unit = 'lbs', $dim = 'in' ) {
	$head = tfc_si_csv_head( $unit, $dim );
	$line = fn( array $cols ) => array_map( fn( $h ) => $cols[ $h ] ?? '', $head );
	$list = fn( array $vals ) => implode( ', ', str_replace( ',', '\\,', $vals ) ); // Woo's escaped-comma list
	$sku  = fn( $id ) => 'tfc-' . trim( preg_replace( '/[^a-z0-9]+/i', '-', $id ), '-' );
	$out  = [ $head ];
	foreach ( $groups as $group => $items ) {
		$first  = $items[0];
		$parent = [
			'SKU'                 => $sku( $group ),
			'Name'                => $first['name'],
			'Published'           => 1,
			'Description'         => $first['description'],
			'Categories'          => $first['cat_path'] ?? TFC_SI_CATS[ $first['category'] ][1],
			'Images'              => $list( $first['images'] ),
			'Meta: _tfc_si_group' => $group,
		];
		$prices = fn( array $r ) => [
			'In stock?'          => (int) $r['available'],
			'Regular price'      => $r['price'],
			"Weight ($unit)"     => $r['weight'],
			"Length ($dim)"      => $r['length'] ?? null,
			"Width ($dim)"       => $r['width'] ?? null,
			"Height ($dim)"      => $r['height'] ?? null,
			'Meta: _tfc_si_id'   => $r['id'],
			'Meta: _tfc_si_cost' => $r['cost'],
		];
		if ( $first['size'] === '' ) {
			$out[] = $line( $parent + [ 'Type' => 'simple' ] + $prices( $first ) );
			continue;
		}
		$out[] = $line( $parent + [
			'Type'                 => 'variable',
			'Attribute 1 name'     => 'Size',
			'Attribute 1 value(s)' => $list( array_column( $items, 'size' ) ),
			'Attribute 1 visible'  => 1,
			'Attribute 1 global'   => 0,
		] );
		foreach ( $items as $r ) {
			$out[] = $line( [
				'Type'                 => 'variation',
				'SKU'                  => $sku( $r['id'] ),
				'Parent'               => $sku( $group ),
				'Name'                 => $r['name'] . ' - ' . $r['size'],
				'Published'            => 1,
				'Attribute 1 name'     => 'Size',
				'Attribute 1 value(s)' => $list( [ $r['size'] ] ),
				'Attribute 1 global'   => 0,
			] + $prices( $r ) );
		}
	}
	return $out;
}
