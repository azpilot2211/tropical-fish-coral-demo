<?php
// Pure parsing helpers: no WordPress calls, so test.php can run them with plain `php`.
// Every parser returns rows shaped like:
// [ id, group, name, size, cost, available, category, images[], url, description ]
// `group` ties sizes of one product together so they import as variations.

// Shopify storefront /products.json — one row per variant (size).
function tfc_si_from_shopify( array $data, $base ) {
	$rows = [];
	foreach ( $data['products'] ?? [] as $p ) {
		$tags = is_array( $p['tags'] ?? '' ) ? implode( ' ', $p['tags'] ) : ( $p['tags'] ?? '' );
		$cat  = tfc_si_classify( ( $p['product_type'] ?? '' ) . ' ' . $tags . ' ' . $p['title'] );
		foreach ( $p['variants'] ?? [] as $v ) {
			$rows[] = tfc_si_row( [
				'id'          => 'shopify:' . $v['id'],
				'group'       => 'shopify:' . $p['id'],
				'name'        => $p['title'],
				'size'        => $v['title'] === 'Default Title' ? '' : $v['title'],
				'cost'        => $v['price'],
				'available'   => ! empty( $v['available'] ),
				'category'    => $cat,
				'cat_text'    => ( $p['product_type'] ?? '' ) . ' ' . $tags,
				'images'      => array_column( $p['images'] ?? [], 'src' ),
				'url'         => $base . '/products/' . $p['handle'],
				'description' => $p['body_html'] ?? '',
			] );
		}
	}
	return $rows;
}

// WooCommerce Store API /wp-json/wc/store/v1/products — one row per product.
function tfc_si_from_woo( array $data ) {
	$rows = [];
	foreach ( $data as $p ) {
		if ( ! isset( $p['prices']['price'] ) ) continue;
		$cats = implode( ' ', array_column( $p['categories'] ?? [], 'name' ) );
		$rows[] = tfc_si_row( [
			'id'          => 'woo:' . $p['id'],
			'group'       => 'woo:' . $p['id'],
			'name'        => $p['name'],
			'cost'        => $p['prices']['price'] / 10 ** (int) ( $p['prices']['currency_minor_unit'] ?? 2 ),
			'available'   => ! empty( $p['is_in_stock'] ),
			'category'    => tfc_si_classify( $cats . ' ' . $p['name'] ),
			'cat_text'    => $cats,
			'images'      => array_column( $p['images'] ?? [], 'src' ),
			'url'         => $p['permalink'] ?? '',
			'description' => $p['description'] ?? '',
		] );
	}
	return $rows;
}

// schema.org Product data embedded in a page's <script type="application/ld+json">.
function tfc_si_from_jsonld( $html, $page_url ) {
	preg_match_all( '#<script[^>]*application/ld\+json[^>]*>(.*?)</script>#is', $html, $m );
	$found = [];
	foreach ( $m[1] as $json ) {
		tfc_si_ld_walk( json_decode( trim( $json ), true ), $found );
	}
	$rows = [];
	foreach ( $found as [ $p, $group ] ) {
		$offer = $p['offers'] ?? [];
		$offer = isset( $offer[0] ) ? $offer[0] : $offer;
		$cost  = $offer['price'] ?? $offer['lowPrice'] ?? null;
		if ( $cost === null ) continue;
		// image can be a URL, an ImageObject, or a list of either.
		$images = $p['image'] ?? [];
		$images = is_string( $images ) || isset( $images['url'] ) ? [ $images ] : (array) $images;
		$images = array_values( array_filter( array_map( fn( $i ) => is_array( $i ) ? ( $i['url'] ?? '' ) : (string) $i, $images ) ) );
		$name  = $p['name'] ?? '';
		$id    = $p['sku'] ?? $p['@id'] ?? $p['url'] ?? $name;
		$rows[] = tfc_si_row( [
			'id'          => 'ld:' . $id,
			'group'       => 'ld:' . ( $group !== '' ? $group : $id ),
			'name'        => $name,
			'size'        => is_string( $p['size'] ?? null ) ? $p['size'] : '',
			'cost'        => $cost,
			'available'   => stripos( (string) ( $offer['availability'] ?? 'InStock' ), 'InStock' ) !== false,
			'category'    => tfc_si_classify( ( is_string( $p['category'] ?? null ) ? $p['category'] : '' ) . ' ' . $name ),
			'cat_text'    => is_string( $p['category'] ?? null ) ? $p['category'] : '',
			'images'      => $images,
			'url'         => $p['url'] ?? $offer['url'] ?? $page_url,
			'description' => $p['description'] ?? '',
		] );
	}
	return $rows;
}

// Collect every Product node, remembering the ProductGroup (sizes) it sits under.
function tfc_si_ld_walk( $node, array &$found, $group = '' ) {
	if ( ! is_array( $node ) ) return;
	$type = (array) ( $node['@type'] ?? [] );
	if ( in_array( 'ProductGroup', $type, true ) ) {
		$group = (string) ( $node['productGroupID'] ?? $node['name'] ?? '' );
	} elseif ( in_array( 'Product', $type, true ) ) {
		$found[] = [ $node, $group ];
		return;
	}
	foreach ( $node as $child ) tfc_si_ld_walk( $child, $found, $group );
}

// ---- Spreadsheets (supplier price / availability lists) --------------------

// Field => [ label, header patterns in priority order ]. Headers are matched lowercased with
// punctuation turned into spaces (except #).
const TFC_SI_SHEET_FIELDS = [
	'name'        => [ 'Name', [ '/^common name/', '/^(product|item) ?name/', '/^name$/', '/^(product|item|species|title)$/', '/description/' ] ],
	'cost'        => [ 'Price / cost', [ '/wholesale|your price|cost/', '/^(unit |regular |reg )?price/', '/price/' ] ],
	'sale'        => [ 'Sale price (used when filled in)', [ '/sale|special|promo/' ] ],
	'size'        => [ 'Size', [ '/size/' ] ],
	'sku'         => [ 'Item # / SKU', [ '/sku|item ?(#|no|num)|part ?(#|no|num)|code|^id$|^#$/', '/upc|barcode|gtin/' ] ],
	'category'    => [ 'Category', [ '/categor|^cat\b|^czt|dept|department|section|group|type/' ] ],
	'qty'         => [ 'Stock / qty', [ '/qty|quantity|stock|avail|on hand/' ] ],
	'weight'      => [ 'Weight (lb)', [ '/weight|^wt|^lbs?$/' ] ],
	'length'      => [ 'Length (in)', [ '/^len/' ] ],
	'width'       => [ 'Width (in)', [ '/^wid|^with$/' ] ],
	'height'      => [ 'Height (in)', [ '/^hei|^hig/' ] ],
	'image'       => [ 'Image URL', [ '/image|photo|picture|img/' ] ],
	'description' => [ 'Description', [ '/descr|decrip|discrip|details|notes/' ] ],
];

// "Bicolor Angel Lg" -> [ 'Bicolor Angel', 'Lg' ]. Suppliers often put the size at the end of
// the name; splitting it off lets the sizes become one product. No size found -> [ name, '' ].
function tfc_si_split_size( $name ) {
	$code = '(?:x{0,2}s|sm|small|md|med|medium|ml|lg|large|x{0,2}l|tiny|jumbo|show)';
	$num  = '\d+(?:\.\d+)?';
	$inch = "$num(?:\"|in\\b)?(?:\\s*-\\s*$num)?(?:\"|in\\b)\\+?"; // 3"  3-4"  3"-4"  3.5"+
	if ( preg_match( "~^(.+?)[\\s,\\-]+({$code}(?:/{$code})?|{$inch}|$num(?:\\s*-\\s*$num)?\\s*lbs?)$~i", trim( $name ), $m ) ) {
		return [ trim( $m[1] ), $m[2] ];
	}
	return [ trim( $name ), '' ];
}

// CSV text -> rows of cells. Handles Excel's BOM and Windows-1252 export, and ; or tab delimiters.
function tfc_si_read_csv( $text ) {
	$text = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
	if ( ! preg_match( '//u', $text ) ) { // not valid UTF-8, so it's Excel's Windows-1252
		if ( function_exists( 'mb_convert_encoding' ) ) $text = mb_convert_encoding( $text, 'UTF-8', 'Windows-1252' );
		elseif ( function_exists( 'iconv' ) ) $text = iconv( 'Windows-1252', 'UTF-8//IGNORE', $text );
	}
	$sample = substr( $text, 0, 4000 );
	$counts = [ ',' => substr_count( $sample, ',' ), ';' => substr_count( $sample, ';' ), "\t" => substr_count( $sample, "\t" ) ];
	arsort( $counts );
	$fh = fopen( 'php://temp', 'r+' );
	fwrite( $fh, $text );
	rewind( $fh );
	$table = [];
	while ( ( $row = fgetcsv( $fh, 0, key( $counts ), '"', '' ) ) !== false ) {
		if ( $row !== [ null ] ) $table[] = $row;
	}
	fclose( $fh );
	return $table;
}

// First worksheet of an .xlsx file -> rows of cell text. Null if it can't be read.
// ponytail: reads sheet1.xml, which is the first tab in files from Excel and Google Sheets.
function tfc_si_read_xlsx( $path ) {
	if ( ! class_exists( 'ZipArchive' ) ) return null;
	$zip = new ZipArchive();
	if ( $zip->open( $path ) !== true ) return null;
	$strings_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
	$sheet_xml   = $zip->getFromName( 'xl/worksheets/sheet1.xml' );
	$zip->close();
	if ( $sheet_xml === false ) return null;

	$strings = [];
	if ( $strings_xml !== false ) {
		foreach ( simplexml_load_string( $strings_xml, 'SimpleXMLElement', LIBXML_NONET )->si as $si ) {
			$s = (string) $si->t;
			foreach ( $si->r as $run ) $s .= (string) $run->t; // text with mixed formatting
			$strings[] = $s;
		}
	}
	$table = [];
	foreach ( simplexml_load_string( $sheet_xml, 'SimpleXMLElement', LIBXML_NONET )->sheetData->row as $row ) {
		$cells = [];
		$col   = -1;
		foreach ( $row->c as $c ) {
			$col  = isset( $c['r'] ) ? tfc_si_col_index( (string) $c['r'] ) : $col + 1;
			$type = (string) $c['t'];
			$cells[ $col ] = $type === 's' ? ( $strings[ (int) $c->v ] ?? '' ) : ( $type === 'inlineStr' ? (string) $c->is->t : (string) $c->v );
		}
		if ( $cells ) $table[] = array_replace( array_fill( 0, max( array_keys( $cells ) ) + 1, '' ), $cells );
	}
	return $table;
}

// "AB12" -> 27
function tfc_si_col_index( $ref ) {
	$n = 0;
	foreach ( str_split( preg_replace( '/[^A-Z]/', '', strtoupper( $ref ) ) ) as $ch ) $n = $n * 26 + ord( $ch ) - 64;
	return $n - 1;
}

// "$1,299.50 ea" -> 1299.5; nothing numeric -> null.
function tfc_si_number( $s ) {
	return preg_match( '/\d[\d,]*(?:\.\d+)?|\.\d+/', (string) $s, $m ) ? (float) str_replace( ',', '', $m[0] ) : null;
}

// "Weight: 12 oz" -> 0.75 (lb). No unit = lb.
function tfc_si_lbs( $s ) {
	$n = tfc_si_number( $s );
	if ( $n !== null && preg_match( '/\d\s*(oz|kg|g)\b/i', (string) $s, $m ) ) $n *= [ 'oz' => 1 / 16, 'kg' => 2.20462, 'g' => 0.00220462 ][ strtolower( $m[1] ) ];
	return $n === null ? null : round( $n, 3 );
}

// "140 mm" -> 5.51 (in). No unit = inches.
function tfc_si_inches( $s ) {
	$n = tfc_si_number( $s );
	if ( $n !== null && preg_match( '/\d\s*(mm|cm|ft)\b/i', (string) $s, $m ) ) $n *= [ 'mm' => 1 / 25.4, 'cm' => 1 / 2.54, 'ft' => 12 ][ strtolower( $m[1] ) ];
	return $n === null ? null : round( $n, 2 );
}

// "Size: 15.3 cm x 8.1 cm x 5.31 cm" -> [ length, width, height ] in inches, or null if it isn't L x W x H.
function tfc_si_dims( $s ) {
	$num = '(\d+(?:\.\d+)?\s*(?:in|mm|cm|ft|")?)';
	return preg_match( "~$num\s*x\s*$num\s*x\s*$num~i", (string) $s, $m ) ? array_map( 'tfc_si_inches', [ $m[1], $m[2], $m[3] ] ) : null;
}

// "SKU: 3F96385BE" -> "3F96385BE" (some supplier exports label every value).
function tfc_si_unlabel( $s ) {
	return trim( preg_replace( '/^[a-z][a-z ]{1,15}:\s*/i', '', (string) $s ) );
}

// Find the header row (the first of the top 20 with a name and a price column) and guess
// which column holds each field. Returns [ header row index, [ field => column index ] ].
function tfc_si_guess_columns( array $table ) {
	foreach ( array_slice( $table, 0, 20, true ) as $i => $row ) {
		$heads = array_map( fn( $c ) => trim( preg_replace( '/[^a-z0-9#]+/', ' ', strtolower( (string) $c ) ) ), $row );
		$map   = [];
		foreach ( TFC_SI_SHEET_FIELDS as $field => [ , $patterns ] ) {
			foreach ( $patterns as $pattern ) {
				foreach ( $heads as $col => $h ) {
					if ( $h !== '' && ! in_array( $col, $map, true ) && preg_match( $pattern, $h ) ) {
						$map[ $field ] = $col;
						continue 3;
					}
				}
			}
		}
		if ( isset( $map['name'], $map['cost'] ) ) return [ $i, $map ];
	}
	return [ 0, [] ];
}

// Rows under the header -> importer rows.
// - Rows without a price are skipped. A row with a single filled cell ("ANGELFISH", "Soft Corals")
//   is a section heading that helps sort the rows below it into fish / coral / dry.
// - Same name with different sizes = one product with a Size option. Sizes can be their own
//   column or the end of the name ("Bicolor Angel Lg"); a size is only split off a name when
//   another row shares the rest of the name, so one-off names like "Trace A - 500 mL" stay whole.
// - Rows with their own item # / SKU stay separate products (e.g. one-of-a-kind coral colonies);
//   exact repeats are listed once.
function tfc_si_from_table( array $table, $header, array $map ) {
	$get = fn( array $row, $f ) => isset( $map[ $f ] ) ? trim( (string) ( $row[ $map[ $f ] ] ?? '' ) ) : '';
	// Every category-looking column (cat-1, cat-2, Type…) helps decide fish / coral / dry.
	$cat_cols = array_keys( array_filter( $table[ $header ] ?? [], fn( $h ) => preg_match( '/^(cat|czt|type|categor|dept|department|section|group)/i', trim( (string) $h ) ) ) );
	if ( isset( $map['category'] ) ) $cat_cols[] = $map['category'];

	// Pass 1: priced rows, their section heading, and how often each name-minus-size occurs.
	$priced  = [];
	$bases   = [];
	$section = '';
	foreach ( array_slice( $table, $header + 1 ) as $row ) {
		$name   = preg_replace( '/\s+/u', ' ', $get( $row, 'name' ) );
		$cost   = tfc_si_number( $get( $row, 'sale' ) ) ?? tfc_si_number( $get( $row, 'cost' ) );
		$filled = array_values( array_filter( array_map( fn( $c ) => trim( (string) $c ), $row ), 'strlen' ) );
		if ( $cost === null && count( $filled ) === 1 ) $section = $filled[0]; // heading, in whatever column
		if ( $name === '' || $cost === null ) continue;
		$split    = tfc_si_split_size( $name );
		$priced[] = [ $row, $name, $cost, $section, $split ];
		if ( $split[1] !== '' ) $bases[ strtolower( $split[0] ) ] = ( $bases[ strtolower( $split[0] ) ] ?? 0 ) + 1;
	}

	// Pass 2: build the rows.
	$rows = [];
	$seen = [];
	foreach ( $priced as [ $row, $name, $cost, $section, $split ] ) {
		$size = tfc_si_unlabel( $get( $row, 'size' ) );
		$dims = tfc_si_dims( $size );
		if ( $dims ) $size = ''; // "8 in x 3 in x 4 in" is a box size, not a product size
		if ( $size === '' && $split[1] !== '' && $bases[ strtolower( $split[0] ) ] > 1 ) [ $name, $size ] = $split;
		$sku = tfc_si_unlabel( $get( $row, 'sku' ) );
		$key = strtolower( $name );
		$id  = 'sheet:' . ( $sku !== '' ? $sku : $key . '|' . strtolower( $size ) );
		if ( isset( $seen[ $id ] ) ) continue;
		$seen[ $id ] = true;

		$cat_text = $section;
		foreach ( array_unique( $cat_cols ) as $c ) $cat_text .= ' ' . ( $row[ $c ] ?? '' );
		$qty   = strtolower( tfc_si_unlabel( $get( $row, 'qty' ) ) );
		$image = $get( $row, 'image' );
		$dim   = fn( $f, $i ) => tfc_si_inches( $get( $row, $f ) ) ?? ( $dims[ $i ] ?? null );
		$rows[] = tfc_si_row( [
			'id'          => $id,
			'group'       => 'sheet:' . ( $size === '' && $sku !== '' ? $sku : $key ),
			'name'        => $name,
			'size'        => $size,
			'cost'        => $cost,
			'available'   => $qty === '' || ( is_numeric( $qty ) ? $qty > 0 : ! preg_match( '/\b(no|out|sold|none|n\/a)\b/', $qty ) ),
			// The sheet's own categories / section win over words in the name ("Coral Beauty" is a fish).
			'category'    => tfc_si_classify( $cat_text, null ) ?? tfc_si_classify( $name ),
			'cat_text'    => trim( $cat_text ),
			'weight'      => tfc_si_lbs( $get( $row, 'weight' ) ),
			'length'      => $dim( 'length', 0 ),
			'width'       => $dim( 'width', 1 ),
			'height'      => $dim( 'height', 2 ),
			'images'      => filter_var( $image, FILTER_VALIDATE_URL ) ? [ $image ] : [],
			'description' => preg_replace( '/^\s*description\s*:?\s*/i', '', $get( $row, 'description' ) ),
		] );
	}
	return $rows;
}

// Only rows with a price: suppliers that hide prices list items at 0 or leave the price blank.
function tfc_si_priced( array $rows ) {
	return array_values( array_filter( $rows, fn( $r ) => $r['cost'] > 0 ) );
}

function tfc_si_row( array $r ) {
	// cat_text = the supplier's own category words, used to pick a store sub-category.
	$r += [ 'size' => '', 'available' => true, 'images' => [], 'url' => '', 'description' => '', 'weight' => null, 'length' => null, 'width' => null, 'height' => null, 'cat_text' => '' ];
	$r['name'] = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $r['name'], ENT_QUOTES, 'UTF-8' ) ) );
	$r['cost'] = (float) $r['cost'];
	return $r;
}

// Pick the most specific store category for a product. $cands = [ [ id, depth, keywords[] ], ... ]
// (the store's categories under Fish, Corals, Supplies…). A keyword matches at the start of a word
// in the supplier's own category text or the product name. Deeper categories win ("Tangs" beats
// "Fish"), then a hit in the supplier's category, then the longer keyword. Null if nothing matches.
function tfc_si_pick_term( array $cands, $cat_text, $name ) {
	$best  = null;
	$score = -1;
	foreach ( $cands as $c ) {
		foreach ( $c['keywords'] as $kw ) {
			$re     = '/\b' . preg_quote( $kw, '/' ) . '/i';
			$in_cat = preg_match( $re, (string) $cat_text );
			if ( ! $in_cat && ! preg_match( $re, (string) $name ) ) continue;
			$s = $c['depth'] * 1000 + ( $in_cat ? 100 : 0 ) + strlen( $kw );
			if ( $s > $score ) [ $score, $best ] = [ $s, $c['id'] ];
		}
	}
	return $best;
}

// ---- Finding photos on a supplier's website ---------------------------------------------------

// Words that must all appear in a search result's title for it to count as the same product.
// Drops the scientific name ("Black Storm - Amphiprion ocellaris" -> black, storm), sizes and filler.
function tfc_si_key_words( $name ) {
	$name = preg_replace( '/\s+[-–—]\s+.*$/u', '', html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) ); // " - Scientific name" (any dash)
	$name = preg_replace( '/\([^)]*\)/', ' ', $name );                                                     // "(3.5 Inches)"
	$words = preg_split( '/[^a-z0-9]+/', strtolower( $name ), -1, PREG_SPLIT_NO_EMPTY );
	$skip  = [ 'the', 'and', 'with', 'for', 'xs', 'sm', 'md', 'lg', 'xl', 'xxl', 'small', 'medium', 'large', 'tiny', 'show', 'size', 'inch', 'inches', 'lbs' ];
	return array_values( array_unique( array_filter( $words, fn( $w ) => strlen( $w ) > 1 && ! in_array( $w, $skip, true ) && ! is_numeric( $w ) ) ) );
}

// The search query to send: the key words (no scientific name, sizes or punctuation), with
// hyphenated ones kept whole ("AE-NANO", "ATO-20-P"): some shops' search only finds those as written.
function tfc_si_search_query( $name ) {
	$key = tfc_si_key_words( $name );
	$out = [];
	foreach ( preg_split( '/[^a-z0-9-]+/', strtolower( html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) ), -1, PREG_SPLIT_NO_EMPTY ) as $w ) {
		$w = trim( $w, '-' );
		if ( $w !== '' && array_intersect( explode( '-', $w ), $key ) ) $out[] = $w;
	}
	return implode( ' ', array_unique( $out ) );
}

// From a supplier's search results page, the image of the result whose title contains every key
// word of $name (the closest-titled one if several do). Null when nothing is a confident match.
function tfc_si_match_image( $html, $name, $page_url ) {
	$need = tfc_si_key_words( $name );
	if ( count( $need ) < 2 ) return null; // one word ("Naso") is too vague to be sure it's the same animal
	$u    = parse_url( $page_url );
	$root = ( $u['scheme'] ?? 'https' ) . '://' . ( $u['host'] ?? '' );
	$best = null;
	$extra_best = PHP_INT_MAX;
	preg_match_all( '/<img\b[^>]*>/i', (string) $html, $tags );
	foreach ( $tags[0] as $tag ) {
		$attr  = tfc_si_attrs( $tag );
		$title = $attr['alt'] ?? $attr['title'] ?? '';
		$have  = preg_split( '/[^a-z0-9]+/', strtolower( $title ), -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $have || ! tfc_si_all_words_in( $need, $have ) ) continue; // every key word must be in the title
		$src = tfc_si_largest_src( $attr );
		if ( $src === '' || strpos( $src, 'data:' ) === 0 ) continue;
		$extra = count( $have ) - count( $need );
		if ( $extra < $extra_best ) {
			$extra_best = $extra;
			$best       = strpos( $src, '//' ) === 0 ? 'https:' . $src : ( strpos( $src, '/' ) === 0 ? $root . $src : $src );
		}
	}
	return $best;
}

// A tag's attributes as [ lowercase name => decoded value ]: quoted, unquoted, or bare like "checked" ('').
function tfc_si_attrs( $tag ) {
	preg_match_all( '/\s([a-z][\w:.-]*)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+)))?/i', (string) $tag, $m, PREG_SET_ORDER );
	$attr = [];
	foreach ( $m as $a ) $attr[ strtolower( $a[1] ) ] = html_entity_decode( ( $a[2] ?? '' ) . ( $a[3] ?? '' ) . ( $a[4] ?? '' ), ENT_QUOTES, 'UTF-8' );
	return $attr;
}

// The login form in a page: [ action as written, fields to send, username field, password field ],
// or null. It's the first form with exactly one password box (a sign-up form has two); hidden fields
// such as security tokens go back unchanged. Username field is '' when there is none (a store password page).
function tfc_si_login_form( $html ) {
	preg_match_all( '#<form\b([^>]*)>(.*?)</form>#is', (string) $html, $forms, PREG_SET_ORDER );
	foreach ( $forms as [ , $form_attrs, $inner ] ) {
		preg_match_all( '#<(input|button)\b[^>]*>#i', $inner, $tags, PREG_SET_ORDER );
		$fields = [];
		$pass   = [];
		$user   = $submit = '';
		foreach ( $tags as [ $tag, $el ] ) {
			$a    = tfc_si_attrs( $tag );
			$name = $a['name'] ?? '';
			$type = strtolower( $a['type'] ?? ( strtolower( $el ) === 'button' ? 'submit' : 'text' ) );
			if ( $name === '' || isset( $a['disabled'] ) ) continue;
			if ( $type === 'password' ) $pass[] = $name;
			elseif ( ( $type === 'text' || $type === 'email' ) && $user === '' ) $user = $name;
			elseif ( $type === 'hidden' ) $fields[ $name ] = $a['value'] ?? '';
			elseif ( ( $type === 'checkbox' || $type === 'radio' ) && isset( $a['checked'] ) ) $fields[ $name ] = $a['value'] ?? 'on';
			elseif ( $type === 'submit' && $submit === '' ) $fields[ $submit = $name ] = $a['value'] ?? ''; // some sites check which button was pressed
		}
		if ( count( $pass ) === 1 ) return [ tfc_si_attrs( $form_attrs )['action'] ?? '', $fields, $user, $pass[0] ];
	}
	return null;
}

// Sign-in links in a page, best first: links saying log in / sign in, then account links.
// Log-out, sign-up, password-reset and account-application links are left out.
function tfc_si_login_links( $html ) {
	preg_match_all( '#<a\b([^>]*)>(.*?)</a>#is', (string) $html, $m, PREG_SET_ORDER );
	$best = $ok = [];
	foreach ( $m as [ , $attrs, $text ] ) {
		$href = trim( tfc_si_attrs( $attrs )['href'] ?? '' );
		$says = strtolower( $href . ' ' . strip_tags( $text ) );
		if ( $href === '' || $href[0] === '#' || preg_match( '/log-?\s?out|sign-?\s?out|regist|sign-?\s?up|create|lost|forgot|reset|appl/', $says ) ) continue;
		if ( preg_match( '/log-?\s?in|sign-?\s?in/', $says ) ) $best[] = $href;
		elseif ( strpos( $says, 'account' ) !== false ) $ok[] = $href;
	}
	return array_values( array_unique( array_merge( $best, $ok ) ) );
}

// The site-search form in a page: [ action as written, hidden fields, search box name ], or null.
// A GET form with a search box: type="search", or a text box named like one (q, s, search_query…).
function tfc_si_search_form( $html ) {
	preg_match_all( '#<form\b([^>]*)>(.*?)</form>#is', (string) $html, $forms, PREG_SET_ORDER );
	foreach ( $forms as [ , $form_attrs, $inner ] ) {
		$f = tfc_si_attrs( $form_attrs );
		if ( strtolower( $f['method'] ?? 'get' ) !== 'get' ) continue;
		preg_match_all( '#<input\b[^>]*>#i', $inner, $tags );
		$box    = '';
		$hidden = [];
		foreach ( $tags[0] as $tag ) {
			$a    = tfc_si_attrs( $tag );
			$name = $a['name'] ?? '';
			$type = strtolower( $a['type'] ?? 'text' );
			if ( $name === '' ) continue;
			if ( $type === 'hidden' ) $hidden[ $name ] = $a['value'] ?? '';
			elseif ( $box === '' && ( $type === 'search' || ( $type === 'text' && preg_match( '/^(q|s|search|search_query|query|keywords?|term|searchterm)$/i', $name ) ) ) ) $box = $name;
		}
		if ( $box !== '' ) return [ $f['action'] ?? '', $hidden, $box ];
	}
	return null;
}

// A shop's JSON product search (Shopify /search/suggest.json, the WooCommerce Store API) as
// <img> tags titled with each product's name, so the photo matcher reads it like a results page.
// Null when $body isn't one of those.
function tfc_si_results_html( $body ) {
	$data = json_decode( (string) $body, true );
	if ( ! is_array( $data ) ) return null;
	$items = [];
	if ( isset( $data['resources']['results'] ) ) {
		foreach ( $data['resources']['results']['products'] ?? [] as $p ) $items[] = [ $p['title'] ?? '', $p['image'] ?? $p['featured_image']['url'] ?? '' ];
	} elseif ( $data === array_values( $data ) ) {
		foreach ( $data as $p ) {
			if ( ! isset( $p['name'] ) ) return null;
			$items[] = [ $p['name'], $p['images'][0]['src'] ?? '' ];
		}
	} else {
		return null;
	}
	$html = '';
	foreach ( $items as [ $title, $src ] ) {
		if ( $src ) $html .= sprintf( '<img src="%s" alt="%s">', htmlspecialchars( $src, ENT_QUOTES ), htmlspecialchars( html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ), ENT_QUOTES ) );
	}
	return $html;
}

// Every needed word appears among $have, counting short forms: "clownfish" ~ "clown",
// "angel" ~ "angelfish", "tang" ~ "tangs" (one must start with the other, 4+ letters).
function tfc_si_all_words_in( array $need, array $have ) {
	foreach ( $need as $w ) {
		$ok = false;
		foreach ( $have as $h ) {
			if ( $h === $w || ( min( strlen( $h ), strlen( $w ) ) >= 4 && ( strpos( $w, $h ) === 0 || strpos( $h, $w ) === 0 ) ) ) {
				$ok = true;
				break;
			}
		}
		if ( ! $ok ) return false;
	}
	return true;
}

// Biggest candidate from srcset / data-srcset, else data-src / src; then ask image CDNs for a large copy.
function tfc_si_largest_src( array $attr ) {
	$src = $attr['data-src'] ?? $attr['src'] ?? '';
	$max = 0;
	foreach ( [ 'data-srcset', 'srcset' ] as $k ) {
		foreach ( explode( ',', $attr[ $k ] ?? '' ) as $cand ) {
			if ( preg_match( '/^\s*(\S+)\s+(\d+)w/', $cand, $m ) && (int) $m[2] > $max ) [ $max, $src ] = [ (int) $m[2], $m[1] ];
		}
	}
	$src = preg_replace( '#/stencil/[0-9x]+w?/#', '/stencil/1280x1280/', $src ); // BigCommerce
	return preg_replace( '/([?&])width=\d+/', '$1width=1200', $src );             // Shopify
}

// Guess fish / coral / dry from product type, tags and title. Checked in that order of
// specificity: supplies first so "Coral Food" or "Fish Net" land in dry goods.
// $fallback is returned when nothing matches ('dry', or null to ask "did anything match?").
// ponytail: keyword guess; every row has a category dropdown to correct it.
function tfc_si_classify( $text, $fallback = 'dry' ) {
	$t = strtolower( $text );
	if ( preg_match( '/\b(dry|supplies|equipment|foods?|pellets?|flakes?|salt|pumps?|lights?|lighting|led|filters?|test|kits?|glue|heaters?|skimmers?|media|supplements?|additives?|nets?|reactors?|controllers?|sump|tubing|fittings?|dosing|frozen|plugs?|racks?|tools?|valves?|hoses?|connectors?|adapters?|brackets?|stands?|timers?|probes?|meters?|refractometers?|thermometers?|chillers?|aquariums?|canisters?|lamps?|bulbs?|fixtures?|powerheads?|wavemakers?|dosers?|scrapers?|siphons?|tweezers?|tongs?|magnets?|gloves?|feeders?|bowls?|cabinets?|merch|merchandise|stickers?|calcium|alkalinity|magnesium|buffers?|iodine|strontium|hydrometers?|salinity|conditioners?|dechlorinators?|bacteria|medications?|carbon|phosphate|purigen)\b/', $t ) ) return 'dry';
	if ( preg_match( '/\b(coral\w*|frags?|zoa\w*|acro\w*|sps|lps|mushrooms?|ricordea|euphyllia|torch|hammer|monti\w*|goniopora|chalice|anemones?|clams?|polyps?|leather|toadstool|xenia)\b/', $t ) ) return 'coral';
	if ( preg_match( '/\b(\w*fish|tangs?|clown\w*|gob(y|ies)|wrasses?|angel\w*|damsel\w*|blenn\w*|chromis|basslets?|anthias|puffers?|eels?|cardinal\w*|dottybacks?|shrimp|crabs?|snails?|urchins?|inverts?|invertebrates?|livestock)\b/', $t ) ) return 'fish';
	return $fallback;
}

// Shipping for one order to one state (shipping.php supplies the inputs).
// $rate  = [ live_base, live_lb, dry_base, dry_lb, live => can ship live? ] or null if no rates.
// $lines = [ [ live => bool, lbs => weight of one, qty => n ], ... ]
// Each type in the order pays its base + per-lb charge, so a mixed order pays both.
// Returns null when the order can't ship there.
function tfc_sr_cost( $rate, array $lines ) {
	if ( ! $rate ) return null;
	$lbs = [];
	foreach ( $lines as $l ) {
		$type          = $l['live'] ? 'live' : 'dry';
		$lbs[ $type ] = ( $lbs[ $type ] ?? 0 ) + $l['lbs'] * $l['qty'];
	}
	if ( isset( $lbs['live'] ) && empty( $rate['live'] ) ) return null;
	$cost = 0;
	foreach ( $lbs as $type => $w ) $cost += (float) $rate[ "{$type}_base" ] + (float) $rate[ "{$type}_lb" ] * $w;
	return round( $cost, 2 );
}

// $type is 'percent' or 'flat'. Half cents round up (70.99 + 50% = 106.49), which plain
// round() gets wrong because 106.485 is stored as 106.48499…
function tfc_si_markup( $cost, $type, $amount ) {
	$price = $type === 'flat' ? $cost + $amount : $cost * ( 1 + $amount / 100 );
	return round( round( $price * 100, 4 ) ) / 100;
}

// key => [ label, WooCommerce category path ]. Paths match the theme's live-goods / dry-goods slugs.
const TFC_SI_CATS = [
	'fish'  => [ 'Fish', 'Live Goods > Fish' ],
	'coral' => [ 'Corals', 'Live Goods > Corals' ],
	'dry'   => [ 'Dry Goods', 'Dry Goods' ],
];

// Picked rows ({i, cat, weight} from the form) -> [ group => rows with price & weight ].
// Weight: typed in the row, else from the supplier's sheet, else the category default.
// Sizes of one product take the first size's category, so one product gets one markup.
function tfc_si_prepare( array $rows, array $picked, array $mk ) {
	$groups = [];
	foreach ( $picked as $p ) {
		$r = $rows[ (int) ( $p['i'] ?? -1 ) ] ?? null;
		if ( ! $r ) continue;
		if ( isset( TFC_SI_CATS[ $p['cat'] ?? '' ] ) ) $r['category'] = $p['cat'];
		$r['weight'] = is_numeric( $p['weight'] ?? '' ) ? (float) $p['weight'] : ( $r['weight'] ?? null );
		$groups[ $r['group'] ][] = $r;
	}
	foreach ( $groups as $g => $items ) {
		$m = $mk[ $items[0]['category'] ];
		foreach ( $items as $k => $r ) {
			$groups[ $g ][ $k ]['category'] = $items[0]['category'];
			$groups[ $g ][ $k ]['price']    = tfc_si_markup( $r['cost'], $m['price_type'], $m['price'] );
			$groups[ $g ][ $k ]['weight']   = $r['weight'] ?? ( $m['weight'] ? (float) $m['weight'] : null );
		}
	}
	return $groups;
}

// WooCommerce's own product CSV format (Products > Import). SKUs link sizes to their parent
// and let a re-import update existing products instead of duplicating them.
// $unit / $dim are the store's weight and dimension units, which Woo's importer expects in the headers.
function tfc_si_csv_head( $unit = 'lbs', $dim = 'in' ) {
	return [
		'Type', 'SKU', 'Parent', 'Name', 'Published', 'Description', 'Categories', 'Images', 'In stock?', 'Regular price',
		"Weight ($unit)", "Length ($dim)", "Width ($dim)", "Height ($dim)",
		'Attribute 1 name', 'Attribute 1 value(s)', 'Attribute 1 visible', 'Attribute 1 global',
		'Meta: _tfc_si_group', 'Meta: _tfc_si_id', 'Meta: _tfc_si_cost',
	];
}

function tfc_si_csv_rows( array $groups, $unit = 'lbs', $dim = 'in' ) {
	$head = tfc_si_csv_head( $unit, $dim );
	$line = fn( array $cols ) => array_map( fn( $h ) => $cols[ $h ] ?? '', $head );
	$list = fn( array $vals ) => implode( ', ', str_replace( ',', '\\,', $vals ) ); // Woo's escaped-comma list
	$sku  = fn( $id ) => 'tfc-' . trim( preg_replace( '/[^a-z0-9]+/i', '-', $id ), '-' );
	$out  = [ $head ];
	foreach ( $groups as $group => $items ) {
		$first  = $items[0];
		$parent = [
			'SKU'                 => $sku( $group ),
			'Name'                => $first['name'],
			'Published'           => 1,
			'Description'         => $first['description'],
			'Categories'          => $first['cat_path'] ?? TFC_SI_CATS[ $first['category'] ][1],
			'Images'              => $list( $first['images'] ),
			'Meta: _tfc_si_group' => $group,
		];
		$prices = fn( array $r ) => [
			'In stock?'          => (int) $r['available'],
			'Regular price'      => $r['price'],
			"Weight ($unit)"     => $r['weight'],
			"Length ($dim)"      => $r['length'] ?? null,
			"Width ($dim)"       => $r['width'] ?? null,
			"Height ($dim)"      => $r['height'] ?? null,
			'Meta: _tfc_si_id'   => $r['id'],
			'Meta: _tfc_si_cost' => $r['cost'],
		];
		if ( $first['size'] === '' ) {
			$out[] = $line( $parent + [ 'Type' => 'simple' ] + $prices( $first ) );
			continue;
		}
		$out[] = $line( $parent + [
			'Type'                 => 'variable',
			'Attribute 1 name'     => 'Size',
			'Attribute 1 value(s)' => $list( array_column( $items, 'size' ) ),
			'Attribute 1 visible'  => 1,
			'Attribute 1 global'   => 0,
		] );
		foreach ( $items as $r ) {
			$out[] = $line( [
				'Type'                 => 'variation',
				'SKU'                  => $sku( $r['id'] ),
				'Parent'               => $sku( $group ),
				'Name'                 => $r['name'] . ' - ' . $r['size'],
				'Published'            => 1,
				'Attribute 1 name'     => 'Size',
				'Attribute 1 value(s)' => $list( [ $r['size'] ] ),
				'Attribute 1 global'   => 0,
			] + $prices( $r ) );
		}
	}
	return $out;
}

// ---- Stripe ----------------------------------------------------------------

// Order total in the smallest currency unit, as Stripe wants it ($12.34 -> 1234).
// ponytail: two-decimal currencies only (the store sells in USD); zero-decimal ones like JPY would need a list.
function tfc_stripe_amount( $total ) {
	return (int) round( round( (float) $total, 2 ) * 100 ); // round to cents first: 1049.995 is 1049.99499… as a float
}

// What's wrong with a pasted Stripe key, or '' if it looks right. $kind: pk (publishable), sk (secret,
// or a restricted rk_ key), whsec (webhook signing secret); $mode: test or live.
function tfc_stripe_key_problem( $kind, $key, $mode ) {
	if ( $key === '' ) return '';
	if ( $kind === 'whsec' ) return strpos( $key, 'whsec_' ) === 0 ? '' : 'A webhook signing secret starts with whsec_.';
	$ok = $kind === 'pk' ? [ "pk_{$mode}_" ] : [ "sk_{$mode}_", "rk_{$mode}_" ];
	foreach ( $ok as $prefix ) if ( strpos( $key, $prefix ) === 0 ) return '';
	return sprintf( 'That %s key should start with %s. Check it’s the %s key, not the %s one.', $kind === 'pk' ? 'publishable' : 'secret', implode( ' or ', $ok ), $mode, $mode === 'test' ? 'live' : 'test' );
}

// Stripe webhook signature check. The Stripe-Signature header is "t=<unix time>,v1=<hmac>,…"; the
// HMAC-SHA256 of "<time>.<raw body>" with the endpoint's signing secret must equal one v1, and the
// time must be within 5 minutes of $now (stops replays of old events).
function tfc_stripe_signature_ok( $payload, $header, $secret, $now, $tolerance = 300 ) {
	$t    = 0;
	$sigs = [];
	foreach ( explode( ',', (string) $header ) as $part ) {
		[ $k, $v ] = array_pad( explode( '=', trim( $part ), 2 ), 2, '' );
		if ( $k === 't' ) $t = (int) $v;
		elseif ( $k === 'v1' ) $sigs[] = $v;
	}
	if ( ! $t || ! $sigs || $secret === '' || abs( $now - $t ) > $tolerance ) return false;
	$expected = hash_hmac( 'sha256', $t . '.' . $payload, $secret );
	foreach ( $sigs as $s ) if ( hash_equals( $expected, $s ) ) return true;
	return false;
}

// A saved secret as it may be shown again: its prefix (sk_test_, whsec_…) and last 4 only.
function tfc_mask_secret( $key ) {
	if ( $key === '' ) return 'Not set';
	preg_match( '/^((?:[a-z]+_)+)/', $key, $m );
	return 'Saved: ' . ( $m[1] ?? '' ) . '…' . substr( $key, -4 );
}

// ---- Carrier rates (FedEx, UPS) ----------------------------------------------

// Split a shipment's weight into boxes of at most $max_lb each, as evenly as possible (lb, 1 decimal, rounded up).
function tfc_ship_boxes( $lbs, $max_lb ) {
	$n = max( 1, (int) ceil( $lbs / max( 1, $max_lb ) ) );
	return array_fill( 0, $n, max( 0.1, ceil( $lbs / $n * 10 ) / 10 ) );
}

// FedEx Rates and Transit Times API body (POST /rate/v1/rates/quotes). $from/$to: [ postcode, state ];
// $box: [ length, width, height ] in inches.
function tfc_fedex_rate_request( $account, array $from, array $to, array $boxes, array $box, $service = 'PRIORITY_OVERNIGHT' ) {
	$address = fn( $a, $residential ) => [ 'postalCode' => (string) $a[0], 'stateOrProvinceCode' => (string) $a[1], 'countryCode' => 'US', 'residential' => $residential ];
	return [
		'accountNumber'     => [ 'value' => (string) $account ],
		'requestedShipment' => [
			'shipper'                   => [ 'address' => $address( $from, false ) ],
			'recipient'                 => [ 'address' => $address( $to, true ) ],
			'pickupType'                => 'DROPOFF_AT_FEDEX_LOCATION',
			'serviceType'               => $service,
			'rateRequestType'           => [ 'ACCOUNT' ],
			'requestedPackageLineItems' => array_map( fn( $lb ) => [
				'weight'     => [ 'units' => 'LB', 'value' => $lb ],
				'dimensions' => [ 'length' => (int) $box[0], 'width' => (int) $box[1], 'height' => (int) $box[2], 'units' => 'IN' ],
			], $boxes ),
		],
	];
}

// The price in a FedEx rate reply: the account rate if there is one, otherwise the first quoted. Null if none.
function tfc_fedex_rate_from( array $reply ) {
	$first = null;
	foreach ( $reply['output']['rateReplyDetails'] ?? [] as $detail ) {
		foreach ( $detail['ratedShipmentDetails'] ?? [] as $rated ) {
			if ( ! isset( $rated['totalNetCharge'] ) ) continue;
			if ( ( $rated['rateType'] ?? '' ) === 'ACCOUNT' ) return (float) $rated['totalNetCharge'];
			$first = $first ?? (float) $rated['totalNetCharge'];
		}
	}
	return $first;
}

// UPS Rating API body (POST /api/rating/v2409/Rate). Service 03 = UPS Ground; asks for the account's negotiated rates.
function tfc_ups_rate_request( $account, array $from, array $to, array $boxes, array $box, $service = '03' ) {
	$address = fn( $a ) => [ 'StateProvinceCode' => (string) $a[1], 'PostalCode' => (string) $a[0], 'CountryCode' => 'US' ];
	return [ 'RateRequest' => [
		'Request'  => [ 'TransactionReference' => [ 'CustomerContext' => 'checkout' ] ],
		'Shipment' => [
			'Shipper'               => [ 'ShipperNumber' => (string) $account, 'Address' => $address( $from ) ],
			'ShipFrom'              => [ 'Address' => $address( $from ) ],
			'ShipTo'                => [ 'Address' => $address( $to ) + [ 'ResidentialAddressIndicator' => 'Y' ] ],
			'PaymentDetails'        => [ 'ShipmentCharge' => [ [ 'Type' => '01', 'BillShipper' => [ 'AccountNumber' => (string) $account ] ] ] ],
			'Service'               => [ 'Code' => $service ],
			'ShipmentRatingOptions' => [ 'NegotiatedRatesIndicator' => 'Y' ],
			'NumOfPieces'           => (string) count( $boxes ),
			'Package'               => array_map( fn( $lb ) => [
				'PackagingType' => [ 'Code' => '02' ],
				'Dimensions'    => [ 'UnitOfMeasurement' => [ 'Code' => 'IN' ], 'Length' => (string) (int) $box[0], 'Width' => (string) (int) $box[1], 'Height' => (string) (int) $box[2] ],
				'PackageWeight' => [ 'UnitOfMeasurement' => [ 'Code' => 'LBS' ], 'Weight' => (string) $lb ],
			], $boxes ),
		],
	] ];
}

// The price in a UPS rate reply: negotiated if present, otherwise the published total. RatedShipment is
// a list in the spec but a single object in many replies; both are read. Null if none.
function tfc_ups_rate_from( array $reply ) {
	$rated = $reply['RateResponse']['RatedShipment'] ?? null;
	if ( ! is_array( $rated ) ) return null;
	$rated = isset( $rated[0] ) ? $rated[0] : $rated;
	$value = $rated['NegotiatedRateCharges']['TotalCharge']['MonetaryValue'] ?? $rated['TotalCharges']['MonetaryValue'] ?? null;
	return is_numeric( $value ) ? (float) $value : null;
}

// ---- Duplicates and supplier codes -------------------------------------------------

// What identifies a product's name, to spot the same product listed twice: lowercase, without a
// trailing " - Scientific name", punctuation and filler words, words sorted. Sizes stay in ("Angel Sm"
// and "Angel Lg" are different products).
function tfc_si_dupe_key( $name ) {
	$name  = preg_replace( '/\s+[-–—]\s+.*$/u', '', html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) );
	$words = preg_split( '/[^a-z0-9]+/', strtolower( $name ), -1, PREG_SPLIT_NO_EMPTY );
	$words = array_values( array_unique( array_diff( $words, [ 'the', 'and', 'with', 'for', 'of', 'a' ] ) ) );
	sort( $words );
	return implode( ' ', $words );
}

// A key split into its size-like words (anything with a digit, or sm/md/lg/small…) and the rest.
function tfc_si_dupe_split( $key ) {
	$size = $rest = [];
	foreach ( explode( ' ', $key ) as $w ) {
		if ( preg_match( '/\d/', $w ) || in_array( $w, [ 'xs', 'sm', 'md', 'med', 'lg', 'xl', 'xxl', 'small', 'medium', 'large', 'tiny', 'mini', 'nano', 'jumbo', 'pair', 'pack', 'combo' ], true ) ) $size[] = $w;
		else $rest[] = $w;
	}
	return [ implode( ' ', $size ), implode( ' ', $rest ) ];
}

// Same product? Equal keys, or (for names of 8+ letters) the same size words and a 90%+ similar rest,
// which catches a typo or a stray word: "Green Star Polyp" ~ "Green Star Polyps".
function tfc_si_near_same( $a, $b ) {
	if ( $a === $b ) return $a !== '';
	return tfc_si_near_same_parts( tfc_si_dupe_split( $a ), tfc_si_dupe_split( $b ) );
}

// The same test on keys already split by tfc_si_dupe_split(). Cheap checks first, since it runs a lot: same size words, the
// same first 3 letters, lengths within 3, and only then the similarity.
function tfc_si_near_same_parts( array $x, array $y ) {
	[ $sa, $ra ] = $x;
	[ $sb, $rb ] = $y;
	if ( $sa !== $sb || min( strlen( $ra ), strlen( $rb ) ) < 8 || abs( strlen( $ra ) - strlen( $rb ) ) > 3 || substr( $ra, 0, 3 ) !== substr( $rb, 0, 3 ) ) return false;
	similar_text( $ra, $rb, $pct );
	return $pct >= 90;
}

// One product per name. $groups is tfc_si_prepare()'s [ group => rows ]. Of the groups that are the same
// product, the one in stock wins, then the lowest cost, then the first listed. Returns [ kept groups (original
// order), dropped ] where dropped rows are [ name, source, cost, kept name, kept source, kept cost ].
function tfc_si_dedupe( array $groups ) {
	$info = [];
	foreach ( $groups as $g => $items ) {
		$key = tfc_si_dupe_key( $items[0]['name'] );
		$info[ $g ] = [
			'key'   => $key,
			'parts' => tfc_si_dupe_split( $key ),
			'cost'  => min( array_column( $items, 'cost' ) ),
			'stock' => (bool) array_filter( array_column( $items, 'available' ) ),
		];
	}
	$better = fn( $a, $b ) => $a['stock'] !== $b['stock'] ? $a['stock'] : $a['cost'] < $b['cost']; // is $a better than $b?
	$winner = [];   // cluster => group
	$bucket = [];   // size words => [ cluster ids ], so only likely matches are compared
	$of     = [];   // group => cluster
	foreach ( $info as $g => $i ) {
		$parts = tfc_si_dupe_split( $i['key'] );
		$sig   = $parts[0] . '|' . substr( $parts[1], 0, 3 ); // only groups sharing size words and first letters can be near-equal
		foreach ( $bucket[ $sig ] ?? [] as $c ) {
			if ( $i['key'] === $info[ $winner[ $c ] ]['key'] || tfc_si_near_same_parts( $parts, $info[ $winner[ $c ] ]['parts'] ) ) {
				$of[ $g ] = $c;
				if ( $better( $i, $info[ $winner[ $c ] ] ) ) $winner[ $c ] = $g;
				continue 2;
			}
		}
		$c              = count( $winner );
		$winner[ $c ]   = $g;
		$of[ $g ]       = $c;
		$bucket[ $sig ][] = $c;
	}
	$kept = $dropped = [];
	foreach ( $groups as $g => $items ) {
		if ( $winner[ $of[ $g ] ] === $g ) {
			$kept[ $g ] = $items;
			continue;
		}
		$w         = $winner[ $of[ $g ] ];
		$dropped[] = [ $items[0]['name'], $items[0]['source'] ?? '', $info[ $g ]['cost'], $groups[ $w ][0]['name'], $groups[ $w ][0]['source'] ?? '', $info[ $w ]['cost'] ];
	}
	return [ $kept, $dropped ];
}

// The same check against products already in the store. $existing: [ [ id, group, key, cost ] ] for products
// imported earlier. A new group that matches one from a different supplier listing is dropped if the store's is
// cheaper or equal; if the new one is cheaper it stays and the store's product id is returned to be retired.
// Returns [ kept groups, dropped rows (as above, "kept" being the store's product), ids to retire ].
function tfc_si_dedupe_against( array $groups, array $existing ) {
	$index = []; // size words + first 3 letters => the store's products that could match
	foreach ( $existing as $e ) {
		$e['parts'] = tfc_si_dupe_split( $e['key'] );
		$index[ $e['parts'][0] . '|' . substr( $e['parts'][1], 0, 3 ) ][] = $e;
	}
	$dropped = $retire = [];
	foreach ( $groups as $g => $items ) {
		$key   = tfc_si_dupe_key( $items[0]['name'] );
		$parts = tfc_si_dupe_split( $key );
		$cost  = min( array_column( $items, 'cost' ) );
		foreach ( $index[ $parts[0] . '|' . substr( $parts[1], 0, 3 ) ] ?? [] as $e ) {
			if ( (string) $e['group'] === (string) $g || ! ( $key === $e['key'] || tfc_si_near_same_parts( $parts, $e['parts'] ) ) ) continue;
			if ( $e['cost'] <= $cost ) {
				$dropped[] = [ $items[0]['name'], $items[0]['source'] ?? '', $cost, $e['name'], $e['source'], $e['cost'] ];
				unset( $groups[ $g ] );
				continue 2;
			}
			$retire[] = $e['id'];
		}
	}
	return [ $groups, $dropped, array_values( array_unique( $retire ) ) ];
}

// A short supplier code from a supplier's name or website: the initials of its words ("Seaside Aquatics" →
// SA, "aquasd.com" → ASD via its camel/case words), or the first 3 letters of a single word. The owner can
// change any code on the Suppliers page.
function tfc_si_default_code( $source ) {
	$s = preg_replace( '#[/?].*$#', '', preg_replace( '#^(https?://)?(www\.)?#i', '', trim( (string) $source ) ) ); // drop scheme, www and any path
	$s = preg_replace( '/\.(com|net|org|csv|xlsx|tsv|txt)$/i', '', $s );
	$s = preg_replace( '/([a-z])([A-Z])/', '$1 $2', $s );          // AquaSD -> Aqua SD
	$s = preg_replace( '/([A-Z]{2,})([A-Z][a-z])/', '$1 $2', $s );  // AMAquitas -> AM Aquitas
	$words = preg_split( '/[^A-Za-z0-9]+/', $s, -1, PREG_SPLIT_NO_EMPTY );
	if ( ! $words ) return '';
	if ( count( $words ) === 1 ) return strtoupper( substr( $words[0], 0, 3 ) );
	return strtoupper( substr( implode( '', array_map( fn( $w ) => ctype_upper( $w ) ? $w : $w[0], $words ), ), 0, 6 ) );
}

// ---- Sites with no product feed: read the product cards on their pages ---------------------

// A link as an absolute address, given the page it was on (no WordPress needed).
function tfc_si_abs( $href, $page_url ) {
	$href = html_entity_decode( trim( (string) $href ), ENT_QUOTES, 'UTF-8' );
	if ( $href === '' ) return '';
	if ( preg_match( '#^https?://#i', $href ) ) return $href;
	$u      = parse_url( $page_url );
	$scheme = $u['scheme'] ?? 'https';
	$host   = ( $u['host'] ?? '' ) . ( isset( $u['port'] ) ? ':' . $u['port'] : '' );
	if ( strpos( $href, '//' ) === 0 ) return "$scheme:$href";
	if ( $href[0] === '/' ) return "$scheme://$host$href";
	if ( $href[0] === '?' ) return "$scheme://$host" . ( $u['path'] ?? '/' ) . $href;
	$dir = preg_replace( '#[^/]*$#', '', $u['path'] ?? '/' );
	return "$scheme://$host$dir$href";
}

// Products from the cards on a listing page, in the markup PrestaShop shops use (article.product-miniature:
// name and link in .product-title, price in a .price element, photo, reference). A card with no price (a
// wholesale shop while logged out) has cost 0. Rows are shaped like every other parser's.
function tfc_si_from_cards( $html, $page_url ) {
	$rows = [];
	preg_match_all( '#<article\b[^>]*product-miniature[^>]*>(.*?)</article>#is', (string) $html, $cards, PREG_SET_ORDER );
	foreach ( $cards as [ $card, $inner ] ) {
		if ( ! preg_match( '/data-id-product\s*=\s*["\']?(\d+)/i', $card, $id ) ) continue;
		if ( ! preg_match( '#<h\d[^>]*product-title[^>]*>\s*<a\b([^>]*)>(.*?)</a>#is', $inner, $t ) ) continue;
		$name = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( strip_tags( $t[2] ), ENT_QUOTES, 'UTF-8' ) ) );
		if ( $name === '' ) continue;
		$img = [];
		if ( preg_match( '/<img\b[^>]*>/i', $inner, $im ) ) {
			$a   = tfc_si_attrs( $im[0] );
			$src = $a['data-full-size-image-url'] ?? $a['data-src'] ?? $a['src'] ?? '';
			if ( $src !== '' && strpos( $src, 'data:' ) !== 0 ) $img[] = tfc_si_abs( $src, $page_url );
		}
		$price = null;
		if ( preg_match( '/itemprop\s*=\s*["\']price["\'][^>]*content\s*=\s*["\']([\d.,]+)/i', $inner, $p ) || preg_match( '/content\s*=\s*["\']([\d.,]+)["\'][^>]*itemprop\s*=\s*["\']price/i', $inner, $p )
			// else an element whose class is exactly "price" (not "regular-price", the crossed-out one), else any $ amount in the card
			|| preg_match( '/class\s*=\s*["\'](?:[^"\']*\s)?price(?:\s[^"\']*)?["\'][^>]*>\s*([^<]*\d[^<]*)</i', $inner, $p )
			|| preg_match( '/\$\s*(\d[\d,]*(?:\.\d{1,2})?)/', strip_tags( $inner ), $p ) ) $price = tfc_si_number( $p[1] );
		$rows[] = tfc_si_row( [
			'id'          => 'card:' . $id[1],
			'group'       => 'card:' . $id[1],
			'name'        => $name,
			'cost'        => $price ?? 0,
			'available'   => ! preg_match( '/out[-_ ]of[-_ ]stock|product-unavailable|sold[-_ ]out/i', $card ),
			'category'    => tfc_si_classify( $name ),
			'images'      => $img,
			'url'         => tfc_si_abs( tfc_si_attrs( '<a ' . $t[1] . '>' )['href'] ?? '', $page_url ),
			'description' => '',
		] );
	}
	return array_merge( $rows, tfc_si_from_bigcommerce_cards( $html, $page_url ) );
}

// The same, for BigCommerce shops (article.card carrying data-entity-id, data-name, data-product-category and
// data-product-price; photo in the card image, stock number when the shop shows one). Cost is 0 when no price is shown.
function tfc_si_from_bigcommerce_cards( $html, $page_url ) {
	$rows = [];
	preg_match_all( '#(<article\b[^>]*\bdata-entity-id\s*=[^>]*>)(.*?)</article>#is', (string) $html, $cards, PREG_SET_ORDER );
	foreach ( $cards as [ , $open, $inner ] ) {
		$a    = tfc_si_attrs( $open );
		$id   = trim( $a['data-entity-id'] ?? '' );
		$name = trim( preg_replace( '/\s+/u', ' ', $a['data-name'] ?? '' ) );
		if ( $name === '' && preg_match( '#<h\d[^>]*card-title[^>]*>\s*<a\b[^>]*>(.*?)</a>#is', $inner, $t ) ) $name = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( strip_tags( $t[1] ), ENT_QUOTES, 'UTF-8' ) ) );
		if ( ! ctype_digit( $id ) || $name === '' ) continue;
		$link = '';
		if ( preg_match( '#<a\b[^>]*(?:card-figure__link|data-event-type="product-click")[^>]*>#i', $inner, $l ) || preg_match( '#<h\d[^>]*card-title[^>]*>\s*(<a\b[^>]*>)#is', $inner, $l ) ) $link = tfc_si_attrs( ( $l[1] ?? $l[0] ) )['href'] ?? '';
		$link = preg_replace( '/[?&](searchid|search_query)=[^&]*/', '', tfc_si_abs( $link, $page_url ) );
		$img = [];
		if ( preg_match( '/<img\b[^>]*>/i', $inner, $im ) ) {
			$src = tfc_si_largest_src( tfc_si_attrs( $im[0] ) );
			if ( $src !== '' && strpos( $src, 'data:' ) !== 0 ) $img[] = tfc_si_abs( $src, $page_url );
		}
		$price = isset( $a['data-product-price'] ) ? tfc_si_number( $a['data-product-price'] ) : null;
		if ( ! $price && preg_match( '/data-product-price-without-tax[^>]*>\s*([^<]*\d[^<]*)</i', $inner, $p ) ) $price = tfc_si_number( $p[1] );
		$cats = trim( preg_replace( '/\s+/', ' ', str_replace( '/', ', ', $a['data-product-category'] ?? '' ) ) );
		$rows[] = tfc_si_row( [
			'id'          => 'card:' . $id,
			'group'       => 'card:' . $id,
			'name'        => $name,
			'cost'        => $price ?? 0,
			'available'   => ! preg_match( '/out[-_ ]of[-_ ]stock|sold[-_ ]out|stock-number[^>]*>\s*0\s*</i', $inner ),
			'category'    => tfc_si_classify( $cats . ' ' . $name ),
			'cat_text'    => $cats,
			'images'      => $img,
			'url'         => $link,
			'description' => '',
		] );
	}
	return $rows;
}

// Links on a page that stay on the same site: [ [ address, link text ] ], each address once, no #anchors.
function tfc_si_page_links( $html, $page_url ) {
	$host = strtolower( preg_replace( '/^www\./', '', (string) parse_url( $page_url, PHP_URL_HOST ) ) );
	$out  = [];
	preg_match_all( '#<a\b([^>]*)>(.*?)</a>#is', (string) $html, $m, PREG_SET_ORDER );
	foreach ( $m as [ , $attrs, $text ] ) {
		$href = tfc_si_attrs( "<a $attrs>" )['href'] ?? '';
		if ( $href === '' || preg_match( '/^(#|javascript:|mailto:|tel:)/i', $href ) ) continue;
		$url = preg_replace( '/#.*$/', '', tfc_si_abs( $href, $page_url ) );
		if ( strtolower( preg_replace( '/^www\./', '', (string) parse_url( $url, PHP_URL_HOST ) ) ) !== $host || preg_match( '/\.(jpe?g|png|gif|webp|svg|pdf|zip|css|js)(\?|$)/i', $url ) ) continue;
		$out[ $url ] = [ $url, trim( preg_replace( '/\s+/u', ' ', html_entity_decode( strip_tags( $text ), ENT_QUOTES, 'UTF-8' ) ) ) ];
	}
	return array_values( $out );
}

// Where on a site the products probably are, best first (at most 8): links called Shop, Products, Catalog, All,
// Categories, or shaped like a category ("/12-protein-skimmers", "/product-category/…"). Login, cart, blog and
// info pages are skipped.
function tfc_si_start_candidates( array $links, $page_url ) {
	$scored = [];
	foreach ( $links as $i => [ $url, $text ] ) {
		$path = strtolower( (string) parse_url( $url, PHP_URL_PATH ) );
		if ( $url === $page_url || trim( $path, '/' ) === '' || preg_match( '#log-?in|sign-?in|account|cart|checkout|contact|about|blog|news|cms|content/|privacy|terms|policy|wishlist|password|register|sitemap|faq|help|shipping-#', $path . ' ' . strtolower( $text ) ) ) continue;
		$score = 0;
		if ( preg_match( '/\b(all|shop|products?|catalog(ue)?|store|categories|browse|home)\b/i', $text ) ) $score += 3;
		if ( preg_match( '#/(shop|products?|catalog|collections/all|store|categor(y|ies)|product-category)(/|$)#', $path ) ) $score += 3;
		if ( preg_match( '#^/\d+-[a-z0-9-]+/?$#', $path ) ) $score += 2; // PrestaShop category
		if ( $score ) $scored[] = [ $score, $i, $url ];
	}
	usort( $scored, fn( $a, $b ) => $b[0] <=> $a[0] ?: $a[1] <=> $b[1] );
	return array_slice( array_column( $scored, 2 ), 0, 8 );
}

// The next page of a listing: a link marked rel="next", else one to the same page with ?page=N+1. Null if none.
function tfc_si_next_page( $html, $page_url ) {
	parse_str( (string) parse_url( $page_url, PHP_URL_QUERY ), $q );
	$want = ( (int) ( $q['page'] ?? 1 ) ) + 1;
	$path = (string) parse_url( $page_url, PHP_URL_PATH );
	$page_re = '/[?&]page=' . $want . '(&|$)/';
	$fallback = null;
	preg_match_all( '/<(?:a|link)\b[^>]*>/i', (string) $html, $tags );
	foreach ( $tags[0] as $tag ) {
		$a = tfc_si_attrs( $tag );
		$href = $a['href'] ?? '';
		if ( $href === '' ) continue;
		$abs = tfc_si_abs( $href, $page_url );
		if ( preg_match( '/\bnext\b/i', $a['rel'] ?? '' ) ) return $abs;
		if ( $fallback === null && (string) parse_url( $abs, PHP_URL_PATH ) === $path && preg_match( $page_re, (string) parse_url( $abs, PHP_URL_QUERY ) ? '?' . parse_url( $abs, PHP_URL_QUERY ) : '' ) ) $fallback = $abs;
	}
	return $fallback;
}

// ---- Product descriptions from a product's own page ----------------------------------------

// The inside of the div with this id (balanced against nested divs), or ''.
function tfc_si_div_inner( $html, $id ) {
	if ( ! preg_match( '/<div\b[^>]*\sid\s*=\s*["\']' . preg_quote( $id, '/' ) . '["\'][^>]*>/i', (string) $html, $m, PREG_OFFSET_CAPTURE ) ) return '';
	$start = $m[0][1] + strlen( $m[0][0] );
	preg_match_all( '#<div\b|</div>#i', $html, $t, PREG_OFFSET_CAPTURE, $start );
	$depth = 1;
	foreach ( $t[0] as [ $tag, $off ] ) {
		$depth += strtolower( $tag ) === '</div>' ? -1 : 1;
		if ( $depth === 0 ) return substr( $html, $start, $off - $start );
	}
	return substr( $html, $start );
}

// A supplier's description markup made plain: no scripts, styles, forms, images or tab labels, every attribute
// dropped except a link's address, layout wrappers (div/span/font) removed. Paragraphs, headings, lists and
// bold/italic stay, without the supplier's fonts and colours.
function tfc_si_clean_description( $html, $page_url = '' ) {
	$html = preg_replace( '#<(script|style|iframe|form|button|noscript|svg|select|textarea)\b.*?</\1>#is', '', (string) $html );
	$html = preg_replace( '/<!--.*?-->/s', '', $html );
	$html = preg_replace( '#<div\b[^>]*index_title[^>]*>.*?</div>#is', '', $html );   // the "Description" tab label
	$html = preg_replace( '#<img\b[^>]*>#i', '', $html );
	$html = preg_replace_callback( '#<(/?)([a-z][a-z0-9]*)\b([^>]*)>#i', function ( $m ) use ( $page_url ) {
		$tag = strtolower( $m[2] );
		if ( in_array( $tag, [ 'div', 'section', 'article' ], true ) ) return "\n";
		if ( in_array( $tag, [ 'span', 'font' ], true ) ) return '';
		if ( $m[1] ) return "</$tag>";
		$href = $tag === 'a' ? tfc_si_abs( tfc_si_attrs( $m[0] )['href'] ?? '', $page_url ) : '';
		return "<$tag" . ( $href !== '' ? ' href="' . htmlspecialchars( $href, ENT_QUOTES ) . '"' : '' ) . '>';
	}, $html );
	$html = preg_replace( '#<(p|h[1-6]|li|strong|em|b|i|a)(?: [^>]*)?>(?:\s|&nbsp;|<br\s*/?>)*</\1>#i', '', $html );   // empty tags
	$html = preg_replace( '/[ \t]*\R[ \t]*/', "\n", trim( $html ) );
	$html = preg_replace( '#^\s*<h[1-6]>\s*Description\s*</h[1-6]>#i', '', $html );   // WooCommerce's tab heading
	return trim( preg_replace( "/\n{3,}/", "\n\n", $html ) );
}

// The description on a product page: the page's Description tab, else the schema.org Product description if it says
// more than the product's name. (og:description is not used: shops fill it with a store-wide blurb when a product has
// no text.) '' when there is nothing worth having.
function tfc_si_page_description( $html, $page_url = '', $name = '' ) {
	$text   = fn( $d ) => trim( preg_replace( '/\s+/', ' ', html_entity_decode( strip_tags( $d ), ENT_QUOTES, 'UTF-8' ) ) );
	$enough = fn( $d ) => strlen( $text( $d ) ) >= 40;
	// The page's own Description tab counts even when short ("Ceramic Coral Frag Plug"), unless it just repeats the product name.
	$own = fn( $d ) => strlen( $text( $d ) ) >= 5 && ! in_array( strtolower( $text( $d ) ), [ 'description', 'product description', 'details', 'no description', 'n/a' ], true ) && ( $name === '' || tfc_si_dupe_key( $text( $d ) ) !== tfc_si_dupe_key( $name ) );
	foreach ( [ 'description', 'tab-description', 'product-description', 'product_description' ] as $id ) {
		$d = tfc_si_clean_description( tfc_si_div_inner( $html, $id ), $page_url );
		if ( $own( $d ) ) return $d;
	}
	preg_match_all( '#<script[^>]*application/ld\+json[^>]*>(.*?)</script>#is', (string) $html, $m );
	foreach ( $m[1] as $json ) {
		$data = json_decode( $json, true );
		foreach ( isset( $data['@graph'] ) ? $data['@graph'] : [ $data ] as $node ) {
			if ( is_array( $node ) && ( $node['@type'] ?? '' ) === 'Product' && $enough( $node['description'] ?? '' ) ) return '<p>' . tfc_si_esc( $node['description'] ) . '</p>';
		}
	}
	return '';
}

// htmlspecialchars without needing WordPress (parse.php runs under plain php in the tests).
function tfc_si_esc( $s ) {
	return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' );
}

// Descriptions are read from a product's own page only for listings that have a page and no feed: a Shopify or
// WooCommerce feed already carries the description, so an empty one there is really empty.
function tfc_si_reads_pages( array $row ) {
	return $row['url'] !== '' && ! preg_match( '/^(shopify|woo):/', $row['id'] );
}

// ---- Looking at a site before scraping it: which optional data is there -------------------------

// From a sample of rows, which optional data types turned up. $description_on_page: true when the
// listing itself carries no description but a sample product's own page does (checked separately -
// only worth trying for sources that read pages at all; see tfc_si_reads_pages()).
function tfc_si_fields_found( array $rows, $description_on_page = false ) {
	return [
		'images'            => (bool) array_filter( $rows, fn( $r ) => $r['images'] ),
		'description'       => $description_on_page || (bool) array_filter( $rows, fn( $r ) => trim( (string) $r['description'] ) !== '' ),
		'description_page'  => $description_on_page,
	];
}

// Blanks out data types the owner unticked in the "Look at this site" checklist, after fetching.
// Structural fields (name, price, category, stock, url…) are never touched - unticking a field just
// means "don't bother saving this", not "pretend the product doesn't exist".
function tfc_si_strip_fields( array $rows, array $skip ) {
	foreach ( $rows as $i => $r ) {
		if ( in_array( 'images', $skip, true ) ) $rows[ $i ]['images'] = [];
		if ( in_array( 'description', $skip, true ) ) $rows[ $i ]['description'] = '';
	}
	return $rows;
}

// ---- Scanning a whole site in batches ---------------------------------------------------------

// Could this link be a page listing products? Not login, cart, contact, blog or other info pages.
function tfc_si_listing_link_ok( $url, $text, $page_url ) {
	$path = strtolower( (string) parse_url( $url, PHP_URL_PATH ) );
	return $url !== $page_url && trim( $path, '/' ) !== '' && ! preg_match( '#log-?in|sign-?in|account|cart|checkout|contact|about|blog|news|cms|content/|privacy|terms|policy|wishlist|password|register|sitemap|faq|help|shipping-#', $path . ' ' . strtolower( $text ) );
}

// Every page worth checking for products, in the order to check them: the likely catalog pages first, then the rest of the
// site's category-looking links as they appear. Left out: addresses already known to be single products ($skip), variants
// with a query string, and anything deeper than 3 folders. At most $max.
function tfc_si_scan_candidates( array $links, $page_url, array $skip = [], $max = 150 ) {
	$skip = array_flip( $skip );
	$ok   = array_column( array_filter( $links, fn( $l ) => tfc_si_listing_link_ok( $l[0], $l[1], $page_url ) ), 0 );
	$out  = [];
	foreach ( array_merge( tfc_si_start_candidates( $links, $page_url, 8 ), $ok ) as $url ) {
		if ( isset( $skip[ $url ] ) || isset( $out[ $url ] ) || strpos( $url, '?' ) !== false || substr_count( trim( (string) parse_url( $url, PHP_URL_PATH ), '/' ), '/' ) > 2 ) continue;
		$out[ $url ] = true;
		if ( count( $out ) >= $max ) break;
	}
	return array_keys( $out );
}

// Up to $n entries spread evenly through a list (first, last and between), to sample it.
function tfc_si_spread( array $list, $n ) {
	$list = array_values( $list );
	if ( count( $list ) <= $n ) return $list;
	$out = [];
	for ( $i = 0; $i < $n; $i++ ) $out[] = $list[ (int) round( $i * ( count( $list ) - 1 ) / ( $n - 1 ) ) ];
	return $out;
}
