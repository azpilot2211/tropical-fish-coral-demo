<?php
// Importing in batches. A big import (thousands of products, each downloading photos and reading a page)
// can't finish inside one web request: hosts cut those off after 30-60 seconds with a "504 gateway timeout".
// So the Import button starts a job, and the page then asks for one small batch at a time (each under ~10 s),
// with a progress bar. Each product is saved on its own, so a batch that's cut off or repeated loses nothing,
// and a job left half done can be continued from the page later.
defined( 'ABSPATH' ) || exit;

const TFC_SI_STEP_SECONDS = 10; // work per batch; the gateway limit is usually 30-60 s

function tfc_si_job_key() {
	return 'tfc_si_job_' . get_current_user_id();
}

// [ i (done so far), total ] of this user's unfinished import, or null.
function tfc_si_job_state() {
	$state = get_option( tfc_si_job_key() . '_state' );
	$total = (int) get_option( tfc_si_job_key() . '_total' );
	return is_array( $state ) && $total ? [ (int) $state['i'], $total ] : null;
}

function tfc_si_job_clear() {
	foreach ( [ '', '_state', '_total', '_meta' ] as $suffix ) delete_option( tfc_si_job_key() . $suffix );
}

function tfc_si_ajax_guard() {
	check_ajax_referer( 'tfc_si' );
	if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'You don’t have permission to import products.', 403 );
	ignore_user_abort( true ); // a dropped connection shouldn't leave a product half saved
}

// Start: prepare everything (markups, duplicates) and park the list; the batches follow.
add_action( 'wp_ajax_tfc_si_start', function () {
	tfc_si_ajax_guard();
	$mk = tfc_si_markups( wp_unslash( $_POST['mk'] ?? [] ) );
	update_option( 'tfc_si_markups', $mk, false );
	$picked = json_decode( wp_unslash( $_POST['picked'] ?? '' ), true );
	$prep   = tfc_si_import_groups( get_transient( 'tfc_si_rows_' . get_current_user_id() ) ?: [], is_array( $picked ) ? $picked : [], $mk, true );
	if ( ! $prep ) wp_send_json_error( 'Nothing selected, or the list expired. Fetch the URL or upload the file again.' );
	[ $groups, $dupes, $retire ] = $prep;
	tfc_si_job_clear();
	update_option( tfc_si_job_key(), $groups, false );           // large: written once
	update_option( tfc_si_job_key() . '_total', count( $groups ), false );
	update_option( tfc_si_job_key() . '_meta', [ 'refile' => ! empty( $_POST['refile'] ), 'retire' => $retire, 'dupes' => $dupes ], false );
	update_option( tfc_si_job_key() . '_state', [ 'i' => 0, 'fails' => [] ], false ); // small: rewritten every batch
	wp_send_json_success( [ 'i' => 0, 'total' => count( $groups ), 'skipped' => count( $dupes ) ] );
} );

// One batch: save products until about TFC_SI_STEP_SECONDS have passed. Repeating a batch is harmless (saves are updates).
add_action( 'wp_ajax_tfc_si_step', function () {
	tfc_si_ajax_guard();
	$state = get_option( tfc_si_job_key() . '_state' );
	$total = (int) get_option( tfc_si_job_key() . '_total' );
	if ( ! is_array( $state ) || ! $total ) wp_send_json_error( 'There is no import in progress.' );
	if ( ! empty( $_POST['cancel'] ) ) {
		tfc_si_job_clear();
		wp_send_json_success( [ 'cancelled' => true, 'i' => (int) $state['i'], 'total' => $total ] );
	}
	$groups = get_option( tfc_si_job_key() );
	$meta   = (array) get_option( tfc_si_job_key() . '_meta' );
	if ( ! is_array( $groups ) ) {
		tfc_si_job_clear();
		wp_send_json_error( 'The import list was lost. Start the import again.' );
	}
	tfc_si_import_env();
	global $tfc_si_img_fails;
	$tfc_si_img_fails = (array) ( $state['fails'] ?? [] );
	$keys  = array_keys( $groups );
	$i     = (int) $state['i'];
	$limit = microtime( true ) + TFC_SI_STEP_SECONDS;
	while ( $i < $total && microtime( true ) < $limit ) {
		tfc_si_import_one( $keys[ $i ], $groups[ $keys[ $i ] ], ! empty( $meta['refile'] ), microtime( true ) < $limit - 3 );
		$i++;
		update_option( tfc_si_job_key() . '_state', [ 'i' => $i, 'fails' => $tfc_si_img_fails ], false ); // progress survives a cut-off request
	}
	if ( $i < $total ) wp_send_json_success( [ 'i' => $i, 'total' => $total, 'done' => false ] );

	// Finished: hide the dearer copies that a cheaper listing replaced, and report.
	$retire = (array) ( $meta['retire'] ?? [] );
	foreach ( $retire as $old_id ) {
		wp_update_post( [ 'ID' => $old_id, 'post_status' => 'draft' ] );
		update_post_meta( $old_id, '_tfc_si_retired', 'replaced by a cheaper listing of the same product' );
	}
	$dead    = array_keys( array_filter( $tfc_si_img_fails, fn( $n ) => $n >= 5 ) );
	$message = sprintf( 'Saved %d products to WooCommerce. <a href="%s">View products</a>', $total, esc_url( admin_url( 'edit.php?post_type=product' ) ) )
		. tfc_si_dupe_note( (array) ( $meta['dupes'] ?? [] ), count( $retire ) )
		. ( $dead ? ' Images from ' . esc_html( implode( ', ', $dead ) ) . ' were skipped because their links aren’t working; ask the supplier for current image links.' : '' );
	tfc_si_job_clear();
	wp_send_json_success( [ 'i' => $total, 'total' => $total, 'done' => true, 'message' => $message ] );
} );

// The progress box and the script that drives it. Printed on the Supplier Import page.
function tfc_si_job_ui() {
	$state = tfc_si_job_state();
	?>
	<div id="tfc-si-progress" class="notice notice-info" hidden style="padding:12px 16px">
		<p><strong id="tfc-si-p-text">Importing…</strong></p>
		<progress id="tfc-si-p-bar" max="1" value="0" style="width:100%;max-width:520px;height:18px"></progress>
		<p class="description">Keep this page open. The import runs in small batches, so it can take a while for a big list; stopping keeps everything saved so far.</p>
		<p>
			<button type="button" class="button" id="tfc-si-p-stop">Stop</button>
			<button type="button" class="button button-primary" id="tfc-si-p-go" hidden>Continue import</button>
			<button type="button" class="button" id="tfc-si-p-discard" hidden>Discard the rest</button>
		</p>
	</div>
	<script>
	(() => {
		const box = document.getElementById('tfc-si-progress'), text = document.getElementById('tfc-si-p-text'), bar = document.getElementById('tfc-si-p-bar');
		const stopBtn = document.getElementById('tfc-si-p-stop'), goBtn = document.getElementById('tfc-si-p-go'), discardBtn = document.getElementById('tfc-si-p-discard');
		const nonce = () => document.querySelector('input[name=_wpnonce]').value; // read when needed: the forms come after this script
		const n = v => Number(v).toLocaleString();
		let stopping = false, running = false;

		// One request, retried when the host cuts it off (a 504 comes back as a page, not JSON): the step is safe to repeat.
		const post = async (fields) => {
			const body = new FormData();
			Object.entries(fields).forEach(([k, v]) => body.append(k, v));
			body.append('_wpnonce', nonce());
			for (let tries = 0; ; tries++) {
				try {
					const r = await fetch(ajaxurl, { method: 'POST', body, credentials: 'same-origin' });
					if (r.status === 401 || r.status === 403) throw Object.assign(new Error('refused'), { refused: r.status });
					return await r.json();
				} catch (e) {
					if (e.refused || tries >= 20) throw e;
					text.textContent += ' (the server is slow, retrying…)';
					await new Promise(r => setTimeout(r, 3000));
				}
			}
		};
		const notice = (kind, html) => {
			const el = document.createElement('div');
			el.className = 'notice notice-' + kind;
			el.innerHTML = '<p>' + html + '</p>';
			document.querySelector('.wrap h1').after(el);
		};
		// A 403 is the site refusing the request, so it isn't retried: usually the login expired, or a firewall / security plugin blocked admin-ajax.php.
		const refusal = (e) => e.refused ? ' The server refused the request (HTTP ' + e.refused + ' Forbidden). If you were away from the page a while, reload it and sign in again. If it keeps happening, a firewall or security plugin on your host is probably blocking admin-ajax.php; ask the host to allow it.' : '';
		const buttons = (on) => document.querySelectorAll('#tfc-si button[name=tfc_si]').forEach(b => b.disabled = !on);

		const run = async (i, total) => {
			running = true; stopping = false; buttons(false);
			box.hidden = false; stopBtn.hidden = false; goBtn.hidden = discardBtn.hidden = true;
			try {
				while (i < total && !stopping) {
					text.textContent = 'Importing… ' + n(i) + ' of ' + n(total);
					bar.max = total; bar.value = i;
					const r = await post({ action: 'tfc_si_step' });
					if (!r.success) { box.hidden = true; notice('error', r.data); break; }
					i = r.data.i;
					if (r.data.done) { box.hidden = true; notice('success', r.data.message); i = total; break; }
				}
				if (stopping) {
					await post({ action: 'tfc_si_step', cancel: 1 });
					box.hidden = true;
					notice('warning', 'Import stopped after ' + n(i) + ' of ' + n(total) + ' products. Those are saved; the rest were not imported.');
				}
			} catch (e) {
				text.textContent = 'Lost contact with the server after ' + n(i) + ' of ' + n(total) + ' products.' + refusal(e);
				bar.value = i; stopBtn.hidden = true; goBtn.hidden = discardBtn.hidden = false;
				goBtn.onclick = () => run(i, total);
			}
			running = false; buttons(true);
		};
		stopBtn.onclick = () => { stopping = true; stopBtn.disabled = true; };
		discardBtn.onclick = async () => { await post({ action: 'tfc_si_step', cancel: 1 }); box.hidden = true; buttons(true); };

		// The Import button on the items form starts a job instead of submitting the page.
		window.tfcStartImport = async (form) => {
			buttons(false);
			const fields = new FormData(form);
			fields.append('action', 'tfc_si_start');
			text.textContent = 'Preparing the import…'; bar.value = 0; box.hidden = false; stopBtn.hidden = true;
			try {
				const resp = await fetch(ajaxurl, { method: 'POST', body: fields, credentials: 'same-origin' });
				if (resp.status === 401 || resp.status === 403) throw Object.assign(new Error('refused'), { refused: resp.status });
				const r = await resp.json();
				if (!r.success) { box.hidden = true; buttons(true); notice('warning', r.data); return; }
				stopBtn.hidden = false; stopBtn.disabled = false;
				run(r.data.i, r.data.total);
			} catch (e) {
				box.hidden = true; buttons(true);
				notice('error', 'Couldn’t start the import (the server didn’t answer). Try again.' + refusal(e));
			}
		};

		<?php if ( $state ) : ?>
		// An import from earlier was left unfinished: offer to carry on (once the page, with its buttons, is loaded).
		document.addEventListener('DOMContentLoaded', () => {
			const i = <?php echo (int) $state[0]; ?>, total = <?php echo (int) $state[1]; ?>;
			box.hidden = false; bar.max = total; bar.value = i; stopBtn.hidden = true; goBtn.hidden = discardBtn.hidden = false;
			text.textContent = 'An import was left unfinished: ' + n(i) + ' of ' + n(total) + ' products done.';
			goBtn.onclick = () => run(i, total);
			buttons(false);
		});
		<?php endif; ?>
	})();
	</script>
	<?php
}
