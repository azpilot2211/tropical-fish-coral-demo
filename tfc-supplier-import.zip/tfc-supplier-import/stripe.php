<?php
// Stripe card payments without a separate payment plugin. The owner pastes test and live keys on
// WooCommerce → Stripe and picks which to use. At checkout, "Credit or debit card" sends the customer
// to Stripe's own payment page (card details never touch this site) for the order total, and the order
// is marked paid only after asking Stripe: when the customer comes back, and again from Stripe's signed
// webhook in case they close the tab first.
defined( 'ABSPATH' ) || exit;

// Saved settings: mode (test|live) and {mode}_pk, {mode}_sk, {mode}_whsec.
function tfc_stripe_settings() {
	return (array) get_option( 'tfc_stripe', [] ) + [ 'mode' => 'test', 'test_pk' => '', 'test_sk' => '', 'test_whsec' => '', 'live_pk' => '', 'live_sk' => '', 'live_whsec' => '' ];
}

function tfc_stripe_api( $method, $path, $secret, array $body = [], array $headers = [] ) {
	$res = wp_remote_request( 'https://api.stripe.com/v1/' . $path, [
		'method'  => $method,
		'timeout' => 30,
		'headers' => [ 'Authorization' => 'Bearer ' . $secret ] + $headers,
		'body'    => $body ?: null,
	] );
	if ( is_wp_error( $res ) ) return new WP_Error( 'stripe', 'Couldn’t reach Stripe: ' . $res->get_error_message() );
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( ! is_array( $data ) ) return new WP_Error( 'stripe', 'Stripe sent an unreadable reply.' );
	if ( isset( $data['error'] ) ) return new WP_Error( 'stripe', 'Stripe: ' . ( $data['error']['message'] ?? 'request refused' ) );
	return $data;
}

// A Stripe Checkout page for the order's total. Returns the session (its 'url' is where to send the customer).
function tfc_stripe_create_session( WC_Order $order ) {
	$s     = tfc_stripe_settings();
	$mode  = $s['mode'];
	$cents = tfc_stripe_amount( $order->get_total() );
	$items = implode( ', ', array_map( fn( $i ) => $i->get_quantity() . ' × ' . $i->get_name(), array_values( $order->get_items() ) ) );
	$body  = [
		'mode'                => 'payment',
		'client_reference_id' => (string) $order->get_id(),
		'customer_email'      => $order->get_billing_email(),
		// add_query_arg() leaves {CHECKOUT_SESSION_ID} as is; Stripe fills it in.
		'success_url'         => add_query_arg( 'tfc_stripe_session', '{CHECKOUT_SESSION_ID}', $order->get_checkout_order_received_url() ),
		'cancel_url'          => wc_get_checkout_url(),
		'line_items'          => [ [
			'quantity'   => 1,
			'price_data' => [
				'currency'     => strtolower( $order->get_currency() ),
				'unit_amount'  => $cents,
				'product_data' => [ 'name' => sprintf( 'Order #%s, %s', $order->get_order_number(), get_bloginfo( 'name' ) ), 'description' => mb_substr( $items, 0, 480 ) ],
			],
		] ],
		'metadata'            => [ 'order_id' => $order->get_id() ],
		'payment_intent_data' => [ 'metadata' => [ 'order_id' => $order->get_id() ], 'description' => sprintf( 'Order #%s', $order->get_order_number() ) ],
	];
	// Same order and total → same Stripe page, so a double click doesn't make two.
	$key     = 'tfc-' . $order->get_id() . '-' . md5( $cents . $order->get_currency() . $order->get_billing_email() );
	$session = tfc_stripe_api( 'POST', 'checkout/sessions', $s["{$mode}_sk"], $body, [ 'Idempotency-Key' => $key ] );
	if ( is_wp_error( $session ) ) return $session;
	$order->update_meta_data( '_tfc_stripe_session', $session['id'] );
	$order->update_meta_data( '_tfc_stripe_mode', $mode );
	$order->save();
	return $session;
}

// Marks the order paid when a Stripe Checkout session for it is paid for exactly the order's total;
// a paid session with a different total (say, an old tab paid after the cart changed) puts the order
// on hold with a note instead. $session always comes from Stripe (signed webhook, or fetched with
// the secret key). Safe to run twice (return page and webhook).
function tfc_stripe_complete( array $session ) {
	$order = wc_get_order( (int) ( $session['metadata']['order_id'] ?? 0 ) );
	if ( ! $order || $order->get_payment_method() !== 'tfc_stripe' ) return;
	if ( ( $session['payment_status'] ?? '' ) !== 'paid' || $order->is_paid() ) return;
	if ( (int) ( $session['amount_total'] ?? -1 ) !== tfc_stripe_amount( $order->get_total() ) || strtolower( $session['currency'] ?? '' ) !== strtolower( $order->get_currency() ) ) {
		$order->update_status( 'on-hold', 'Stripe’s paid amount doesn’t match this order’s total. Check the payment in Stripe before shipping.' );
		return;
	}
	$order->payment_complete( (string) ( $session['payment_intent'] ?? '' ) );
	$order->add_order_note( sprintf( 'Paid with Stripe (%s mode). Payment %s.', $order->get_meta( '_tfc_stripe_mode' ), $session['payment_intent'] ?? '' ) );
}

// Back from Stripe: ask Stripe (not the address bar) whether it's paid.
add_action( 'template_redirect', function () {
	if ( empty( $_GET['tfc_stripe_session'] ) || ! is_order_received_page() ) return;
	$order = wc_get_order( absint( get_query_var( 'order-received' ) ) );
	$id    = sanitize_text_field( wp_unslash( $_GET['tfc_stripe_session'] ) );
	if ( ! $order || $order->get_meta( '_tfc_stripe_session' ) !== $id || $order->is_paid() ) return;
	$session = tfc_stripe_api( 'GET', 'checkout/sessions/' . rawurlencode( $id ), tfc_stripe_settings()[ $order->get_meta( '_tfc_stripe_mode' ) . '_sk' ] ?? '' );
	if ( ! is_wp_error( $session ) ) tfc_stripe_complete( $session );
} );

// Stripe's webhook: https://your-site/wp-json/tfc/v1/stripe-webhook
add_action( 'rest_api_init', function () {
	register_rest_route( 'tfc/v1', '/stripe-webhook', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true', // anyone may call it; only Stripe can sign it
		'callback'            => function ( WP_REST_Request $request ) {
			$payload = $request->get_body();
			$event   = json_decode( $payload, true );
			$secret  = tfc_stripe_settings()[ ( empty( $event['livemode'] ) ? 'test' : 'live' ) . '_whsec' ];
			if ( ! is_array( $event ) || ! tfc_stripe_signature_ok( $payload, $request->get_header( 'stripe-signature' ), $secret, time() ) ) {
				return new WP_REST_Response( [ 'error' => 'Signature check failed.' ], 400 );
			}
			if ( in_array( $event['type'] ?? '', [ 'checkout.session.completed', 'checkout.session.async_payment_succeeded' ], true ) ) {
				tfc_stripe_complete( (array) ( $event['data']['object'] ?? [] ) );
			}
			return new WP_REST_Response( [ 'received' => true ], 200 );
		},
	] );
} );

// The payment method. Declared once WooCommerce has loaded (it may load after this plugin).
add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	class TFC_Stripe_Gateway extends WC_Payment_Gateway {
		public function __construct() {
			$this->id                 = 'tfc_stripe';
			$this->method_title       = 'Stripe (card)';
			$this->method_description = 'Card payments on Stripe’s own payment page. Keys and test/live mode: WooCommerce → Stripe.';
			$this->has_fields         = false;
			$this->form_fields        = [
				'enabled'     => [ 'title' => 'Enable', 'type' => 'checkbox', 'label' => 'Take card payments with Stripe', 'default' => 'yes' ],
				'title'       => [ 'title' => 'Title', 'type' => 'text', 'default' => 'Credit or debit card' ],
				'description' => [ 'title' => 'Description', 'type' => 'textarea', 'default' => 'You’ll pay securely on Stripe’s checkout page, then come back here.' ],
			];
			$this->init_settings();
			$this->enabled     = $this->get_option( 'enabled' );
			$this->title       = $this->get_option( 'title' );
			$this->description = $this->get_option( 'description' );
			if ( tfc_stripe_settings()['mode'] === 'test' ) $this->description .= ' (Test mode: pay with card 4242 4242 4242 4242, any future date and any CVC.)';
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
		}

		public function is_available() {
			$s = tfc_stripe_settings();
			return parent::is_available() && $s[ $s['mode'] . '_pk' ] !== '' && $s[ $s['mode'] . '_sk' ] !== '';
		}

		public function process_payment( $order_id ) {
			$session = tfc_stripe_create_session( wc_get_order( $order_id ) );
			if ( is_wp_error( $session ) ) {
				wc_add_notice( 'Card payment couldn’t start. ' . $session->get_error_message(), 'error' );
				return [ 'result' => 'failure' ];
			}
			return [ 'result' => 'success', 'redirect' => $session['url'] ];
		}
	}

	add_filter( 'woocommerce_payment_gateways', fn( $gateways ) => array_merge( $gateways, [ 'TFC_Stripe_Gateway' ] ) );
} );

// The block checkout (WooCommerce's default) lists a payment method only when it's registered for blocks too.
add_action( 'woocommerce_blocks_loaded', function () {
	if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) return;

	class TFC_Stripe_Blocks extends Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
		protected $name = 'tfc_stripe';

		public function initialize() {
			$this->settings = get_option( 'woocommerce_tfc_stripe_settings', [] );
		}

		public function is_active() {
			$gateway = WC()->payment_gateways()->payment_gateways()['tfc_stripe'] ?? null;
			return $gateway && $gateway->is_available();
		}

		public function get_payment_method_script_handles() {
			wp_register_script( 'tfc-stripe-blocks', plugins_url( 'stripe-blocks.js', __FILE__ ), [ 'wc-blocks-registry', 'wc-settings', 'wp-element' ], '1', true );
			return [ 'tfc-stripe-blocks' ];
		}

		public function get_payment_method_data() {
			$gateway = WC()->payment_gateways()->payment_gateways()['tfc_stripe'] ?? null;
			return [ 'title' => $gateway ? $gateway->title : 'Credit or debit card', 'description' => $gateway ? $gateway->description : '', 'supports' => [ 'products' ] ];
		}
	}

	add_action( 'woocommerce_blocks_payment_method_type_registration', fn( $registry ) => $registry->register( new TFC_Stripe_Blocks() ) );
} );

// ---- Settings page: WooCommerce → Stripe ----------------------------------

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Stripe', 'Stripe', 'manage_woocommerce', 'tfc-stripe', 'tfc_stripe_page' );
} );

function tfc_stripe_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) return;
	$s        = tfc_stripe_settings();
	$problems = [];
	$status   = '';
	if ( isset( $_POST['tfc_stripe'] ) ) {
		check_admin_referer( 'tfc_stripe' );
		$in        = (array) wp_unslash( $_POST['tfc_stripe'] );
		$s['mode'] = ( $in['mode'] ?? '' ) === 'live' ? 'live' : 'test';
		foreach ( [ 'test', 'live' ] as $mode ) {
			foreach ( [ 'pk', 'sk', 'whsec' ] as $kind ) {
				$value = trim( sanitize_text_field( $in[ "{$mode}_{$kind}" ] ?? '' ) );
				if ( $kind !== 'pk' && $value === '' ) continue; // secrets: a blank box keeps the saved one
				if ( $problem = tfc_stripe_key_problem( $kind, $value, $mode ) ) {
					$problems[] = ucfirst( $mode ) . ': ' . $problem;
					continue;
				}
				$s[ "{$mode}_{$kind}" ] = $value;
			}
			if ( ! empty( $in[ "{$mode}_forget" ] ) ) $s[ "{$mode}_pk" ] = $s[ "{$mode}_sk" ] = $s[ "{$mode}_whsec" ] = '';
		}
		update_option( 'tfc_stripe', $s, false );
		// Check the keys in use actually work.
		$sk = $s[ $s['mode'] . '_sk' ];
		if ( $sk !== '' ) {
			$account = tfc_stripe_api( 'GET', 'account', $sk );
			$status  = is_wp_error( $account ) ? $account->get_error_message()
				: sprintf( 'Connected to %s in %s mode.', $account['settings']['dashboard']['display_name'] ?? $account['business_profile']['name'] ?? $account['email'] ?? 'your Stripe account', $s['mode'] );
			$status  = [ is_wp_error( $account ) ? 'error' : 'success', $status ];
		}
	}
	$webhook = rest_url( 'tfc/v1/stripe-webhook' );
	$gateway = get_option( 'woocommerce_tfc_stripe_settings', [] );
	?>
	<div class="wrap">
	<h1>Stripe</h1>
	<?php foreach ( $problems as $p ) printf( '<div class="notice notice-error"><p>%s Not saved.</p></div>', esc_html( $p ) ); ?>
	<?php if ( $status ) printf( '<div class="notice notice-%s"><p>%s</p></div>', esc_attr( $status[0] ), esc_html( $status[1] ) ); ?>
	<?php if ( isset( $_POST['tfc_stripe'] ) && ! $problems && ! $status ) echo '<div class="notice notice-success"><p>Saved.</p></div>'; ?>
	<p style="max-width:720px">Customers who choose <strong>Credit or debit card</strong> at checkout pay on Stripe’s own secure page, then come back to their order confirmation. Find your keys in the Stripe Dashboard under <strong>Developers → API keys</strong> (switch the Dashboard to test mode for the test keys).</p>
	<?php if ( ( $gateway['enabled'] ?? 'yes' ) === 'no' ) printf( '<div class="notice notice-warning inline"><p>Card payments are switched off in <a href="%s">WooCommerce → Settings → Payments</a>.</p></div>', esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=tfc_stripe' ) ) ); ?>
	<form method="post">
		<?php wp_nonce_field( 'tfc_stripe' ); ?>
		<table class="form-table">
			<tr>
				<th>Account to use</th>
				<td>
					<fieldset>
						<label><input type="radio" name="tfc_stripe[mode]" value="test" <?php checked( $s['mode'], 'test' ); ?>> <strong>Test</strong>: no real money; pay with Stripe’s test card 4242 4242 4242 4242</label><br>
						<label><input type="radio" name="tfc_stripe[mode]" value="live" <?php checked( $s['mode'], 'live' ); ?>> <strong>Live</strong>: real payments</label>
					</fieldset>
				</td>
			</tr>
		</table>
		<?php foreach ( [ 'test' => 'Test keys', 'live' => 'Live keys' ] as $mode => $heading ) : ?>
			<h2><?php echo esc_html( $heading ); ?></h2>
			<table class="form-table">
				<tr>
					<th><label for="tfc-<?php echo $mode; ?>-pk">Publishable key</label></th>
					<td><input id="tfc-<?php echo $mode; ?>-pk" name="tfc_stripe[<?php echo $mode; ?>_pk]" class="large-text code" autocomplete="off" placeholder="pk_<?php echo $mode; ?>_…" value="<?php echo esc_attr( $s[ "{$mode}_pk" ] ); ?>"></td>
				</tr>
				<?php foreach ( [ 'sk' => [ 'Secret key', "sk_{$mode}_…" ], 'whsec' => [ 'Webhook signing secret', 'whsec_…' ] ] as $kind => [ $label, $placeholder ] ) : ?>
					<tr>
						<th><label for="tfc-<?php echo $mode . '-' . $kind; ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input id="tfc-<?php echo $mode . '-' . $kind; ?>" type="password" name="tfc_stripe[<?php echo $mode . '_' . $kind; ?>]" class="large-text code" autocomplete="new-password" placeholder="<?php echo esc_attr( $placeholder ); ?>">
							<p class="description"><?php echo esc_html( tfc_mask_secret( $s[ "{$mode}_{$kind}" ] ) ); ?>. Leave blank to keep it.</p>
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th></th>
					<td><label><input type="checkbox" name="tfc_stripe[<?php echo $mode; ?>_forget]" value="1"> Remove the saved <?php echo $mode; ?> keys</label></td>
				</tr>
			</table>
		<?php endforeach; ?>
		<h2>Webhook</h2>
		<p style="max-width:720px">So orders are marked paid even when a customer closes the tab before coming back: in the Stripe Dashboard go to <strong>Developers → Webhooks</strong> (in test mode for the test secret, live mode for the live one), add an endpoint with this address, pick the events <code>checkout.session.completed</code> and <code>checkout.session.async_payment_succeeded</code>, then paste its signing secret above.</p>
		<p><input type="text" class="large-text code" readonly value="<?php echo esc_attr( $webhook ); ?>" onfocus="this.select()"></p>
		<?php submit_button( 'Save and check keys' ); ?>
	</form>
	</div>
	<?php
}
