<?php
// Supplier sites behind a login: spot the login wall, ask for the username and password in a dialog,
// log in through the site's own login form, and keep that site's session cookies (never the password)
// for 12 hours, so fetches and photo searches there go through as the logged-in account.
defined( 'ABSPATH' ) || exit;

function tfc_si_site( $url ) {
	return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );
}

// Same website, or one's a subdomain of the other (shop.x.com / x.com).
function tfc_si_same_site( $a, $b ) {
	[ $a, $b ] = [ tfc_si_site( $a ), tfc_si_site( $b ) ];
	return $a !== '' && ( $a === $b || substr( ".$a", -strlen( ".$b" ) ) === ".$b" || substr( ".$b", -strlen( ".$a" ) ) === ".$a" );
}

function tfc_si_cookie_key( $url ) {
	return 'tfc_si_auth_' . get_current_user_id() . '_' . md5( tfc_si_site( $url ) );
}

// GET, sending the saved login cookies for that site if there are any.
function tfc_si_remote_get( $url ) {
	return wp_safe_remote_get( $url, [ 'timeout' => 20, 'cookies' => get_transient( tfc_si_cookie_key( $url ) ) ?: [] ] );
}

// The address a response ended up at, after redirects.
function tfc_si_final_url( $res, $url ) {
	return isset( $res['http_response'] ) ? $res['http_response']->get_response_object()->url : $url;
}

// The login page a response is asking for, or '' if it isn't asking: a 401, or a redirect to a
// login-looking address. $loose (a fetch that found no products) also counts any page with a login form.
function tfc_si_login_url( $res, $url, $loose = false ) {
	if ( is_wp_error( $res ) ) return '';
	$final = tfc_si_final_url( $res, $url );
	if ( wp_remote_retrieve_response_code( $res ) === 401 ) return $final;
	if ( $final !== $url && preg_match( '#log-?in|sign-?in|account|auth|password#i', (string) wp_parse_url( $final, PHP_URL_PATH ) ) ) return $final;
	if ( $loose && tfc_si_login_form( wp_remote_retrieve_body( $res ) ) ) return $final;
	return '';
}

// Cookies a response set, added to $jar; ones it expired are removed.
function tfc_si_keep_cookies( array $jar, $res ) {
	foreach ( wp_remote_retrieve_cookies( $res ) as $c ) {
		if ( $c->value === '' || ( $c->expires && $c->expires < time() ) ) unset( $jar[ $c->name ] );
		else $jar[ $c->name ] = $c->value;
	}
	return $jar;
}

// The login form at $login_url, ready to post: [ action URL, fields, username field, password field,
// cookies from the login page ], or a WP_Error. When that page has no login form (say it's the home
// page), $look tries its sign-in links and the usual login addresses. Refuses a form that would send
// the password to another website or unencrypted. Nothing is posted here.
function tfc_si_login_target( $login_url, $look = true ) {
	$res = wp_safe_remote_get( $login_url, [ 'timeout' => 20 ] );
	if ( is_wp_error( $res ) ) return new WP_Error( 'login', 'Couldn’t open the login page: ' . $res->get_error_message() );
	$body = wp_remote_retrieve_body( $res );
	$page = tfc_si_final_url( $res, $login_url );
	$form = tfc_si_login_form( $body );
	if ( ! $form && $look ) {
		foreach ( tfc_si_login_guesses( $body, $page ) as $try ) {
			$t = tfc_si_login_target( $try, false );
			if ( ! is_wp_error( $t ) || $t->get_error_code() === 'refused' ) return $t;
		}
		// Shopify's newer customer accounts sign in with a code sent by email, not a password.
		if ( preg_grep( '#^https://(shopify\.com/\d+/account|account\.)|/customer_authentication/#', array_merge( [ $page ], tfc_si_login_links( $body ) ) ) ) {
			return new WP_Error( 'login', 'This store signs customers in with a code emailed to them (Shopify customer accounts) instead of a password, so the plugin can’t log in. Ask the supplier for a spreadsheet or product feed instead.' );
		}
	}
	if ( ! $form ) return new WP_Error( 'login', 'No login form found there. Open the page where you sign in on their site and paste its address into Login page. If their sign-in only appears after clicking (built with JavaScript), the plugin can’t log in there; ask for a spreadsheet instead.' );
	[ $action, $fields, $user_field, $pass_field ] = $form;
	$action = WP_Http::make_absolute_url( $action !== '' ? $action : $page, $page );
	if ( ! tfc_si_same_site( $action, $page ) ) return new WP_Error( 'refused', 'That login form sends passwords to a different website, so nothing was sent.' );
	if ( wp_parse_url( $action, PHP_URL_SCHEME ) !== 'https' ) return new WP_Error( 'refused', 'That login form isn’t secure (no https), so the password wasn’t sent.' );
	return [ $action, $fields, $user_field, $pass_field, tfc_si_keep_cookies( [], $res ) ];
}

// Where to look for the login form when a page has none: its sign-in links on the same site, then
// the usual login addresses of WooCommerce, Shopify, BigCommerce and Magento shops. At most 6 tries.
function tfc_si_login_guesses( $html, $page ) {
	$root  = preg_replace( '~^(https?://[^/?#]+).*~', '$1', $page );
	$tries = array_map( fn( $h ) => WP_Http::make_absolute_url( $h, $page ), tfc_si_login_links( $html ) );
	foreach ( [ '/my-account/', '/account/login', '/login.php', '/customer/account/login/', '/login' ] as $path ) $tries[] = $root . $path;
	$tries = array_filter( $tries, fn( $u ) => $u !== $page && tfc_si_same_site( $u, $page ) );
	return array_slice( array_values( array_unique( $tries ) ), 0, 6 );
}

// Logs in with the form at $login_url and saves the session for $for_url's site. True, or a WP_Error.
function tfc_si_login( $login_url, $user, $pass, $for_url ) {
	$target = tfc_si_login_target( $login_url );
	if ( is_wp_error( $target ) ) return $target;
	[ $action, $fields, $user_field, $pass_field, $jar ] = $target;
	if ( $user_field !== '' ) $fields[ $user_field ] = $user;
	$fields[ $pass_field ] = $pass;

	// Post the form, then follow its redirects on the same site, collecting the session cookies they set.
	$site = $action;
	$args = [ 'method' => 'POST', 'body' => $fields ];
	for ( $hop = 0; $hop < 5 && $action !== '' && tfc_si_same_site( $action, $site ); $hop++ ) {
		$res = wp_safe_remote_request( $action, $args + [ 'timeout' => 20, 'redirection' => 0, 'cookies' => $jar ] );
		if ( is_wp_error( $res ) ) return new WP_Error( 'login', 'The login didn’t go through: ' . $res->get_error_message() );
		$jar    = tfc_si_keep_cookies( $jar, $res );
		$loc    = wp_remote_retrieve_header( $res, 'location' );
		$action = $loc ? WP_Http::make_absolute_url( $loc, $action ) : '';
		$args   = [ 'method' => 'GET' ];
	}
	set_transient( tfc_si_cookie_key( $for_url ), $jar, 12 * HOUR_IN_SECONDS );
	return true;
}

// Logs in with the dialog's fields when it was submitted. An error message, or '' (logged in, or no login posted).
function tfc_si_login_posted( $for_url ) {
	$f = wp_unslash( $_POST['tfc_login'] ?? null );
	if ( ! is_array( $f ) ) return '';
	$r = tfc_si_login( esc_url_raw( trim( $f['url'] ?? '' ) ), trim( $f['user'] ?? '' ), (string) ( $f['pass'] ?? '' ), $for_url );
	return is_wp_error( $r ) ? $r->get_error_message() : '';
}

// The login dialog. Its fields belong to the page's form $form_id, so logging in re-runs that form's
// fetch or photo search ($submit: that form's [ button name, value ]). It opens on page load when
// $open (a login wall was just hit); otherwise that form's "Log in" button opens it. The fields stay
// disabled while it's closed, so they don't block or ride along with the form's normal submit.
function tfc_si_login_dialog( $form_id, array $submit, $login_url = '', $error = '', $open = false ) {
	$f = (array) wp_unslash( $_POST['tfc_login'] ?? [] );
	if ( $open && $error === '' && $f ) {
		$error = 'The site still asks for a login. Check the username and password. Sites with a captcha or “Sign in with Google” can’t be logged into from here; ask the supplier for a spreadsheet instead.';
	}
	$login_url = $f['url'] ?? $login_url;
	$user      = $f['user'] ?? '';
	$site      = tfc_si_site( $login_url );
	$in        = sprintf( 'form="%s" class="large-text" disabled', esc_attr( $form_id ) );
	?>
	<style>#tfc-login { width: min(460px, calc(100vw - 32px)); padding: 24px 28px; border: 0; border-radius: 8px; box-shadow: 0 12px 48px rgba(0,0,0,.3); } #tfc-login::backdrop { background: rgba(0,0,0,.45); }</style>
	<dialog id="tfc-login" aria-labelledby="tfc-login-title">
		<h2 id="tfc-login-title" style="margin-top:0">Log in to <?php echo $site ? esc_html( $site ) : 'the supplier’s website'; ?></h2>
		<p>Use your account on the supplier’s website. Your password is only used to log in and isn’t saved; the login lasts 12 hours.</p>
		<?php if ( $error ) printf( '<div class="notice notice-error inline"><p>%s</p></div>', esc_html( $error ) ); ?>
		<p><label>Login page<br><input type="url" name="tfc_login[url]" <?php echo $in; ?> required placeholder="https://supplier.com/login" value="<?php echo esc_attr( $login_url ); ?>"></label>
			<span class="description">Their home page is fine: the plugin finds the login form from there.</span></p>
		<p><label>Username or email<br><input type="text" name="tfc_login[user]" <?php echo $in; ?> autocomplete="off" value="<?php echo esc_attr( $user ); ?>" <?php echo $user === '' ? 'autofocus' : ''; ?>></label></p>
		<p><label>Password<br><input type="password" name="tfc_login[pass]" <?php echo $in; ?> required autocomplete="new-password" <?php echo $user === '' ? '' : 'autofocus'; ?>></label></p>
		<p style="display:flex;gap:8px;justify-content:flex-end;margin-bottom:0">
			<button type="button" class="button" data-tfc-login-cancel>Cancel</button>
			<button class="button button-primary" form="<?php echo esc_attr( $form_id ); ?>" name="<?php echo esc_attr( $submit[0] ); ?>" value="<?php echo esc_attr( $submit[1] ); ?>" disabled>Log in and continue</button>
		</p>
	</dialog>
	<script>
	(() => {
		const d = document.getElementById('tfc-login'), form = document.getElementById(<?php echo wp_json_encode( $form_id ); ?>);
		const address = form.querySelector('input[type=url]'), page = d.querySelector('[name="tfc_login[url]"]');
		const enable = on => d.querySelectorAll('[form]').forEach(el => el.disabled = !on);
		const open = () => {
			if (!page.value) try { page.value = new URL(address.value).origin + '/'; } catch (e) {}
			enable(true);
			d.showModal();
		};
		d.addEventListener('close', () => enable(false)); // Esc; the event arrives a moment later
		d.querySelector('[data-tfc-login-cancel]').addEventListener('click', () => { enable(false); d.close(); });
		form.querySelectorAll('[data-tfc-login]').forEach(b => b.addEventListener('click', () => address.reportValidity() && open()));
		<?php if ( $open ) echo 'open();'; ?>
	})();
	</script>
	<?php
}
