<?php
// Live FedEx and UPS rates at checkout. A cart's live goods are quoted FedEx Priority Overnight and its
// dry goods UPS Ground; a mixed cart pays both (the same split as Shipping by State). Credentials, test
// or live mode, box sizes and handling are on WooCommerce → Carrier Rates. Whatever part a carrier can't
// price falls back to the Shipping by State table, so checkout always has a price, and the table still
// decides where you ship (blank state = no shipping, "Ship live" off = no live goods).
defined( 'ABSPATH' ) || exit;

const TFC_CARRIER_HOSTS = [
	'fedex' => [ 'test' => 'https://apis-sandbox.fedex.com', 'live' => 'https://apis.fedex.com' ],
	'ups'   => [ 'test' => 'https://wwwcie.ups.com', 'live' => 'https://onlinetools.ups.com' ],
];
const TFC_CARRIER_FOR = [ 'live' => [ 'fedex', 'FedEx Priority Overnight' ], 'dry' => [ 'ups', 'UPS Ground' ] ];

function tfc_carrier_settings() {
	$s = (array) get_option( 'tfc_carriers', [] ) + [ 'enabled' => false, 'mode' => 'test', 'handling' => 0, 'markup' => 0, 'live_box' => [ 16, 16, 16 ], 'live_max' => 30, 'dry_box' => [ 14, 14, 14 ], 'dry_max' => 50 ];
	foreach ( [ 'fedex', 'ups' ] as $c ) foreach ( [ 'test', 'live' ] as $m ) foreach ( [ 'key', 'secret', 'account' ] as $f ) $s[ "{$c}_{$m}_{$f}" ] = $s[ "{$c}_{$m}_{$f}" ] ?? '';
	return $s;
}

// Ship-from [ ZIP, state ] from WooCommerce → Settings → General, or null if it's incomplete.
function tfc_carrier_origin() {
	[ $country, $state ] = array_pad( explode( ':', (string) get_option( 'woocommerce_default_country', '' ) ), 2, '' );
	$zip = substr( preg_replace( '/\D/', '', (string) get_option( 'woocommerce_store_postcode', '' ) ), 0, 5 );
	return $country === 'US' && $state && strlen( $zip ) === 5 ? [ $zip, $state ] : null;
}

function tfc_carrier_ready( $carrier ) {
	$s = tfc_carrier_settings();
	$p = "{$carrier}_{$s['mode']}_";
	return $s[ $p . 'key' ] !== '' && $s[ $p . 'secret' ] !== '' && $s[ $p . 'account' ] !== '';
}

// FedEx: { errors: [ { message } ] }; UPS: { response: { errors: [ { message } ] } }.
function tfc_carrier_error( $res, $data ) {
	if ( is_wp_error( $res ) ) return $res->get_error_message();
	$e = $data['errors'][0] ?? $data['response']['errors'][0] ?? null;
	return $e['message'] ?? $e['code'] ?? 'HTTP ' . wp_remote_retrieve_response_code( $res );
}

// OAuth access token, cached until shortly before it expires. $fresh skips the cache.
function tfc_carrier_token( $carrier, $mode, $fresh = false ) {
	$s      = tfc_carrier_settings();
	$key    = $s["{$carrier}_{$mode}_key"];
	$secret = $s["{$carrier}_{$mode}_secret"];
	$cache  = "tfc_token_{$carrier}_{$mode}_" . md5( $key . $secret );
	if ( ! $fresh && ( $token = get_transient( $cache ) ) ) return $token;
	$args = $carrier === 'fedex'
		? [ 'body' => [ 'grant_type' => 'client_credentials', 'client_id' => $key, 'client_secret' => $secret ] ]
		: [ 'body' => [ 'grant_type' => 'client_credentials' ], 'headers' => [ 'Authorization' => 'Basic ' . base64_encode( "$key:$secret" ), 'x-merchant-id' => $s["ups_{$mode}_account"] ] ];
	$res  = wp_remote_post( TFC_CARRIER_HOSTS[ $carrier ][ $mode ] . ( $carrier === 'fedex' ? '/oauth/token' : '/security/v1/oauth/token' ), $args + [ 'timeout' => 10 ] );
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( empty( $data['access_token'] ) ) return new WP_Error( 'carrier', 'Login refused: ' . tfc_carrier_error( $res, $data ) );
	set_transient( $cache, $data['access_token'], max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 120 ) );
	return $data['access_token'];
}

// POST a rate request with the token; an expired token (401) is renewed once.
function tfc_carrier_post( $carrier, $mode, array $body ) {
	$url = TFC_CARRIER_HOSTS[ $carrier ][ $mode ] . ( $carrier === 'fedex' ? '/rate/v1/rates/quotes' : '/api/rating/v2409/Rate' );
	for ( $try = 0; $try < 2; $try++ ) {
		$token = tfc_carrier_token( $carrier, $mode, $try > 0 );
		if ( is_wp_error( $token ) ) return $token;
		$res = wp_remote_post( $url, [
			'timeout' => 10,
			'headers' => [ 'Authorization' => "Bearer $token", 'Content-Type' => 'application/json', 'X-locale' => 'en_US', 'transId' => str_replace( '-', '', wp_generate_uuid4() ), 'transactionSrc' => 'tfc' ],
			'body'    => wp_json_encode( $body ),
		] );
		if ( wp_remote_retrieve_response_code( $res ) !== 401 ) break;
	}
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	return is_array( $data ) ? $data : new WP_Error( 'carrier', tfc_carrier_error( $res, $data ) );
}

// One carrier's price for sending $lbs to $to [ ZIP, state ]: split into boxes, quoted, then handling per
// box and markup added. Quotes are cached for an hour, since checkout asks again on every change.
function tfc_carrier_quote( $carrier, array $to, $lbs ) {
	$s    = tfc_carrier_settings();
	$mode = $s['mode'];
	$from = tfc_carrier_origin();
	if ( ! $from ) return new WP_Error( 'carrier', 'The store address in WooCommerce → Settings → General needs a US ZIP code and state.' );
	$type  = $carrier === 'fedex' ? 'live' : 'dry';
	$boxes = tfc_ship_boxes( $lbs, $s["{$type}_max"] );
	$cache = 'tfc_quote_' . md5( wp_json_encode( [ $carrier, $mode, $s["{$carrier}_{$mode}_account"], $from, $to, $boxes, $s["{$type}_box"] ] ) );
	$price = get_transient( $cache );
	if ( $price === false ) {
		$account = $s["{$carrier}_{$mode}_account"];
		$reply   = tfc_carrier_post( $carrier, $mode, $carrier === 'fedex'
			? tfc_fedex_rate_request( $account, $from, $to, $boxes, $s['live_box'] )
			: tfc_ups_rate_request( $account, $from, $to, $boxes, $s['dry_box'] ) );
		if ( is_wp_error( $reply ) ) return $reply;
		$price = $carrier === 'fedex' ? tfc_fedex_rate_from( $reply ) : tfc_ups_rate_from( $reply );
		if ( $price === null ) return new WP_Error( 'carrier', 'No rate: ' . ( $reply['errors'][0]['message'] ?? $reply['response']['errors'][0]['message'] ?? 'the reply had no price' ) );
		set_transient( $cache, $price, HOUR_IN_SECONDS );
	}
	return round( ( $price + (float) $s['handling'] * count( $boxes ) ) * ( 1 + (float) $s['markup'] / 100 ), 2 );
}

// The carriers' price for a cart ($lines from tfc_sr_lines) going to $to (a WooCommerce destination):
// [ cost, label ], or null when carrier rates are off or the address isn't complete yet. A part a
// carrier can't price uses the Shipping by State table instead; failures go to WooCommerce → Status → Logs.
function tfc_carrier_cost( array $to, array $lines ) {
	$s   = tfc_carrier_settings();
	$zip = substr( preg_replace( '/\D/', '', (string) ( $to['postcode'] ?? '' ) ), 0, 5 );
	if ( empty( $s['enabled'] ) || ( $to['country'] ?? '' ) !== 'US' || strlen( $zip ) !== 5 || empty( $to['state'] ) ) return null;
	$cost  = 0;
	$names = [];
	foreach ( TFC_CARRIER_FOR as $type => [ $carrier, $name ] ) {
		$part = array_filter( $lines, fn( $l ) => $l['live'] === ( $type === 'live' ) );
		if ( ! $part ) continue;
		$quote = tfc_carrier_ready( $carrier ) ? tfc_carrier_quote( $carrier, [ $zip, $to['state'] ], array_sum( array_map( fn( $l ) => $l['lbs'] * $l['qty'], $part ) ) ) : null;
		if ( is_float( $quote ) ) {
			$cost   += $quote;
			$names[] = $name;
			continue;
		}
		if ( is_wp_error( $quote ) ) wc_get_logger()->warning( "$name quote to $zip failed, used the Shipping by State rate: " . $quote->get_error_message(), [ 'source' => 'tfc-carriers' ] );
		$cost   += (float) tfc_sr_cost( tfc_sr_rate( $to['state'] ), $part );
		$names[] = 'Shipping';
	}
	return [ round( $cost, 2 ), implode( ' + ', array_unique( $names ) ) ];
}

// ---- Settings page: WooCommerce → Carrier Rates ---------------------------------

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Carrier Rates', 'Carrier Rates', 'manage_woocommerce', 'tfc-carriers', 'tfc_carrier_page' );
} );

function tfc_carrier_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) return;
	$s     = tfc_carrier_settings();
	$tests = [];
	if ( isset( $_POST['tfc_carriers'] ) ) {
		check_admin_referer( 'tfc_carriers' );
		$in           = (array) wp_unslash( $_POST['tfc_carriers'] );
		$s['enabled'] = ! empty( $in['enabled'] );
		$s['mode']    = ( $in['mode'] ?? '' ) === 'live' ? 'live' : 'test';
		foreach ( [ 'fedex', 'ups' ] as $c ) {
			foreach ( [ 'test', 'live' ] as $m ) {
				foreach ( [ 'key', 'secret', 'account' ] as $f ) {
					$value = trim( sanitize_text_field( $in[ "{$c}_{$m}_{$f}" ] ?? '' ) );
					if ( $f === 'account' || $value !== '' ) $s[ "{$c}_{$m}_{$f}" ] = $value; // key/secret: blank keeps the saved one
				}
			}
		}
		foreach ( [ 'live', 'dry' ] as $t ) {
			$s["{$t}_box"] = array_map( fn( $v ) => min( 108, max( 1, (int) $v ) ), array_pad( (array) ( $in["{$t}_box"] ?? [] ), 3, 1 ) );
			$s["{$t}_max"] = min( 150, max( 1, (float) ( $in["{$t}_max"] ?? 50 ) ) );
		}
		$s['handling'] = max( 0, (float) ( $in['handling'] ?? 0 ) );
		$s['markup']   = max( -50, min( 500, (float) ( $in['markup'] ?? 0 ) ) );
		update_option( 'tfc_carriers', $s, false );
		// Check the credentials in use with a sample quote to New York (10001).
		foreach ( TFC_CARRIER_FOR as $type => [ $carrier, $name ] ) {
			if ( ! tfc_carrier_ready( $carrier ) ) continue;
			$lb      = TFC_DEFAULT_LB[ $type ];
			$q       = tfc_carrier_quote( $carrier, [ '10001', 'NY' ], $lb );
			$tests[] = is_wp_error( $q ) ? [ 'error', "$name: " . $q->get_error_message() ] : [ 'success', sprintf( '%s works: %s lb to New York 10001 would be $%s (with your handling and markup).', $name, $lb, number_format( $q, 2 ) ) ];
		}
	}
	$origin = tfc_carrier_origin();
	$labels = [ 'fedex' => [ 'FedEx', 'API key', 'Secret key', 'Account number' ], 'ups' => [ 'UPS', 'Client ID', 'Client secret', 'Account number (6 characters)' ] ];
	?>
	<div class="wrap">
	<h1>Carrier Rates</h1>
	<?php if ( isset( $_POST['tfc_carriers'] ) ) echo '<div class="notice notice-success"><p>Saved.</p></div>'; ?>
	<?php foreach ( $tests as [ $kind, $msg ] ) printf( '<div class="notice notice-%s"><p>%s</p></div>', esc_attr( $kind ), esc_html( $msg ) ); ?>
	<?php if ( ! $origin ) printf( '<div class="notice notice-warning"><p>Carriers need the ship-from address: add a US address with ZIP code in <a href="%s">WooCommerce → Settings → General</a>.</p></div>', esc_url( admin_url( 'admin.php?page=wc-settings&tab=general' ) ) ); ?>
	<p style="max-width:760px">Checkout quotes <strong>FedEx Priority Overnight</strong> for live goods and <strong>UPS Ground</strong> for dry goods (a mixed cart pays both) to the customer’s address, from your store address<?php echo $origin ? esc_html( sprintf( ' (%s %s)', $origin[1], $origin[0] ) ) : ''; ?>.
	Items without a weight count as <?php echo (int) TFC_DEFAULT_LB['live']; ?> lb (live) or <?php echo (int) TFC_DEFAULT_LB['dry']; ?> lb (dry). If a carrier doesn’t answer, that part uses your <a href="<?php echo esc_url( admin_url( 'admin.php?page=tfc-state-rates' ) ); ?>">Shipping by State</a> rate, which also still decides which states you ship to.</p>
	<form method="post">
		<?php wp_nonce_field( 'tfc_carriers' ); ?>
		<table class="form-table">
			<tr><th>Carrier rates</th><td><label><input type="checkbox" name="tfc_carriers[enabled]" value="1" <?php checked( $s['enabled'] ); ?>> Use live FedEx / UPS rates at checkout</label></td></tr>
			<tr><th>Account to use</th><td><fieldset>
				<label><input type="radio" name="tfc_carriers[mode]" value="test" <?php checked( $s['mode'], 'test' ); ?>> <strong>Test</strong>: the carriers’ sandboxes (test credentials, sample prices)</label><br>
				<label><input type="radio" name="tfc_carriers[mode]" value="live" <?php checked( $s['mode'], 'live' ); ?>> <strong>Live</strong>: your real account rates</label>
			</fieldset></td></tr>
		</table>
		<?php foreach ( $labels as $c => [ $carrier, $key_label, $secret_label, $account_label ] ) : ?>
			<h2><?php echo esc_html( $carrier ); ?></h2>
			<p class="description"><?php echo $c === 'fedex'
				? 'From the FedEx Developer Portal (developer.fedex.com): create a project with the Rates and Transit Times API; it shows test keys, and production keys once your account is linked.'
				: 'From the UPS Developer Portal (developer.ups.com): create an app with the Rating API; its Client ID and Client Secret work in test and live.'; ?></p>
			<table class="form-table">
				<?php foreach ( [ 'test' => 'Test', 'live' => 'Live' ] as $m => $mode_label ) : ?>
					<tr>
						<th><?php echo esc_html( $mode_label ); ?></th>
						<td>
							<?php foreach ( [ 'key' => $key_label, 'secret' => $secret_label ] as $f => $label ) : $name = "{$c}_{$m}_{$f}"; ?>
								<p><label><?php echo esc_html( $label ); ?><br><input type="password" name="tfc_carriers[<?php echo $name; ?>]" class="regular-text code" autocomplete="new-password"></label>
								<span class="description"><?php echo esc_html( tfc_mask_secret( $s[ $name ] ) ); ?>. Leave blank to keep it.</span></p>
							<?php endforeach; ?>
							<p><label><?php echo esc_html( $account_label ); ?><br><input name="tfc_carriers[<?php echo "{$c}_{$m}_account"; ?>]" class="regular-text code" autocomplete="off" value="<?php echo esc_attr( $s[ "{$c}_{$m}_account" ] ); ?>"></label></p>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		<?php endforeach; ?>
		<h2>Boxes and handling</h2>
		<table class="form-table">
			<?php foreach ( [ 'live' => 'Live goods box (FedEx)', 'dry' => 'Dry goods box (UPS)' ] as $t => $label ) : ?>
				<tr><th><?php echo esc_html( $label ); ?></th><td>
					<?php foreach ( [ 0 => 'L', 1 => 'W', 2 => 'H' ] as $i => $dim ) : ?>
						<?php echo $dim; ?> <input type="number" min="1" max="108" step="1" style="width:70px" name="tfc_carriers[<?php echo $t; ?>_box][]" value="<?php echo (int) $s["{$t}_box"][ $i ]; ?>">
					<?php endforeach; ?> in, up to <input type="number" min="1" max="150" step="0.5" style="width:80px" name="tfc_carriers[<?php echo $t; ?>_max]" value="<?php echo esc_attr( $s["{$t}_max"] ); ?>"> lb per box
					<p class="description">Heavier orders are split into more boxes of this size. Carriers price big light boxes by size, so use your real box.</p>
				</td></tr>
			<?php endforeach; ?>
			<tr><th>Handling</th><td>
				$ <input type="number" min="0" step="0.01" style="width:90px" name="tfc_carriers[handling]" value="<?php echo esc_attr( $s['handling'] ); ?>"> per box, then
				<input type="number" min="-50" max="500" step="0.1" style="width:80px" name="tfc_carriers[markup]" value="<?php echo esc_attr( $s['markup'] ); ?>"> % markup
				<p class="description">Added to each carrier quote: for packing materials, heat or cold packs, and your time.</p>
			</td></tr>
		</table>
		<?php submit_button( 'Save and get a test quote' ); ?>
	</form>
	</div>
	<?php
}
