<?php
// Shipping by state: every US state gets its own live-goods and dry-goods rate
// (base charge + per lb). Rates live in one option, edited on WooCommerce > Shipping by State.
defined( 'ABSPATH' ) || exit;

const TFC_SR_FIELDS = [ 'live_base', 'live_lb', 'dry_base', 'dry_lb' ];
// Weight used for a product that has none: live goods ship overnight at 3 lb, dry goods by ground at 10 lb.
const TFC_DEFAULT_LB = [ 'live' => 3, 'dry' => 10 ];

add_action( 'woocommerce_shipping_init', function () {
	class TFC_State_Rates extends WC_Shipping_Method {
		public function __construct( $instance_id = 0 ) {
			$this->id                 = 'tfc_state_rates';
			$this->instance_id        = absint( $instance_id );
			$this->method_title       = 'Shipping by State';
			$this->method_description = 'Live and dry goods rates for each state. Edit them under WooCommerce → Shipping by State.';
			$this->title              = 'Shipping';
			$this->supports           = [ 'shipping-zones' ];
		}

		public function calculate_shipping( $package = [] ) {
			$cost = tfc_sr_quote( $package['destination']['state'] ?? '', $package['contents'] );
			if ( $cost === null ) return; // we do not ship there
			$label = $this->title;
			if ( $carrier = tfc_carrier_cost( $package["destination"], tfc_sr_lines( $package["contents"] ) ) ) [ $cost, $label ] = $carrier;
			$this->add_rate( [ "id" => $this->get_rate_id(), "label" => $label, "cost" => $cost ] );
		}
	}
} );
add_filter( 'woocommerce_shipping_methods', fn( $methods ) => $methods + [ 'tfc_state_rates' => 'TFC_State_Rates' ] );

function tfc_sr_rate( $state ) {
	return get_option( 'tfc_sr_rates', [] )[ $state ] ?? null;
}

// Cart/package contents -> [ live?, lb each, qty ] lines; an item with no weight uses TFC_DEFAULT_LB.
function tfc_sr_lines( array $contents ) {
	$lines = [];
	foreach ( $contents as $item ) {
		$live = tfc_sr_is_live( $item['data'] );
		$lbs  = wc_get_weight( (float) $item['data']->get_weight(), 'lbs' );
		$lines[] = [ 'live' => $live, 'lbs' => $lbs > 0 ? $lbs : TFC_DEFAULT_LB[ $live ? 'live' : 'dry' ], 'qty' => $item['quantity'] ];
	}
	return $lines;
}

// Shipping-by-state cost of the cart for $state, or null if it can't ship there.
function tfc_sr_quote( $state, array $contents ) {
	return tfc_sr_cost( tfc_sr_rate( $state ), tfc_sr_lines( $contents ) );
}

// Live = in the Live Goods category or any category under it (the theme uses the same rule).
function tfc_sr_is_live( WC_Product $product ) {
	$live = get_term_by( 'slug', 'live-goods', 'product_cat' );
	if ( ! $live ) return false;
	foreach ( wc_get_product_term_ids( $product->get_parent_id() ?: $product->get_id(), 'product_cat' ) as $id ) {
		if ( $id === $live->term_id || term_is_ancestor_of( $live, $id, 'product_cat' ) ) return true;
	}
	return false;
}

// Tell the customer why there's no shipping instead of a bare "no shipping options".
add_action( 'woocommerce_check_cart_items', function () {
	$customer = WC()->customer;
	if ( ! $customer || $customer->get_shipping_country() !== 'US' ) return;
	$state = $customer->get_shipping_state();
	$rate  = tfc_sr_rate( $state );
	if ( ! $rate || ! empty( $rate['live'] ) ) return;
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( tfc_sr_is_live( $item['data'] ) ) {
			$name = WC()->countries->get_states( 'US' )[ $state ] ?? $state;
			wc_add_notice( sprintf( 'Sorry, we can’t ship live fish, coral or invertebrates to %s. Remove the live items to check out; dry goods can still ship.', $name ), 'error' );
			return;
		}
	}
} );

// Make sure a United States zone runs this method, creating it on first save.
function tfc_sr_ensure_zone() {
	foreach ( WC_Shipping_Zones::get_zones() as $zone ) {
		foreach ( $zone['shipping_methods'] as $method ) {
			if ( $method->id === 'tfc_state_rates' ) return;
		}
	}
	$zone = new WC_Shipping_Zone();
	$zone->set_zone_name( 'United States' );
	$zone->add_location( 'US', 'country' );
	$zone->save();
	$zone->add_shipping_method( 'tfc_state_rates' );
}

// Other zones covering US addresses win if they're listed first, which would bypass these rates.
function tfc_sr_conflicting_zones() {
	$names = [];
	foreach ( WC_Shipping_Zones::get_zones() as $zone ) {
		if ( in_array( 'tfc_state_rates', wp_list_pluck( $zone['shipping_methods'], 'id' ), true ) ) break; // zones after ours don't matter
		foreach ( $zone['zone_locations'] as $loc ) {
			if ( $loc->code === 'US' || strpos( $loc->code, 'US:' ) === 0 ) {
				$names[] = $zone['zone_name'];
				break;
			}
		}
	}
	return $names;
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Shipping by State', 'Shipping by State', 'manage_woocommerce', 'tfc-state-rates', 'tfc_sr_page' );
} );

function tfc_sr_page() {
	$states = WC()->countries->get_states( 'US' );
	if ( isset( $_POST['tfc_sr'] ) ) {
		check_admin_referer( 'tfc_sr' );
		$rates = [];
		foreach ( (array) wp_unslash( $_POST['tfc_sr'] ) as $code => $r ) {
			if ( ! isset( $states[ $code ] ) ) continue;
			$row = [];
			foreach ( TFC_SR_FIELDS as $f ) $row[ $f ] = is_numeric( $r[ $f ] ?? '' ) ? max( 0, (float) $r[ $f ] ) : '';
			if ( implode( '', $row ) === '' ) continue; // a blank row means we don't ship there
			$row['live']    = ! empty( $r['live'] );
			$rates[ $code ] = $row;
		}
		update_option( 'tfc_sr_rates', $rates, false );
		tfc_sr_ensure_zone();
		echo '<div class="notice notice-success"><p>Shipping rates saved.</p></div>';
	}
	$rates     = get_option( 'tfc_sr_rates', [] );
	$conflicts = tfc_sr_conflicting_zones();
	?>
	<div class="wrap">
	<h1>Shipping by State</h1>
	<?php if ( $conflicts ) : ?>
		<div class="notice notice-warning"><p>These shipping zones also cover US addresses and come first, so they’ll be used instead of the rates below:
		<strong><?php echo esc_html( implode( ', ', $conflicts ) ); ?></strong>.
		Delete them or drag “United States” above them in <a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ); ?>">WooCommerce → Settings → Shipping</a>.</p></div>
	<?php endif; ?>
	<p>Each order pays the base charge plus the per-lb rate on the total weight of its items, separately for live and dry goods, so an order with both pays both.
	Leave a state blank to not ship there at all. Untick <em>Ship live</em> for states that can only get dry goods.</p>
	<form method="post">
		<?php wp_nonce_field( 'tfc_sr' ); ?>
		<style>#tfc-sr thead th { position: sticky; top: 32px; background: #fff; z-index: 1; box-shadow: 0 1px 0 #c3c4c7; }</style>
		<table class="widefat striped" id="tfc-sr" style="max-width:820px">
			<thead>
				<tr><th>State</th><th>Ship live</th><th>Live base $</th><th>Live $ per lb</th><th>Dry base $</th><th>Dry $ per lb</th></tr>
			</thead>
			<tbody>
			<?php foreach ( $states as $code => $name ) : $r = $rates[ $code ] ?? null; ?>
				<tr>
					<th><?php echo esc_html( $name ); ?></th>
					<td><input type="checkbox" name="tfc_sr[<?php echo esc_attr( $code ); ?>][live]" value="1" <?php checked( $r ? $r['live'] : true ); ?>></td>
					<?php foreach ( TFC_SR_FIELDS as $f ) : ?>
						<td><input type="number" step="0.01" min="0" style="width:90px" name="tfc_sr[<?php echo esc_attr( $code ); ?>][<?php echo $f; ?>]" value="<?php echo esc_attr( $r[ $f ] ?? '' ); ?>"></td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php submit_button( 'Save rates' ); ?>
	</form>
	</div>
	<?php
}
