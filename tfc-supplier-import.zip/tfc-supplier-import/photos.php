<?php
// Find Missing Photos: for products without a photo, search a supplier's website by product name
// and attach the photo of an unmistakable match. Plus a "Missing photo" filter on Products.
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Find Missing Photos', 'Find Missing Photos', 'manage_woocommerce', 'tfc-find-photos', 'tfc_fp_page' );
} );

// Products → "Missing photo" filter (dropdown + ?tfc_no_photo=1).
add_action( 'restrict_manage_posts', function ( $type ) {
	if ( $type !== 'product' ) return;
	printf( '<select name="tfc_no_photo"><option value="">All photos</option><option value="1"%s>Missing photo</option></select>', selected( $_GET['tfc_no_photo'] ?? '', '1', false ) );
} );
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && ( $_GET['tfc_no_photo'] ?? '' ) === '1' && $q->get( 'post_type' ) === 'product' ) {
		$q->set( 'meta_query', [ [ 'key' => '_thumbnail_id', 'compare' => 'NOT EXISTS' ] ] );
	}
} );

// Supplier lists / sites products were imported from (e.g. "aquaqSD.csv", "aquasd.com").
function tfc_fp_sources() {
	global $wpdb;
	return $wpdb->get_col( "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_tfc_si_source' AND meta_value <> '' ORDER BY meta_value" );
}

function tfc_fp_missing( $limit, $skip_tried_for = '', $source = '' ) {
	$meta = [ [ 'key' => '_thumbnail_id', 'compare' => 'NOT EXISTS' ] ];
	if ( $source !== '' ) $meta[] = [ 'key' => '_tfc_si_source', 'value' => $source ];
	// Don't retry products already searched on this website, so each run moves through the list.
	if ( $skip_tried_for ) $meta[] = [ 'key' => '_tfc_fp_tried', 'value' => md5( $skip_tried_for ), 'compare' => 'NOT EXISTS' ];
	return get_posts( [ 'post_type' => 'product', 'post_status' => 'any', 'numberposts' => $limit, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'meta_query' => $meta ] );
}

function tfc_fp_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) return;
	$site     = get_option( 'tfc_fp_search', '' ); // the supplier's website, or a search address with {q}
	$source   = (string) get_option( 'tfc_fp_source', '' );
	$sources  = tfc_fp_sources();
	$results  = [];
	$batch    = 20;
	$template = '';   // the search address actually used this run
	$notice   = '';
	$login    = null; // [ login page, error ] when the site needs a login
	if ( isset( $_POST['tfc_fp'] ) ) {
		check_admin_referer( 'tfc_fp' );
		// esc_url_raw() strips { }, so protect the {q} placeholder while cleaning the address.
		$site   = trim( wp_unslash( $_POST['search'] ?? '' ) );
		if ( $site !== '' && ! preg_match( '#^https?://#i', $site ) ) $site = 'https://' . $site; // a bare domain is fine
		$site   = str_replace( [ '{q}', '%7Bq%7D' ], 'TFCQUERY', $site );
		$site   = str_replace( 'TFCQUERY', '{q}', esc_url_raw( $site ) );
		$batch  = min( 50, max( 1, (int) ( $_POST['batch'] ?? 20 ) ) );
		$source = in_array( wp_unslash( $_POST['source'] ?? '' ), $sources, true ) ? wp_unslash( $_POST['source'] ) : '';
		update_option( 'tfc_fp_search', $site, false );
		update_option( 'tfc_fp_source', $source, false );
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		wc_set_time_limit( 0 );
		$login_error = tfc_si_login_posted( $site );
		$search      = $login_error ? new WP_Error( 'login', '', '' ) : tfc_fp_search_for( $site );
		$login_page  = null;
		if ( is_wp_error( $search ) && $search->get_error_code() === 'login' ) {
			$login_page = $search->get_error_data();
		} elseif ( is_wp_error( $search ) ) {
			$notice = $search->get_error_message();
		} else {
			$template = $search;
			foreach ( tfc_fp_missing( $batch, $template, $source ) as $id ) {
				$r = tfc_fp_find( $id, $template );
				if ( is_wp_error( $r ) ) {
					$login_page = $r->get_error_data();
					break;
				}
				$results[] = $r;
			}
		}
		if ( $login_error || $login_page !== null ) $login = [ (string) $login_page, $login_error ];
	}
	$left = count( tfc_fp_missing( -1 ) );
	?>
	<div class="wrap">
	<h1>Find Missing Photos</h1>
	<?php if ( $login ) echo '<div class="notice notice-warning"><p>The supplier’s site needs a login.</p></div>'; ?>
	<?php if ( $notice ) printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( $notice ) ); ?>
	<p><?php printf( '<strong>%d</strong> products have no photo. <a href="%s">See them</a>.', $left, esc_url( admin_url( 'edit.php?post_type=product&tfc_no_photo=1' ) ) ); ?></p>
	<form method="post" id="tfc-fp-form">
		<?php wp_nonce_field( 'tfc_fp' ); ?>
		<table class="form-table">
			<tr>
				<th><label for="tfc-fp-search">Supplier website</label></th>
				<td>
					<input id="tfc-fp-search" type="text" inputmode="url" name="search" class="large-text" required placeholder="aquasd.com" value="<?php echo esc_attr( $site ); ?>">
					<p class="description">The supplier’s website address. The plugin finds the site’s product search by itself and looks up each product there.<br>
					A photo is only used when a result’s title contains every word of the product’s name (the scientific name and size are ignored), so it won’t attach the wrong fish.<br>
					To use a particular search page instead, paste its address with <code>{q}</code> in place of the search words.</p>
				</td>
			</tr>
			<tr>
				<th><label for="tfc-fp-source">Only products from</label></th>
				<td>
					<select id="tfc-fp-source" name="source">
						<option value="">All suppliers</option>
						<?php foreach ( $sources as $s ) printf( '<option value="%s"%s>%s (%d without a photo)</option>', esc_attr( $s ), selected( $source, $s, false ), esc_html( $s ), count( tfc_fp_missing( -1, '', $s ) ) ); ?>
					</select>
					<p class="description">Pick the supplier whose website you’re searching, so their products are matched against their own photos.</p>
				</td>
			</tr>
			<tr>
				<th><label for="tfc-fp-batch">Products per run</label></th>
				<td><input id="tfc-fp-batch" type="number" name="batch" min="1" max="50" value="<?php echo (int) $batch; ?>" style="width:80px"> <span class="description">Each run continues with products not yet searched on this site.</span></td>
			</tr>
		</table>
		<p>
			<button class="button button-primary" name="tfc_fp" value="1">Find photos</button>
			<button type="button" class="button" data-tfc-login>Log in to the site</button>
		</p>
	</form>
	<?php tfc_si_login_dialog( 'tfc-fp-form', [ 'tfc_fp', '1' ], $login[0] ?? '', $login[1] ?? '', (bool) $login ); ?>
	<?php if ( $results ) : ?>
		<h2>This run</h2>
		<table class="widefat striped" style="max-width:900px">
			<thead><tr><th style="width:70px"></th><th>Product</th><th>Result</th></tr></thead>
			<tbody>
			<?php foreach ( $results as [ $id, $status, $img ] ) : ?>
				<tr>
					<td><?php echo $img ? wp_get_attachment_image( $img, [ 56, 56 ] ) : ''; ?></td>
					<td><a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>"><?php echo esc_html( get_the_title( $id ) ); ?></a></td>
					<td><?php echo esc_html( $status ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p><?php printf( 'Found %d of %d. Run again to continue with the next products.', count( array_filter( array_column( $results, 2 ) ) ), count( $results ) ); ?></p>
	<?php endif; ?>
	<?php if ( $template ) printf( '<p class="description">Searched with <code>%s</code></p>', esc_html( $template ) ); ?>
	</div>
	<?php
}

// How to search a supplier's site: an address with {q} where the product name goes. Given any page
// of the site, it tries the shop's JSON product search first (Shopify, WooCommerce: every result
// comes with its title and photo), then the search box on that page or the home page. An address
// that already has {q} is used as is. Remembered for a week per address; a WP_Error when nothing
// was found (its data is the login page when the site needs a login first).
function tfc_fp_search_for( $site ) {
	if ( strpos( $site, '{q}' ) !== false ) return $site;
	$key = 'tfc_fp_search_' . md5( $site );
	if ( $found = get_transient( $key ) ) return $found;
	$root = preg_replace( '~^(https?://[^/?#]+).*~', '$1', $site );
	$found = '';
	foreach ( [ "$root/search/suggest.json?q={q}&resources%5Btype%5D=product&resources%5Blimit%5D=10", "$root/wp-json/wc/store/v1/products?search={q}&per_page=20" ] as $api ) {
		$res = tfc_si_remote_get( str_replace( '{q}', 'fish', $api ) );
		if ( wp_remote_retrieve_response_code( $res ) === 200 && tfc_si_results_html( wp_remote_retrieve_body( $res ) ) !== null ) {
			$found = $api;
			break;
		}
	}
	foreach ( $found ? [] : array_unique( [ $site, "$root/" ] ) as $page ) {
		$res  = tfc_si_remote_get( $page );
		$form = tfc_si_search_form( wp_remote_retrieve_body( $res ) );
		if ( ! $form ) {
			if ( $login = tfc_si_login_url( $res, $page, true ) ) return new WP_Error( 'login', 'That site needs a login.', $login );
			continue;
		}
		[ $action, $hidden, $box ] = $form;
		$url   = tfc_si_final_url( $res, $page );
		$url   = WP_Http::make_absolute_url( $action !== '' ? $action : $url, $url );
		$query = ltrim( http_build_query( $hidden ) . '&' . rawurlencode( $box ) . '={q}', '&' );
		$found = $url . ( strpos( $url, '?' ) === false ? '?' : '&' ) . $query;
		break;
	}
	if ( ! $found ) return new WP_Error( 'no_search', 'Couldn’t find a search box on that site. Search the supplier’s site for any product in your browser, copy the address of the results page, and paste it here with {q} in place of the search words.' );
	set_transient( $key, $found, WEEK_IN_SECONDS );
	return $found;
}

// One product: search, match, attach. Returns [ id, status text, attachment id or 0 ],
// or a WP_Error carrying the login page when the search needs a login (the product is left untried).
function tfc_fp_find( $id, $template ) {
	update_post_meta( $id, '_tfc_fp_tried', md5( $template ) );
	$name  = get_post_field( 'post_title', $id, 'raw' ); // not get_the_title(): that turns " - " into "&#8211;"
	$query = tfc_si_search_query( $name );
	if ( $query === '' ) return [ $id, 'Name too short to search', 0 ];
	$url = str_replace( [ '{q}', '%7Bq%7D' ], rawurlencode( $query ), $template );
	$res = tfc_si_remote_get( $url );
	if ( $login = tfc_si_login_url( $res, $url ) ) {
		delete_post_meta( $id, '_tfc_fp_tried' );
		return new WP_Error( 'login', '', $login );
	}
	if ( is_wp_error( $res ) || wp_remote_retrieve_response_code( $res ) !== 200 ) return [ $id, 'Search page could not be loaded', 0 ];
	$body = wp_remote_retrieve_body( $res );
	$src  = tfc_si_match_image( tfc_si_results_html( $body ) ?? $body, $name, $url );
	if ( ! $src ) return [ $id, 'No confident match on the supplier’s site', 0 ];
	$img = tfc_si_sideload( $src, $id, $name );
	if ( is_wp_error( $img ) ) return [ $id, 'Match found, but the photo would not download', 0 ];
	set_post_thumbnail( $id, $img );
	wc_delete_product_transients( $id );
	return [ $id, 'Photo added', $img ];
}
