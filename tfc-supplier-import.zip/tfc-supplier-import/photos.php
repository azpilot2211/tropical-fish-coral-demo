<?php
// Find Missing Photos: for products without a photo, search a supplier's website by product name
// and attach the photo of an unmistakable match. Plus a "Missing photo" filter on Products.
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Find Missing Photos', 'Find Missing Photos', 'manage_woocommerce', 'tfc-find-photos', 'tfc_fp_page' );
} );

// Products → "Missing photo" filter (dropdown + ?tfc_no_photo=1).
add_action( 'restrict_manage_posts', function ( $type ) {
	if ( $type !== 'product' ) return;
	printf( '<select name="tfc_no_photo"><option value="">All photos</option><option value="1"%s>Missing photo</option></select>', selected( $_GET['tfc_no_photo'] ?? '', '1', false ) );
} );
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && ( $_GET['tfc_no_photo'] ?? '' ) === '1' && $q->get( 'post_type' ) === 'product' ) {
		$q->set( 'meta_query', [ [ 'key' => '_thumbnail_id', 'compare' => 'NOT EXISTS' ] ] );
	}
} );

// Supplier lists / sites products were imported from (e.g. "aquaqSD.csv", "aquasd.com").
function tfc_fp_sources() {
	global $wpdb;
	return $wpdb->get_col( "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_tfc_si_source' AND meta_value <> '' ORDER BY meta_value" );
}

function tfc_fp_missing( $limit, $skip_tried_for = '', $source = '' ) {
	$meta = [ [ 'key' => '_thumbnail_id', 'compare' => 'NOT EXISTS' ] ];
	if ( $source !== '' ) $meta[] = [ 'key' => '_tfc_si_source', 'value' => $source ];
	// Don't retry products already searched on this website, so each run moves through the list.
	if ( $skip_tried_for ) $meta[] = [ 'key' => '_tfc_fp_tried', 'value' => md5( $skip_tried_for ), 'compare' => 'NOT EXISTS' ];
	return get_posts( [ 'post_type' => 'product', 'post_status' => 'any', 'numberposts' => $limit, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'meta_query' => $meta ] );
}

function tfc_fp_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) return;
	$template = get_option( 'tfc_fp_search', '' );
	$source   = (string) get_option( 'tfc_fp_source', '' );
	$sources  = tfc_fp_sources();
	$results  = [];
	if ( isset( $_POST['tfc_fp'] ) ) {
		check_admin_referer( 'tfc_fp' );
		// esc_url_raw() strips { }, so protect the {q} placeholder while cleaning the address.
		$template = str_replace( [ '{q}', '%7Bq%7D' ], 'TFCQUERY', trim( wp_unslash( $_POST['search'] ?? '' ) ) );
		$template = str_replace( 'TFCQUERY', '{q}', esc_url_raw( $template ) );
		$batch    = min( 50, max( 1, (int) ( $_POST['batch'] ?? 20 ) ) );
		$source   = in_array( wp_unslash( $_POST['source'] ?? '' ), $sources, true ) ? wp_unslash( $_POST['source'] ) : '';
		update_option( 'tfc_fp_search', $template, false );
		update_option( 'tfc_fp_source', $source, false );
		if ( strpos( $template, '{q}' ) === false && strpos( $template, '%7Bq%7D' ) === false ) {
			echo '<div class="notice notice-error"><p>The search address needs <code>{q}</code> where the product name goes.</p></div>';
		} else {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			wc_set_time_limit( 0 );
			foreach ( tfc_fp_missing( $batch, $template, $source ) as $id ) {
				$results[] = tfc_fp_find( $id, $template );
			}
		}
	}
	$left = count( tfc_fp_missing( -1 ) );
	?>
	<div class="wrap">
	<h1>Find Missing Photos</h1>
	<p><?php printf( '<strong>%d</strong> products have no photo. <a href="%s">See them</a>.', $left, esc_url( admin_url( 'edit.php?post_type=product&tfc_no_photo=1' ) ) ); ?></p>
	<form method="post">
		<?php wp_nonce_field( 'tfc_fp' ); ?>
		<table class="form-table">
			<tr>
				<th><label for="tfc-fp-search">Supplier search address</label></th>
				<td>
					<input id="tfc-fp-search" type="url" name="search" class="large-text" required placeholder="https://aquasd.com/search.php?search_query={q}" value="<?php echo esc_attr( $template ); ?>">
					<p class="description">Search the supplier’s site for any product, copy the address from the results page, and replace the search words with <code>{q}</code>.<br>
					A photo is only used when a result’s title contains every word of the product’s name (the scientific name and size are ignored), so it won’t attach the wrong fish.</p>
				</td>
			</tr>
			<tr>
				<th><label for="tfc-fp-source">Only products from</label></th>
				<td>
					<select id="tfc-fp-source" name="source">
						<option value="">All suppliers</option>
						<?php foreach ( $sources as $s ) printf( '<option value="%s"%s>%s (%d without a photo)</option>', esc_attr( $s ), selected( $source, $s, false ), esc_html( $s ), count( tfc_fp_missing( -1, '', $s ) ) ); ?>
					</select>
					<p class="description">Pick the supplier whose website you’re searching, so their products are matched against their own photos.</p>
				</td>
			</tr>
			<tr>
				<th><label for="tfc-fp-batch">Products per run</label></th>
				<td><input id="tfc-fp-batch" type="number" name="batch" min="1" max="50" value="20" style="width:80px"> <span class="description">Each run continues with products not yet searched on this site.</span></td>
			</tr>
		</table>
		<p><button class="button button-primary" name="tfc_fp" value="1">Find photos</button></p>
	</form>
	<?php if ( $results ) : ?>
		<h2>This run</h2>
		<table class="widefat striped" style="max-width:900px">
			<thead><tr><th style="width:70px"></th><th>Product</th><th>Result</th></tr></thead>
			<tbody>
			<?php foreach ( $results as [ $id, $status, $img ] ) : ?>
				<tr>
					<td><?php echo $img ? wp_get_attachment_image( $img, [ 56, 56 ] ) : ''; ?></td>
					<td><a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>"><?php echo esc_html( get_the_title( $id ) ); ?></a></td>
					<td><?php echo esc_html( $status ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p><?php printf( 'Found %d of %d. Run again to continue with the next products.', count( array_filter( array_column( $results, 2 ) ) ), count( $results ) ); ?></p>
	<?php endif; ?>
	</div>
	<?php
}

// One product: search, match, attach. Returns [ id, status text, attachment id or 0 ].
function tfc_fp_find( $id, $template ) {
	update_post_meta( $id, '_tfc_fp_tried', md5( $template ) );
	$name  = get_post_field( 'post_title', $id, 'raw' ); // not get_the_title(): that turns " - " into "&#8211;"
	$query = tfc_si_search_query( $name );
	if ( $query === '' ) return [ $id, 'Name too short to search', 0 ];
	$url = str_replace( [ '{q}', '%7Bq%7D' ], rawurlencode( $query ), $template );
	$res = wp_safe_remote_get( $url, [ 'timeout' => 20 ] );
	if ( is_wp_error( $res ) || wp_remote_retrieve_response_code( $res ) !== 200 ) return [ $id, 'Search page could not be loaded', 0 ];
	$src = tfc_si_match_image( wp_remote_retrieve_body( $res ), $name, $url );
	if ( ! $src ) return [ $id, 'No confident match on the supplier’s site', 0 ];
	$img = tfc_si_sideload( $src, $id, $name );
	if ( is_wp_error( $img ) ) return [ $id, 'Match found, but the photo would not download', 0 ];
	set_post_thumbnail( $id, $img );
	wc_delete_product_transients( $id );
	return [ $id, 'Photo added', $img ];
}
