<?php
// Scanning a whole site for products, in batches. A site with no product feed (PrestaShop, BigCommerce…) has to be
// explored page by page: Aqua SD is 36+ pages of about 1 MB, which takes minutes and would hit the host's gateway
// timeout in one request. So "Fetch items" starts a scan, and the page then asks for one batch at a time (about
// 10 s each) with a progress bar. Also here: the message shown when a supplier's firewall refuses this server, and a
// script the owner can run in their own browser (which the supplier lets in) to collect the products instead.
defined( 'ABSPATH' ) || exit;

const TFC_SI_SCAN_SECONDS   = 10;
const TFC_SI_SCAN_MAX_PAGES = 250;

function tfc_si_scan_key() {
	return 'tfc_si_scan_' . get_current_user_id();
}

function tfc_si_scan_clear() {
	delete_option( tfc_si_scan_key() );
	delete_option( tfc_si_scan_key() . '_rows' );
}

// [ HTTP status, body ] of a page, fetched as the logged-in user of that site (0 when it couldn't be reached).
function tfc_si_scan_get( $url ) {
	$res = tfc_si_remote_get( $url );
	return is_wp_error( $res ) ? [ 0, '' ] : [ wp_remote_retrieve_response_code( $res ), wp_remote_retrieve_body( $res ) ];
}

// What to tell the owner when the supplier's firewall answers this server with a 403 / 503.
function tfc_si_blocked_message( $body = '' ) {
	$ray = preg_match( '/Ray ID:?\s*(?:<[^>]*>\s*)*([0-9a-f]{12,})/i', (string) $body, $m ) ? ' (Cloudflare Ray ID ' . $m[1] . ')' : '';
	return 'The supplier’s firewall refused this server' . $ray . '. It lets ordinary browsers in but blocks web-hosting addresses, so nothing this plugin does from your store’s server can get past it. Either ask the supplier to allow your server’s address, or use “Collect in your browser” (just below the Fetch box): it runs in your own browser, which the supplier does let in, and saves a spreadsheet you upload here.';
}

// Store fetched rows as the list to import from, and say what happened. Returns [ message [kind, html], login box [page, error] or null ].
function tfc_si_store_fetched( array $rows, $url, $found_at = '', $after_login = false ) {
	if ( ! $rows ) return [ [ 'warning', 'No product data found at that URL. The site may need a login (use “Log in to the site”), or uses a layout this plugin can’t read yet.' ], null ];
	$priced = tfc_si_priced( $rows );
	if ( ! $priced ) {
		// Products but no prices: wholesale shops show prices only to logged-in customers, so ask for the login now.
		return [ [ 'warning', sprintf( 'Found %d items%s, but none show a price. This supplier probably shows prices only after you log in: use the login box.', count( $rows ), $found_at ? ' (starting from ' . esc_html( $found_at ) . ')' : '' ) ], [ $url, '' ] ];
	}
	$host = (string) wp_parse_url( $url, PHP_URL_HOST );
	foreach ( $priced as $i => $r ) $priced[ $i ]['source'] = $host;
	set_transient( 'tfc_si_rows_' . get_current_user_id(), $priced, DAY_IN_SECONDS );
	$skipped = count( $rows ) - count( $priced );
	return [ [ 'success', sprintf( 'Found %d items.', count( $priced ) )
		. ( $found_at && $found_at !== $url ? ' Products found by exploring the site, starting from ' . esc_html( $found_at ) . '.' : '' )
		. ( $skipped ? sprintf( ' Left out %d without a price.', $skipped ) : '' )
		. ( $skipped && ! $after_login ? ' If the supplier shows more prices to logged-in customers, click “Log in to the site”.' : '' ) ], null ];
}

// Start: read the page given. With products on it (a category address) the scan follows that listing's pages; from a
// home page it goes through the site's category links.
add_action( 'wp_ajax_tfc_si_scan_start', function () {
	tfc_si_ajax_guard();
	$url = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
	[ $code, $body ] = tfc_si_scan_get( $url );
	if ( $code === 403 || $code === 503 ) wp_send_json_error( tfc_si_blocked_message( $body ) );
	if ( $code !== 200 ) wp_send_json_error( $code ? "The site returned an error (HTTP $code). Check the address." : 'Couldn’t reach the site.' );
	$cards   = tfc_si_from_cards( $body, $url );
	$explore = ! $cards || trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' ) === '';
	$rows    = [];
	foreach ( $cards as $r ) $rows[ $r['id'] ] = $r;
	$queue = [];
	if ( $explore ) $queue = tfc_si_scan_candidates( tfc_si_page_links( $body, $url ), $url, array_column( $cards, 'url' ) );
	elseif ( $next = tfc_si_next_page( $body, $url ) ) $queue[] = 'p|' . $next;
	if ( ! $rows && ! $queue ) wp_send_json_error( 'No product data found at that address, and no category pages to look through. The site may need a login (use “Log in to the site”), or uses a layout this plugin can’t read yet.' );
	$state = [
		'start' => $url, 'queue' => $queue, 'seen' => [ $url => true ], 'pages' => 1, 'blocked' => 0, 'explore' => $explore,
		'found_at' => $explore ? '' : $url, 'listings' => $explore ? 0 : 1, 'peek' => [], 'peek_state' => $explore ? 0 : 2, 'peek_hit' => false,
		'after_login' => ! empty( $_POST['after_login'] ),
	];
	update_option( tfc_si_scan_key(), $state, false );
	update_option( tfc_si_scan_key() . '_rows', $rows, false );
	wp_send_json_success( [ 'done' => false, 'pages' => 1, 'found' => count( $rows ), 'left' => count( $queue ) ] );
} );

// Work through the queue until $limit (a microtime). Returns true when there is nothing left to check.
function tfc_si_scan_run( array &$st, array &$rows, $limit ) {
	while ( microtime( true ) < $limit ) {
		if ( $st['peek'] ) { // sampling a few pages spread through the list, to see if the first listing already covered the site
			$peek = array_shift( $st['peek'] );
			[ $code, $body ] = tfc_si_scan_get( $peek );
			$st['pages']++;
			if ( $code === 200 ) foreach ( tfc_si_from_cards( $body, $peek ) as $r ) if ( ! isset( $rows[ $r['id'] ] ) ) { $st['peek_hit'] = true; break; }
			continue;
		}
		if ( $st['peek_state'] === 1 ) { // sampling finished: nothing new anywhere means the first listing had everything
			$st['peek_state'] = 2;
			if ( ! $st['peek_hit'] ) $st['queue'] = [];
		}
		if ( ! $st['queue'] || $st['pages'] >= TFC_SI_SCAN_MAX_PAGES ) return true;
		$entry = array_shift( $st['queue'] );
		$is_pg = strpos( $entry, 'p|' ) === 0;
		$url   = $is_pg ? substr( $entry, 2 ) : $entry;
		if ( $st['explore'] && $st['peek_state'] === 0 && $st['listings'] >= 1 && ! $is_pg ) { // the first listing is done: sample before going on
			array_unshift( $st['queue'], $entry );
			$st['peek']       = tfc_si_spread( array_filter( $st['queue'], fn( $q ) => strpos( $q, 'p|' ) !== 0 ), 4 );
			$st['peek_state'] = 1;
			$st['peek_hit']   = false;
			continue;
		}
		if ( isset( $st['seen'][ $url ] ) ) continue;
		$st['seen'][ $url ] = true;
		[ $code, $body ] = tfc_si_scan_get( $url );
		$st['pages']++;
		if ( $code === 403 || $code === 503 ) { $st['blocked']++; $st['blocked_body'] = $body; continue; }
		if ( $code !== 200 ) continue;
		$cards = tfc_si_from_cards( $body, $url );
		$new   = 0;
		foreach ( $cards as $r ) if ( ! isset( $rows[ $r['id'] ] ) ) { $rows[ $r['id'] ] = $r; $new++; }
		if ( $cards && ! $is_pg ) $st['listings']++;
		if ( $cards && $st['found_at'] === '' ) $st['found_at'] = $url;
		// A listing that added products continues onto its next pages; one that added nothing was already covered.
		if ( $cards && ( $new > 0 || $is_pg ) && ( $next = tfc_si_next_page( $body, $url ) ) && ! isset( $st['seen'][ $next ] ) ) array_unshift( $st['queue'], 'p|' . $next );
	}
	return false;
}

// One batch. finish=1 stops and uses what has been found so far.
add_action( 'wp_ajax_tfc_si_scan_step', function () {
	tfc_si_ajax_guard();
	$st   = get_option( tfc_si_scan_key() );
	$rows = get_option( tfc_si_scan_key() . '_rows' );
	if ( ! is_array( $st ) || ! is_array( $rows ) ) wp_send_json_error( 'There is no scan in progress.' );
	tfc_si_import_env();
	$done = ! empty( $_POST['finish'] ) || tfc_si_scan_run( $st, $rows, microtime( true ) + TFC_SI_SCAN_SECONDS );
	if ( $st['blocked'] >= 3 && ! $rows ) {
		tfc_si_scan_clear();
		wp_send_json_error( tfc_si_blocked_message( $st['blocked_body'] ?? '' ) );
	}
	if ( ! $done ) {
		update_option( tfc_si_scan_key(), $st, false );
		update_option( tfc_si_scan_key() . '_rows', $rows, false );
		wp_send_json_success( [ 'done' => false, 'pages' => $st['pages'], 'found' => count( $rows ), 'left' => count( $st['queue'] ) + count( $st['peek'] ) ] );
	}
	$result = tfc_si_store_fetched( array_values( $rows ), $st['start'], $st['found_at'], $st['after_login'] );
	set_transient( 'tfc_si_scan_result_' . get_current_user_id(), $result, 600 );
	tfc_si_scan_clear();
	wp_send_json_success( [ 'done' => true ] );
} );

// The script that drives the scan from the page (uses the progress box from import-job.php). $tfc_si_scan (set by the Fetch
// handler when the page has no product feed) starts it as soon as the page has loaded.
function tfc_si_scan_ui() {
	global $tfc_si_scan;
	?>
	<script>
	window.tfcScan = async (url, afterLogin) => {
		const u = window.tfcUi;
		u.buttons(false);
		u.box.hidden = false; u.stopBtn.hidden = false; u.stopBtn.disabled = false; u.goBtn.hidden = u.discardBtn.hidden = true;
		let finishNow = false;
		u.stopBtn.onclick = () => { finishNow = true; u.stopBtn.disabled = true; u.text.textContent = 'Wrapping up…'; };
		u.text.textContent = 'Looking around the site for products…'; u.bar.removeAttribute('value');
		try {
			let r = await u.post({ action: 'tfc_si_scan_start', url, after_login: afterLogin ? 1 : 0 });
			while (r.success && !r.data.done) {
				u.text.textContent = 'Scanning the site… ' + u.n(r.data.pages) + ' pages read, ' + u.n(r.data.found) + ' products found' + (r.data.left ? ' (' + u.n(r.data.left) + ' pages still to check)' : '');
				u.bar.max = r.data.pages + r.data.left; u.bar.value = r.data.pages;
				r = await u.post(finishNow ? { action: 'tfc_si_scan_step', finish: 1 } : { action: 'tfc_si_scan_step' });
			}
			if (!r.success) { u.box.hidden = true; u.buttons(true); u.notice('error', r.data); return; }
			location.href = location.pathname + '?page=tfc-supplier-import&scanned=1';
		} catch (e) {
			u.box.hidden = true; u.buttons(true);
			u.notice('error', 'Lost contact with the server while scanning.' + u.refusal(e));
		}
	};
	<?php if ( $tfc_si_scan ) : ?>
	document.addEventListener('DOMContentLoaded', () => tfcScan(<?php echo wp_json_encode( $tfc_si_scan['url'] ); ?>, <?php echo $tfc_si_scan['after_login'] ? 'true' : 'false'; ?>));
	<?php endif; ?>
	</script>
	<?php
}

// ---- Collect in your own browser -----------------------------------------------------------------

// For a supplier whose firewall blocks your store's server but lets you in. The owner runs this in the browser console on
// the supplier's site (logged in if it needs it); it goes through the site's category pages, reads the product cards
// (BigCommerce, PrestaShop, WooCommerce) and downloads a spreadsheet that "From a spreadsheet" reads.
function tfc_si_collector_script() {
	return <<<'JS'
(async () => {
  const origin = location.origin, wait = ms => new Promise(r => setTimeout(r, ms)), rows = new Map();
  const box = document.createElement('div');
  box.style.cssText = 'position:fixed;z-index:2147483647;top:10px;right:10px;background:#111;color:#fff;padding:12px 16px;font:14px/1.4 sans-serif;border-radius:8px;max-width:380px;box-shadow:0 4px 20px #0008';
  document.body.append(box);
  const say = t => { box.textContent = t; };
  const num = s => { const m = String(s || '').replace(/,/g, '').match(/\d+(?:\.\d+)?/); return m ? m[0] : ''; };
  const abs = (h, base) => { try { return new URL(h, base).href; } catch (e) { return ''; } };
  const best = img => { // the largest picture in a srcset, else the plain src
    if (!img) return '';
    const set = (img.getAttribute('data-srcset') || img.getAttribute('srcset') || '').split(',').map(s => s.trim().split(/\s+/)).filter(p => p[0]).sort((a, b) => parseInt(b[1]) - parseInt(a[1]))[0];
    return set ? set[0] : (img.getAttribute('data-full-size-image-url') || img.getAttribute('data-src') || img.getAttribute('src') || '');
  };
  const add = (id, o, base) => { if (id && o.name && !rows.has(id)) { rows.set(id, { ...o, img: abs(o.img, base), url: abs(o.url, base).replace(/[?&](searchid|search_query)=[^&]*/g, '') }); return 1; } return 0; };
  const cards = (doc, base) => {
    let n = 0;
    doc.querySelectorAll('article[data-entity-id]').forEach(a => { // BigCommerce
      const st = a.querySelector('[class*=stock-number]');
      n += add('bc' + a.dataset.entityId, { name: (a.dataset.name || '').trim(), price: num(a.dataset.productPrice), cat: (a.dataset.productCategory || '').trim().replace(/\//g, ', '), stock: st ? num(st.textContent) : '', img: best(a.querySelector('img')), url: (a.querySelector('a[href]') || {}).href, sku: a.dataset.entityId }, base);
    });
    doc.querySelectorAll('article[data-id-product]').forEach(a => { // PrestaShop
      const t = a.querySelector('.product-title a'), p = a.querySelector('.price');
      n += add('ps' + a.dataset.idProduct, { name: t ? t.textContent.trim() : '', price: p ? num(p.textContent) : num(a.textContent.match(/\$\s*[\d,.]+/)), cat: '', stock: /out[- ]of[- ]stock/i.test(a.className + a.textContent) ? '0' : '', img: best(a.querySelector('img')), url: t && t.href, sku: (a.querySelector('.pl_reference strong') || {}).textContent || '' }, base);
    });
    doc.querySelectorAll('li.product').forEach(a => { // WooCommerce
      const t = a.querySelector('.woocommerce-loop-product__title'), p = a.querySelector('.price ins .amount, .price .amount'), b = a.querySelector('[data-product_id]');
      n += add('wc' + (b ? b.dataset.product_id : a.className), { name: t ? t.textContent.trim() : '', price: p ? num(p.textContent) : '', cat: '', stock: /outofstock/.test(a.className) ? '0' : '', img: best(a.querySelector('img')), url: (a.querySelector('a[href]') || {}).href, sku: b ? b.dataset.product_sku || '' : '' }, base);
    });
    return n;
  };
  const get = async url => { try { const r = await fetch(url, { credentials: 'include' }); return r.ok ? new DOMParser().parseFromString(await r.text(), 'text/html') : null; } catch (e) { return null; } };
  const skip = /log-?in|sign-?in|account|cart|checkout|contact|about|blog|news|cms|content\/|privacy|terms|policy|wishlist|password|register|sitemap|faq|help|shipping-|\.(jpe?g|png|gif|webp|svg|pdf)(\?|$)/i;
  cards(document, location.href);
  const seen = new Set([location.href]), queue = [];
  const path = location.pathname.replace(/\/+$/, '');
  if (rows.size && path) { // on a category page: follow that listing's pages
    const nx = document.querySelector('link[rel=next], a[rel=next]'); if (nx) queue.push([abs(nx.getAttribute('href'), location.href), true]);
  } else { // on a home page: go through the category links
    [...document.querySelectorAll('a[href]')].forEach(a => { const u = abs(a.getAttribute('href'), location.href).replace(/#.*$/, ''), t = a.textContent.trim(); if (u.startsWith(origin) && !u.includes('?') && u.replace(origin, '').split('/').filter(Boolean).length <= 3 && u.replace(origin, '').replace(/\//g, '') && !skip.test(u + ' ' + t) && !seen.has(u)) { seen.add(u); queue.push([u, false]); } });
  }
  let pages = 1, done = 0, stop = false;
  const stopBtn = document.createElement('button'); stopBtn.textContent = 'Stop and save what I have'; stopBtn.style.cssText = 'display:block;margin-top:8px'; stopBtn.onclick = () => { stop = true; }; box.append(stopBtn);
  while (queue.length && !stop && pages < 300) {
    const [url, isPage] = queue.shift(); pages++;
    say('Collecting… ' + rows.size + ' products from ' + pages + ' pages (' + queue.length + ' left)');
    const doc = await get(url); if (!doc) continue;
    const before = rows.size, n = cards(doc, url);
    if (n || isPage) { const nx = doc.querySelector('link[rel=next], a[rel=next]'); const nu = nx && abs(nx.getAttribute('href'), url); if (nu && !seen.has(nu)) { seen.add(nu); queue.unshift([nu, true]); } }
    await wait(150);
  }
  const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  const csv = ['Name,Price,Category,Stock,Image URL,Product URL,Item #'].concat([...rows.values()].map(r => [r.name, r.price, r.cat, r.stock, r.img, r.url, r.sku].map(q).join(','))).join('\r\n');
  const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); link.download = 'products-' + location.hostname + '.csv'; document.body.append(link); link.click();
  say('Done: ' + rows.size + ' products saved to ' + link.download + '. Upload it under “From a spreadsheet”.');
  stopBtn.remove();
})();
JS;
}

function tfc_si_collector_panel() {
	?>
	<details style="margin:12px 0;max-width:760px">
		<summary><strong>Supplier blocks the fetch? Collect in your browser</strong></summary>
		<div style="padding:8px 0 0 18px">
			<p>Some suppliers’ firewalls let you in but refuse your store’s server (you’ll see “403” or “access denied”). This runs in <em>your</em> browser instead:</p>
			<ol>
				<li>Open the supplier’s site in Chrome, and log in if you need to (so your prices show). Stay on its <strong>home page</strong>, or on one category page to collect just that category.</li>
				<li>Press <strong>F12</strong>, click the <strong>Console</strong> tab, paste the script below and press Enter. (If Chrome says to type “allow pasting”, do that first.)</li>
				<li>A small box shows progress and a spreadsheet downloads when it’s done. Upload it here under <em>From a spreadsheet</em>.</li>
			</ol>
			<textarea id="tfc-si-collector" readonly rows="6" class="large-text code" onfocus="this.select()"><?php echo esc_textarea( tfc_si_collector_script() ); ?></textarea>
			<p><button type="button" class="button" onclick="const t = document.getElementById('tfc-si-collector'); t.select(); navigator.clipboard.writeText(t.value).then(() => this.textContent = 'Copied!');">Copy the script</button></p>
		</div>
	</details>
	<?php
}
